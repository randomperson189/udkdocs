class GFxAction_SetTextField extends SequenceAction
	dependson(GFxMoviePlayer);

var GFxMoviePlayer MoviePlayer;
var GFxObject TextField;
var GFxClikWidget ClikTextField;

var() string 	TextFieldPath;
var() string 	Text;

var() bool		bCLIK;

event Activated()
{	
	if (bCLIK)
	{
		`log("CLIK Text Field Changed to: "@Text);
		ClikTextField = GFxClikWidget(MoviePlayer.GetVariableObject(TextFieldPath, class'GFxClikWidget'));
		ClikTextField.SetString("text", Text);
	}
	else
	{
		`log("Text Field Changed to: "@Text);
		TextField = MoviePlayer.GetVariableObject(TextFieldPath);
		TextField.SetString("text", Text);
	}
}

event bool IsValidLevelSequenceObject() { return true; }

defaultproperties
{
	ObjName="Set TextField"
	ObjCategory="GFx UI"

	VariableLinks(0)=(ExpectedType=class'SeqVar_Object',LinkDesc="Movie Player",bWriteable=false,PropertyName=MoviePlayer)
}