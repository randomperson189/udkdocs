class MouseInterfacePlayerInput extends PlayerInput;

// Stored mouse position. Set to private write as we don't want other classes to modify it, but still allow other classes to access it.
var PrivateWrite IntPoint MousePosition; 
var SFHudWrapper SFHudWrapper;
var float HudX, HudY;

event PlayerInput(float DeltaTime)
{
	GetHudSize();
	
	if (myHUD != None) 
	{
		// Add the aMouseX to the mouse position and clamp it within the viewport width
		MousePosition.X = Clamp(MousePosition.X + aMouseX, 0, HudX); 
		// Add the aMouseY to the mouse position and clamp it within the viewport height
		MousePosition.Y = Clamp(MousePosition.Y - aMouseY, 0, HudY); 
	}
	Super.PlayerInput(DeltaTime);
}

function GetHudSize()
{
    SFHudWrapper = SFHudWrapper(myHUD);
	HudX = SFHudWrapper.HudMovieSize.GetFloat("width");
	HudY = SFHudWrapper.HudMovieSize.GetFloat("height");
}

function SetMousePosition(int X, int Y)
{
	GetHudSize();
	
	if (MyHUD != None)
	{
		MousePosition.X = Clamp(X, 0, HudX);
		MousePosition.Y = Clamp(Y, 0, HudY);
	}
}

defaultproperties
{
}