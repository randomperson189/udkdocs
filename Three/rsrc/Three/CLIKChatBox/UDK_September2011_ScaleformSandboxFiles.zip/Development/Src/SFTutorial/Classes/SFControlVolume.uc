class SFControlVolume extends Volume
	placeable;

var bool 						bControlled;
var int 						ElapsedTime;
var byte						PercentCaptured;

var (TimeToControl) int 		TimeToControl;
var (TimeToControl) float 		UpdateRate;

var () SwfMovie 				Movie;
var () bool						bRenderOnHUD;
var () StaticMesh 				Mesh;
var () vector					TranslationOffset;
var () array<MaterialInterface> Materials;
var () TextureRenderTarget2D 	RenderTexture;

var Info 						ControlTimer;

var SFControlVolumeMovie 		CVMovie;
var SFControlVolumeMesh 		CVMesh;

// Methods

event PostBeginPlay()
{	
	Super.PostBeginPlay();
	ControlTimer = Spawn(class'SFVolumeControlTimer', self);
}


event Touch (Actor Other, PrimitiveComponent OtherComp, vector HitLocation, vector HitNormal)
{
	super.Touch(Other,OtherComp,HitLocation,HitNormal);
	`log("CV Loc: " @ self.Location);
	
	if (!bRenderOnHUD)
	{
		CVMesh = Spawn(class'SFControlVolumeMesh');
		CVMesh.Mesh.SetStaticMesh(Mesh);
		CVMesh.Mesh.SetMaterial(0,Materials[0]);
		CVMesh.SetLocation(self.Location + TranslationOffset);
		CVMesh.PC = Other;
	}
	
	if(!bControlled)
	{
		ControlTimer.SetTimer(UpdateRate,true);
	}
	
	CreateControlVolumeMovie();
	UpdateStatusBar();
}

event UnTouch ( Actor Other )
{
	Super.UnTouch(Other);
	
	if (!bRenderOnHUD)
	{
		CVMesh.Destroy();
	}
	
	ControlTimer.ClearTimer();
	CVMovie.Close(true);
	CVMovie = none;
	
	if(!bControlled)
	{
		ElapsedTime=0;
	}
}

function StartControlling(SFVolumeControlTimer VC)
{
	if (VC == ControlTimer)
	{
		ElapsedTime++;
		`log("Time to capture: " @ TimeToControl - ElapsedTime);
		
		// Tick the Status Bar
		UpdateStatusBar();

		if(ElapsedTime >= TimeToControl)
		{
			bControlled=true;
			`log("Controlled!");
			ControlTimer.ClearTimer();
		}
	}
}

function UpdateStatusBar()
{
	PercentCaptured = (100 * float(ElapsedTime)) / float(TimeToControl);
	CVMovie.UpdateStatusBar(PercentCaptured);
}

function CreateControlVolumeMovie()
{
	CVMovie = new class'SFControlVolumeMovie';
	CVMovie.MovieInfo = Movie;
	
	if (!bRenderOnHUD)
	{
		CVMovie.RenderTexture = RenderTexture;
	}
    
	CVMovie.SetTimingMode(TM_Real); 
    CVMovie.Start();
}

defaultproperties
{
	TimeToControl=10
	UpdateRate=1.0
}