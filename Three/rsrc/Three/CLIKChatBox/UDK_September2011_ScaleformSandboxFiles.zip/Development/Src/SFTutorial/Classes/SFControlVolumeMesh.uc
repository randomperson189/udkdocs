class SFControlVolumeMesh extends StaticMeshActor
	placeable;

var() editinline const StaticMeshComponent Mesh;

var vector PlayerLoc; // location of player
var actor PC;

function Tick(float fDeltaTime)
{
	super.Tick(fDeltaTime);
	
	// Always face the player
	PlayerLoc = PC.Location;
	SetRotation(Rotator(PlayerLoc - self.Location));
	
	// SetRotation(Rotation + rot(0,90,0) * DegToRad * RadToUnrRot * fDeltaTime);
}

defaultproperties
{
	bStatic = false
	bMovable = true
	
	Begin Object class=StaticMeshComponent Name=StaticMeshComp1
		CollideActors = false
		BlockActors = false
		BlockRigidBody = false
	End Object

	Mesh = StaticMeshComp1
	Components.Add(StaticMeshComp1)
}