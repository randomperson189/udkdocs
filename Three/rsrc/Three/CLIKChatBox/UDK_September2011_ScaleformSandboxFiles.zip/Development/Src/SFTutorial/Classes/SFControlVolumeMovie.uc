class SFControlVolumeMovie extends GFxMoviePlayer;

var GFxObject StatusBarMC;
var int Width, Height;

function bool Start(optional bool StartPaused = false)
{	
	local float x0, y0, x1, y1;

    super.Start();
    Advance(0);
	
	StatusBarMC = GetVariableObject("_root.BlueStatusBar");

	// Get width & height of Movie
	GetVisibleFrameRect(x0, y0, x1, y1);
	Width = x1-x0;
	Height = y1-y0;
	
    return true;	
}

function UpdateStatusBar(byte PercentCaptured)
{
    local GFxObject.ASDisplayInfo DI;
		
    DI.hasXScale = true;
	DI.hasAlpha = true;
    DI.XScale = PercentCaptured;
	DI.Alpha = 100;
	
	if (DI.XScale >= 100)
	{
		DI.XScale = 101;
	}
	else if (DI.XScale == 0)
	{
		DI.XScale = 1;
		DI.Alpha = 0;
	}
	
	StatusBarMC.SetDisplayInfo(DI);		
}

function UpdatePosition(SFControlVolume CV, Vector ScreenPos)
{
	if (CV.bRenderOnHUD == true)
	{
		self.SetViewPort(ScreenPos.X,ScreenPos.Y,Width,Height);
	}
}

defaultproperties
{    
	bDisplayWithHudOff = false
}