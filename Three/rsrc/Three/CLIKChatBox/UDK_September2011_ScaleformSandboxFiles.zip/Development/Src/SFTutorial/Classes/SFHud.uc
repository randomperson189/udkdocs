/*
* Flash file: \UDKGame\Flash\UDKSFTutorial\MySFHUD.FLA/SWF
*/

class SFHud extends GFxMoviePlayer;

var WorldInfo    ThisWorld;
var SFPlayerController PC;

// Chat vars
var array<string> chatMessages;
var bool bChatting;

// Attach/Remove Movie Clip vars
var GFxObject PlayerPic;
var array<ASValue> args;
var bool bShowMovie;

// CLIK Widgets
var GFxClikWidget MyHudButton, MyMovieButton, MyTextField, MySlider;
var GFxClikWidget MyChatInput, MyChatSendButton, MyChatLog;

// Standard Flash Objects
var GFxObject SpeedTF, Scoreboard;
var GFxObject RootMC, ContainerMC, MouseContainer, MouseCursor;

var int LastSpeed;
var byte resolution;
var localized string MyString;

var SFSpawnableObject MySpawnedObject;

function Init(optional LocalPlayer player)
{	
	super.Init(player);
	
	ThisWorld = GetPC().WorldInfo;

    Start();
    Advance(0);
		
	AddCaptureKey('Left');
	AddCaptureKey('Right');
	AddFocusIgnoreKey('LeftShift');
	AddFocusIgnoreKey('Enter');
    
	RootMC = GetVariableObject("_root");
	ContainerMC = GetVariableObject("_root.container");
	SpeedTF = GetVariableObject("_root.container.speed_tf");
	
	resolution = 1;
	LastSpeed = -1337;
	bChatting = false;
	bShowMovie = true;
	
	// Set the delegate function DoThis().
	self.SetMyDelegate(none); // clear it first
	self.SetMyDelegate(DoThis);
	
	// Register the HUD with the PlayerController
	PC = SFPlayerController(GetPC());
	PC.registerHUD(self);

	SpawnTestObject();
}

event UpdateMousePosition(float X, float Y)
{
	local MouseInterfacePlayerInput MouseInterfacePlayerInput;

	MouseInterfacePlayerInput = MouseInterfacePlayerInput(GetPC().PlayerInput);

	if (MouseInterfacePlayerInput != None)
	{
		MouseInterfacePlayerInput.SetMousePosition(X, Y);
	}
}

/** Toggles mouse cursor on/off */
function ToggleCursor(bool showCursor, float mx, float my)
{	

	if (showCursor)
	{
		MouseContainer = CreateMouseCursor();
		MouseCursor = MouseContainer.GetObject("my_cursor");
		MouseCursor.SetPosition(mx,my);
		MouseContainer.SetBool("topmostLevel", true);
	}
	else
	{
		MouseContainer.Invoke("removeMovieClip", args);
		MouseContainer = none;	
	}
	
	if (!bChatting)
	{
		self.bCaptureInput = showCursor;
		self.bIgnoreMouseInput = !showCursor;	
	}
	else
	{
		self.bCaptureInput = true;
		self.bIgnoreMouseInput = false;
	}
}

function ToggleChat()
{
	if (!bChatting)
	{
		self.bCaptureInput = true;
		OnChat();
	}
	else
	{
		self.bCaptureInput = false;
		OnChatSend();
	}
}

/* 
* Attach the Mouse Cursor to the Stage 
*/

function GFxObject CreateMouseCursor()
{
	return RootMC.AttachMovie("MouseContainer", "MouseCursor");
}

/* 
* Called from UTGFxHudWrapper 
*/

function TickHud(float DeltaTime)
{	
	local UTPawn UTP;
	local int Pawnspeed;
	  
	UTP = UTPawn(PC.Pawn);

	if( UTP == None ) 
		return;

	PawnSpeed = (UTP.Velocity << UTP.Rotation).X;
	if (PawnSpeed != LastSpeed)
	{
		SpeedTF.SetString("text", string(PawnSpeed));
		LastSpeed = PawnSpeed;
	}
}

/* 
* Change resolution on the fly when Resolution Button is pressed 
*/

function MyHudButtonPressed(GFxClikWidget.EventData ev)
{
	switch(resolution) 
	{
		case(1): 
			ConsoleCommand("setres 800x600");
			resolution = 2;
			break;
		case(2): 
			ConsoleCommand("setres 1024x768");
			resolution = 3;
			break;
		case(3): 
			ConsoleCommand("setres 1280x720");
			resolution = 1;
			break;
		default:
			break;
	}
}

/* 
* Attach / Remove a movie clip 
*/

function MyMovieButtonPressed(GFxClikWidget.EventData ev)
{
	if (bShowMovie)
	{
		PlayerPic = ContainerMC.AttachMovie("PlayerPicture", "Picture");
		PlayerPic.SetPosition(0, 100);
	}
	else if (!bShowMovie)
	{
		PlayerPic.Invoke("removeMovieClip", args);
	}
	bShowMovie = !bShowMovie;
}

/*
* Multiline Chat System
*/

// Event Handler - handles when the player clicks on the chat box text input field.
function OnChat(optional GFxClikWidget.EventData ev)
{
	bChatting = true;
	MyChatInput.SetBool("focused", true);
}

// Event Handler - this function fires off when the player hits the Send button in the chat window.
function OnChatSend(optional GFxClikWidget.EventData ev)
{
	local string Msg;
	
	Msg = MyChatInput.GetString("text");
		
	if (Msg != "")
	{
		PC.SendTextToServer(PC, Msg);
	}
	
	MyChatInput.SetString("text", "");
	self.bCaptureInput = false;
	bChatting = false;
	MyChatLog.SetBool("focused", true);
}

// This function is called from SFTutorialGame.uc - it displays all chat messages received in the chat log on screen.
function UpdateChatLog(string broadcastMsg)
{
	local string msg;
	local int i;
	
	chatMessages.AddItem(broadcastMsg);
	
	msg = "";
	
	for (i = 0; i < chatMessages.length; i++)
	{
		msg @= chatMessages[i];
		msg @= "\n";
	}
	
	MyChatLog.SetString("text", msg);
	
	// This is necessary to ensure the chat log srolls down to the bottom to show the most recent messages
	MyChatLog.SetFloat("position", MyChatLog.GetFloat("maxscroll"));
}

/*
* These four functions demonstrate how to rotate a 3D mesh in the game world using a CLIK slider
* See the accompanying ActionScript in the SFHUD.FLA file
*/

// This function sets the object to be spawned's position in the game world, and then caches a reference to the spawned 3D object in "MySpawnedObject"
function SpawnTestObject()
{
	local vector objectLoc;
	local rotator objectRotation;
	
	objectLoc = vect(0,0,-100);
	MySpawnedObject = SpawnObject(objectLoc);
	
	// Set the initial value of the slider to match that of the spawned in object's Yaw.
	objectRotation = MySpawnedObject.Rotation;
	MySlider.SetFloat("value", (objectRotation.Yaw * UnrRotToDeg));
}

// This function actually spawns the 3D object.
function SFSpawnableObject SpawnObject(vector loc)
{
	local SFSpawnableObject a;
	a = ThisWorld.Spawn(class'SFSpawnableObject',,,loc);
	return a;
}

// Event hanlder - handles slider changes (when the player drags the slider left or right)
function OnSliderChange(GFxClikWidget.EventData ev)
{
	local float sliderValue;
	sliderValue = MySlider.GetFloat("value");
	ObjectRotate(sliderValue);
}

// This function uses the slider's value (yaw) to rotate the 3D object "MySpawnedObject" on its Z axis.
function ObjectRotate(float yaw)
{
	local rotator r;

	r = rot(0, 0, 0);
	r.Yaw = yaw * DegToUnrRot; // OR: yaw * 65536 / 360;
	
	if(MySpawnedObject != none)
	{
		MySpawnedObject.SetRotation(r);
	}
}

/*
* Delegate Example - Whenever MyASFunction() is called in ActionScript, instead execute DoThis().
*/

// Here we declare the delegate.
delegate byte MyDelegate(bool bTrue);

// This is the function we'll use to replace MyASFunction() from ActionScript.
function byte DoThis(bool bTrue)
{
	local byte myNum;
	
	myNum = 5;
	`log("Do This? " @ bTrue);
	return myNum;
}

// This function is called with self.SetMyDelegate(DoThis) in the Init() function above.
function SetMyDelegate( delegate<MyDelegate> InDelegate )
{
	local GFxObject _global;
	_global = GetVariableObject("_global");        
	ActionScriptSetFunction(_global, "MyASFunction");
}

/*
* ExternalInterface.call from ActionScript
*/ 

function KeyPressed(string keyPressed)
{
	`log("Key Pressed: "@keyPressed);
}

/* 
* Events 
*/

event bool WidgetInitialized(name WidgetName, name WidgetPath, GFxObject Widget)
{    
    switch(WidgetName)
    {                 
        case ('myHudButton'):
            MyHudButton = GFxClikWidget(Widget);
			MyHudButton.AddEventListener('ClIK_press', MyHudButtonPressed);
            break;
		case ('movieBtn'):
			MyMovieButton = GFxClikWidget(Widget);
			MyMovieButton.AddEventListener('CLIK_press', MyMovieButtonPressed);
			break;
		case ('myTextField'):
			MyTextField = GFxClikWidget(Widget);
			MyTextField.SetString("text", MyString);
			break;
		case ('textInput'):
			MyChatInput = GFxClikWidget(Widget);
			MyChatInput.AddEventListener('CLIK_press', OnChat);
			break;
		case ('chatSendBtn'):
			MyChatSendButton = GFxClikWidget(Widget);
			MyChatSendButton.AddEventListener('CLIK_press', OnChatSend);
			break;
		case ('chatArea'):
			MyChatLog = GFxClikWidget(Widget);
			MyChatLog.SetBool("editable", false);
			break;	
		case ('slider'):
			MySlider = GFxClikWidget(Widget);
			MySlider.AddEventListener('CLIK_change', OnSliderChange);
			MySlider.SetFloat("maximum", 359);
			MySlider.SetBool("snapping", true);
			MySlider.SetFloat("snapInterval", 1);
			break;
        default:
            break;
    }
    return true;
}

defaultproperties
{
	WidgetBindings.Add((WidgetName="myHudButton",WidgetClass=class'GFxClikWidget')) 
	WidgetBindings.Add((WidgetName="movieBtn",WidgetClass=class'GFxClikWidget'))
	WidgetBindings.Add((WidgetName="myTextField",WidgetClass=class'GFxClikWidget'))

	WidgetBindings.Add((WidgetName="textInput",WidgetClass=class'GFxClikWidget'))
	WidgetBindings.Add((WidgetName="chatSendBtn",WidgetClass=class'GFxClikWidget'))
	WidgetBindings.Add((WidgetName="chatArea",WidgetClass=class'GFxClikWidget'))
	
	WidgetBindings.Add((WidgetName="slider",WidgetClass=class'GFxClikWidget'))
	
	MovieInfo = SwfMovie'UDKSFTutorial.MySFHUD'
	
	bIgnoreMouseInput = true
	bDisplayWithHudOff = false
	bEnableGammaCorrection = false
	bPauseGameWhileActive = false
	bCaptureInput = false;
}
