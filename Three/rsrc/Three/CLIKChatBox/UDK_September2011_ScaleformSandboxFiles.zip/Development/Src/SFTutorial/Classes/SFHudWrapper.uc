/* This is the HUD wrapper. Its job is to instantiate the HUD and to tell it to update after each frame is rendered. */

class SFHudWrapper extends UTHUDBase;

/** Movie */
var SFHud   			HudMovie;

/** Class of Movie object */
var class<SFHud> 		HUDClass;

var GFxObject 			HudMovieSize;

var MouseInterfacePlayerInput MouseInterfacePlayerInput;
var float MouseX, MouseY;

simulated function PostBeginPlay()
{
	Super.PostBeginPlay();
	CreateHUDMovie();
	
	HudMovieSize = HudMovie.GetVariableObject("Stage.originalRect");
	`log("Movie Dimensions: " @ int(HudMovieSize.GetFloat("width")) @ "x" @ int(HudMovieSize.GetFloat("height")));
	
	MouseInterfacePlayerInput = MouseInterfacePlayerInput(PlayerOwner.PlayerInput);
}

function CreateHUDMovie()
{
	HudMovie = new HUDClass;

	HudMovie.SetTimingMode(TM_Real);
	HudMovie.Init(class'Engine'.static.GetEngine().GamePlayers[HudMovie.LocalPlayerOwnerIndex]);
	
	HudMovie.SetViewScaleMode(SM_NoScale);
	HudMovie.SetAlignment(Align_TopLeft);
}

exec function SetShowCursor(bool showCursor)
{
	HudMovie.ToggleCursor(showCursor, MouseX, MouseY);
}

exec function ChatHandler()
{
	HudMovie.ToggleChat();
}

/* 
* Events 
*/

event PostRender()
{	
	local SFControlVolume SFCV;

	super.PostRender();

	// Update control volume relative screen positions
	foreach WorldInfo.AllActors(class'SFControlVolume',SFCV)
	{	
		if (SFCV.CVMovie != none)
		{
			SFCV.CVMovie.UpdatePosition(SFCV,Canvas.Project(SFCV.Location));
		}
	}
	
	MouseX = MouseInterfacePlayerInput.MousePosition.X;
	MouseY = MouseInterfacePlayerInput.MousePosition.Y;

	// Tick HUD
	if (HudMovie != none)
	{
		HudMovie.TickHud(0);
	}
}

defaultproperties
{
	HUDClass = class'SFHud'	
}
