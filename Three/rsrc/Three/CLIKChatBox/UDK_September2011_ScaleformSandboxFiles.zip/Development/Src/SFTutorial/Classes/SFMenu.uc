/*
* Flash file: \UDKGame\Flash\UDKSFTutorial\MySFMenu.FLA/SWF
*/

class SFMenu extends GFxMoviePlayer
	config(ScaleformMenu);
	
var bool bBloom;
var string myMessage;

/** vars to contain retrieved Flash/AS variables */
var bool myBoolean;
var string myString;
var float myNumber;

/** UnrealScript variables to be retrieved by ActionScript */
var float someFloat;
var string someString;

/** Structure which defines each option. */
struct Option
{
	var string OptionName;
	var string OptionLabel;
	var string OptionDesc;
};

/** Arays of all list and drop down options, defined in DefaultScaleformMenu.ini */
var config array<Option> ListOptions;
var config array<Option> DropDownOptions;

/** Reference to the list's dataProvider array in AS. */
var GFxObject ListDataProvider;

/** GFxObjects */
var GFxObject RootMC, MyMovieClip, MouseCursor, MyOptions;

/** Standard Flash text field. */
var GFxObject MainMenuTitle;

/** Widgets set up using GetObject(). */
var GFxClikWidget MyClikLabel, MyDropDownList;

/** These CLIK Widgets are setup in the WidgetInitialized() callback and bound in default properties. */
var GFxClikWidget StartButton, BloomOption, DropDown, ScrollingList, MyResolutionOption, OKButton;

function bool Start(optional bool StartPaused = false)
{	
	someFloat = 1337;
	someString = "Boo!";
	
    super.Start();
    Advance(0);
	
	/** Set variables up for a CLIK label inside another movie clip on the _root timeline. */
    RootMC = GetVariableObject("_root");
    MyMovieClip = RootMC.GetObject("mymovieclip");
    MyClikLabel = GFxClikWidget(MyMovieClip.GetObject("mycliklabel", class'GFxClikWidget'));
	
	/** Get the options set in Flash. */
	MyOptions = GetVariableObject("_root.options");
	
	/** Set the text of main menu title and CLIK label. */
	myMessage = "Something cool!";
	SetMainMenuTitle(myMessage);
	SetClikLabel(myMessage);
	
	/** Retrieve variables from the Flash file */
	myBoolean = RootMC.GetBool("MyBoolean");
	myString = RootMC.GetString("MyString");
	myNumber = RootMC.GetFloat("MyNumber");
	`log("##### MyBoolean: "@myBoolean);
	`log("##### MyString: "@myString);
	`log("##### MyNumber: "@myNumber);
	
	/* Set AS vars */
	RootMC.SetBool("MyBoolean", false);
	RootMC.SetString("MyString", "Something AWESOME!");
	RootMC.SetFloat("MyNumber", 100);
	`log("##### MyString changed to: "@RootMC.GetString("MyString"));
	UpdateVariableDisplay();
	
	/* Create the mouse cursor */
	MouseCursor = CreateMouseCursor();
	MouseCursor.SetBool("topmostLevel", true);	
					
    return true;
}

function UpdateImages()
{
	local GFxObject myImageLoader;
	myImageLoader = RootMC.GetObject("ui_loader");
	myImageLoader.SetString("source","img://UDKSFTutorial.teddy");
}

function OnResolutionChange(GFxClikWidget.EventData ev)
{
	local int selectedRes;
    MyOptions.SetFloat("selectedResolution", MyResolutionOption.GetFloat("selectedIndex"));
	selectedRes = MyOptions.GetFloat("selectedResolution");
    switch (selectedRes)
	{
		case(0):
			ConsoleCommand("setres 800x600");
			break;
		case(1): 
			ConsoleCommand("setres 1024x768");
			break;
		case(2): 
			ConsoleCommand("setres 1280x720");
			break;
		default:
			break;
	}
}

function OptionsOpen()
{
}

/* Attach the Mouse Cursor to the Stage */
function GFxObject CreateMouseCursor()
{
	return RootMC.AttachMovie("MouseContainer", "MouseCursor");
}

function UpdateVariableDisplay()
{
	ActionScriptVoid("UpdateVariableDisplay");
}

/** Set the main menu title, which is a normal Flash text field. */
function SetMainMenuTitle(string message)
{
    MainMenuTitle = GetVariableObject("_root.MyTitleMovie.textField");
	//MainMenuTitle.SetBool("html",true);
	//MainMenuTitle.SetString("htmlText",message);
	MainMenuTitle.SetText(message);
}

/** Intercept an ExternalInterface.call "MyExternalInterfaceCall" from Flash. */
function MyExternalInterfaceCall(string message1, int message2, bool message3)
{
	`log("###### ExternalInterface Call Received #####");
	`log("Arugment 1 (String): "@message1);
	`log("Argument 2 (Integer): "@message2);
	`log("Argument 3 (Boolean): "@message3);
	
	/** Triggers a remove kismet event named MyEvent. */
	TriggerRemoteKismetEvent('MyEvent');
}

/** Callback when a CLIK widget with enableInitCallback set to TRUE is initialized.  Returns TRUE if the widget was handled, FALSE if not. */
event bool WidgetInitialized(name WidgetName, name WidgetPath, GFxObject Widget)
{    
    switch(WidgetName)
    {                 
        case ('startBtn'):
            StartButton = GFxClikWidget(Widget);
            StartButton.AddEventListener('CLIK_press', OnStartButtonPress);
            break;
		case ('bloomBtn'):
			BloomOption = GFxClikWidget(Widget);
			BloomOption.AddEventListener('CLIK_select', OnBloomChange);
			break;
		case ('dm'):
			DropDown = GFxClikWidget(Widget);
			MyDropDownList = GFxClikWidget(DropDown.GetObject("dropdown", class'GFxClikWidget'));
			SetUpDataProvider(DropDown);
			MyDropDownList.AddEventListener('CLIK_itemPress', onDropDownChange);
			MyDropDownList.AddEventListener('CLIK_itemRollOver', onRollOver);
			break;
		case ('sl'):
			ScrollingList = GFxClikWidget(Widget);
			SetUpDataProvider(ScrollingList);
			ScrollingList.AddEventListener('CLIK_itemPress', onDropDownChange);
			ScrollingList.AddEventListener('CLIK_itemRollOver', onRollOver);
			break;
		case ('resolutionOption'): 
            MyResolutionOption = GFxClikWidget(Widget);
            break;
		case ('okBtn'):  // OK Button
			OKButton = GFxClikWidget(Widget);
			OKButton.AddEventListener('ClIK_click', OnResolutionChange);
			break;
		case ('ui_loader'):
			UpdateImages();
			break;
        default:
            break;
    }
    return true;
}

function onRollOver(GFxClikWidget.EventData ev)
{
	`log("List Item Rolled Over");
}

/*
* This function demonstrates how to retrieve (pull) an UnrealScript variable from ActionScript/Flash.
* The function is called via ExternalInterface from ActionScript and passed the variable's name and type.
* It then returns the variable's value inside an object, which ActionScript can parse.
*/

function GFxObject GetUnrealVariable(string VarName, string VarType)
{
	local GFxObject TempObj;
	local ASValue asval;
	local array<ASValue> args;
	
	// First, create a temporary object to hold the variable
	TempObj = CreateObject("Object");

	// Next get the "Type" of the variable we're requesting
	if (VarType == "float") 
	{
		asval.Type = AS_Number;
    }
    else
	{
		asval.Type = AS_String;
    }
	
	// Then set the value of the variable; the values are stored in someFloat and someString and set in the Start() function above;
	switch(VarName)
	{
		case ("someFloat"):
			asval.n = someFloat;
		case ("someString"):
			asval.s = someString;
		default:
			break;
	}
	
	// Next store the variable's value in element 0 of the args array.
	args[0] = asval;
	
	// Then add the variable/property to the temporary object we created using the variable's name & the value stored at args[0].
	TempObj.Set(VarName, args[0]);

	// Finally return the object which contains the variable.
	return TempObj;
}

/** Set the contents of the lists via config file. */
function SetUpDataProvider(GFxClikWidget Widget)
{
	local byte i;
	local GFxObject DataProvider;
	local GFxObject TempObj;

	DataProvider = CreateArray();
	
	switch(Widget)
	{
		case (ScrollingList):
			for (i = 0; i < ListOptions.Length; i++)
			{        
				TempObj = CreateObject("Object");
				TempObj.SetString("name", ListOptions[i].OptionName);
				TempObj.SetString("label", ListOptions[i].OptionLabel); // this will be displayed in the list
				TempObj.SetString("desc", ListOptions[i].OptionDesc);
				DataProvider.SetElementObject(i, TempObj);
			}
			Widget.SetFloat("rowCount", ListOptions.Length);   // you must specify the row count of scrolling lists manually 
			break;
		case (DropDown):
			for (i = 0; i < DropDownOptions.Length; i++)
			{        
				TempObj = CreateObject("Object");
				TempObj.SetString("name", DropDownOptions[i].OptionName);
				TempObj.SetString("label", DropDownOptions[i].OptionLabel); // this will be displayed in the list
				TempObj.SetString("desc", DropDownOptions[i].OptionDesc);	
				DataProvider.SetElementObject(i, TempObj);  				
			}
			break;
		default:
			break;
	}  
	Widget.SetObject("dataProvider", DataProvider);  	
}

function OnBloomChange(GFxClikWidget.EventData ev) 
{
	bBloom = BloomOption.GetBool("_selected");
	`log("###### Bloom enabled? "@bBloom);
}

function onDropDownChange(GFxClikWidget.EventData ev) 
{
	`Entry("##### Selected Item's parent: "@ev.target.GetString("_name"));
	`Entry("##### GetObject: "@ev.target.GetObject("dataProvider"));
	
	`log("#### button: "@ev.button);
	`log("#### data: "@ev.data);
	`log("#### index: "@ev.index);
	`log("#### lastIndex: "@ev.lastIndex);
	`log("#### mouseIndex: "@ev.mouseIndex);
	`log("#### target: "@ev.target);
	`log("#### type: "@ev.type);
}

/** This function illustrates how to call an AS function in the Flash file. Note that the parameter (bool b) is sent as a parameter to Flash along with the function call SetBloomOption. */
function SetBloomOption(bool b) 
{
	ActionScriptVoid("SetBloomOption");
}

/** Set a CLIK label field's text. */
function SetClikLabel(string message)
{
    MyClikLabel.SetString("text", message);
	`log("##### Label's parent: "@MyClikLabel.GetString("_parent"));
}

function OnStartButtonPress(GFxClikWidget.EventData ev)
{
	local string gameType;
	gameType = RootMC.GetString("GameType");

    `log("The start button was pressed.");
	`log("Start button label: "@ev.target.GetString("_label"));
	`log("Start button instance name: "@StartButton.GetString("_name"));
	
	if (gameType == "host") // host a multiplayer game
	{
		ConsoleCommand("open SF-Demo?Listen");
	}
	else if (gameType == "join") // join a multiplayer game
	{
		ConsoleCommand("open 127.0.0.1:7777"); // hardcoded loop-back IP for multiplayer testing on the same machine.
	}
	else // singleplayer
	{
		ConsoleCommand("open SF-Demo");
	}
}

/** This function triggers a remote kismet event. */
function TriggerRemoteKismetEvent( name EventName )
{
	local array<SequenceObject> AllSeqEvents;
	local Sequence GameSeq;
	local int i;

	GameSeq = GetPC().WorldInfo.GetGameSequence();
	if (GameSeq != None)
	{
		// find any Level Reset events that exist
		GameSeq.FindSeqObjectsByClass(class'SeqEvent_RemoteEvent', true, AllSeqEvents);

		// activate them
		for (i = 0; i < AllSeqEvents.Length; i++)
		{
			if(SeqEvent_RemoteEvent(AllSeqEvents[i]).EventName == EventName)
				SeqEvent_RemoteEvent(AllSeqEvents[i]).CheckActivate(GetPC().WorldInfo, None);
		}
	}
}

defaultproperties
{    
    WidgetBindings.Add((WidgetName="startBtn",WidgetClass=class'GFxClikWidget'))    
	WidgetBindings.Add((WidgetName="bloomBtn",WidgetClass=class'GFxClikWidget'))
	WidgetBindings.Add((WidgetName="dm",WidgetClass=class'GFxClikWidget'))
	WidgetBindings.Add((WidgetName="sl",WidgetClass=class'GFxClikWidget'))
	WidgetBindings.Add((WidgetName="resolutionOption",WidgetClass=class'GFxClikWidget'))
	WidgetBindings.Add((WidgetName="okBtn",WidgetClass=class'GFxClikWidget'))

	bDisplayWithHudOff = false
	bCaptureInput = true
	bIgnoreMouseInput = false
}