class SFPlayerController extends UTPlayerController;

var SFHud MySFHud;

function registerHUD(SFHud hud)
{
	MySFHud = hud;
}

/**
 * Client function which receives a broadcast from the server 
 * 
 * Network: Client
 */
reliable client function ReceiveBroadcast(String PlayerName, String ReceivedText)
{
	`Log(Self$":: Server sent me '"$ReceivedText$"' from "$PlayerName$".");
	MySFHud.UpdateChatLog(PlayerName @ ": " @ ReceivedText);
}

/**
 * Exec function which allows the client to send text to the server
 *
 * Network: Client
 */
exec function SendTextToServer(SFPlayerController PC, String TextToSend)
{
	`Log(Self$":: Client wants to send '"$TextToSend$"' to the server.");
	ServerReceiveText(PC, TextToSend);
}

/**
 * Server function which receives text from the client
 *
 * Network: Dedicated/Listen Server
 */
reliable server function ServerReceiveText(SFPlayerController PC, String ReceivedText)
{	
	WorldInfo.Game.Broadcast(PC, ReceivedText, 'Say');
}

defaultproperties
{
	Name="Default__SFPlayerController"
	InputClass=class'MouseInterfacePlayerInput'
}