// Just a simple script spawnable 3D object. (Spawned by the SpawnObject() function in SFHud.uc) 
// For now, I've set it to spawn the armor pickup static mesh.
// You can replace it with whatever object you want, or even make it dynamic.

class SFSpawnableObject extends DynamicSMActor_Spawnable
	notplaceable;
	
defaultproperties 
{
	Begin Object Name=StaticMeshComponent0
		StaticMesh = StaticMesh'Pickups.Armor.Mesh.S_Pickups_Armor'
		LightEnvironment = MyLightEnvironment
	End Object
	
	bCanBeDamaged = false
	bCollideActors = true
	bCollideWorld = true
	bBlockActors = true
}

