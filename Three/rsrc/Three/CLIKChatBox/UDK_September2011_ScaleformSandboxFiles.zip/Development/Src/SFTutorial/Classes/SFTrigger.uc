class SFTrigger extends Trigger
	placeable
	ClassGroup(Common);

event Touch(Actor Other, PrimitiveComponent OtherComp, vector HitLocation, vector HitNormal)
{
	local Pawn TouchingPawn;
	local SFPlayerController PC;
	
	TouchingPawn = Pawn(Other);
	PC = SFPlayerController(TouchingPawn.Controller);
	
	`log(Self$":: @@@@@@@@@ SFTrigger Touched! @@@@@@@@@");
	`log("Touched by: " @ Other);
	`log("PC: " @ PC);
	
	PC.ReceiveBroadcast("SFTrigger", "You Touched Me!");
	
	if (FindEventsOfClass(class'SeqEvent_Touch'))
	{
		NotifyTriggered();
	}
}

/** called when this trigger has successfully been used to activate a Kismet event */
function NotifyTriggered()
{
	bRecentlyTriggered = true;
	SetTimer( AITriggerDelay, false, nameof(UnTrigger) );
}

function UnTrigger()
{
	bRecentlyTriggered = false;
}