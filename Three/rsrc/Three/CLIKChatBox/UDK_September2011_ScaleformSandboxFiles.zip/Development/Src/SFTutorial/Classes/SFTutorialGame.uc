/* 
*  Add to [UnrealEd.EditorEngine] in DefaultEngine.ini: +ModEditPackages=SFTutorial
*  Add to DefaultInput.ini: .Bindings=(Name="LeftShift",Command="SetShowCursor true | Onrelease SetShowCursor false")
*  Add to DefaultInput.ini: .Bindings=(Name="Enter",Command="ChatHandler")
*  Comment out (or delete) the following line in DefaultInput.ini: .Bindings=(Name="Enter",Command="GBA_Use")
*  Add to [Engine.GameInfo] in DefaultGame.ini:
*  DefaultGame=SFTutorial.SFTutorialGame
*  DefaultServerGame=SFTutorial.SFTutorialGame
*  PlayerControllerClassName=SFTutorial.SFPlayerController
*  +DefaultMapPrefixes=(Prefix="SF",bUsesCommonPackage=FALSE,GameType="SFTutorial.SFTutorialGame")
*/

/*
* Maps: \UDKGame\Content\Maps\SFTutorials\
* Config Files: \UDKGame\Config\DefaultScaleformMenu.ini
* INT File: \UDKGame\Localization\INT\SFTutorial.int
* Package: \UDKGame\Content\ScaleformTutorial\UDKSFTutorial.upk
* Flash Files & Assets: \UDKGame\Flash\UDKSFTutorial\
* UnrealScript Files: \Development\Src\SFTutorial\
*/

class SFTutorialGame extends UTDeathmatch;

// The following two ariables are only necessary if your game does not extend UTGame or another class that does.
// Uncomment them if that is the case.

// var class<BroadcastHandler> BroadcastHandlerClass;
// var BroadcastHandler BroadcastHandler;	// handles message (text and localized) broadcasts

event InitGame( string Options, out string ErrorMessage )
{
	Super.InitGame(Options, ErrorMessage);
	BroadcastHandler = spawn(BroadcastHandlerClass);
}

/*
* Overridden Broadcast Function - used for the multi-line multiplayer chat in SFHud
*/

event Broadcast( Actor Sender, coerce string Msg, optional name Type )
{
	local SFPlayerController PC;
	local PlayerReplicationInfo PRI;
	
	// This code gets the PlayerReplicationInfo of the sender. We'll use it to get the sender's name with PRI.PlayerName
	if ( Pawn(Sender) != None )
		PRI = Pawn(Sender).PlayerReplicationInfo;
	else if ( Controller(Sender) != None )
		PRI = Controller(Sender).PlayerReplicationInfo;
	
	// This line executes a "Say"
	BroadcastHandler.Broadcast(Sender,Msg,Type);
	
	// This is where we broadcast the received message to all players
	if (WorldInfo != None)
	{
		foreach WorldInfo.AllControllers(class'SFPlayerController',PC)
		{
			`Log(Self$":: Sending "$PC$" a broadcast message from "$PRI.PlayerName$" which is '"$Msg$"'.");
			PC.ReceiveBroadcast(PRI.PlayerName, Msg);
		}
	}
}

defaultproperties
{
	PlayerControllerClass=class'SFPlayerController'
	BroadcastHandlerClass=class'Engine.BroadcastHandler'
	
	HUDType=class'SFTutorial.SFHudWrapper'
	bUseClassicHUD = true;
	
	//bDelayedStart = true;
	//bRestartLevel = false;
	
	Name="Default__SFTutorialGame"
}