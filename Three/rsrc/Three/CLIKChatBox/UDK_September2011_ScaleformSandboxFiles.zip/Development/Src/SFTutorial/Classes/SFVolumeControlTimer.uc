class SFVolumeControlTimer extends Info;

var SFControlVolume CV;

event PostBeginPlay()
{
	Super.PostBeginPlay();
	CV = SFControlVolume(Owner);
}

event Timer()
{
	CV.StartControlling(self);
}

defaultproperties
{
	TickGroup = TG_PreAsyncWork
	bStatic = false
	RemoteRole = ROLE_None
}