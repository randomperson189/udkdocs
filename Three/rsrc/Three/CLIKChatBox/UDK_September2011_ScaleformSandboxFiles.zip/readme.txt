Hey everyone,

I've decided to release all the Autodesk Scaleform sample UDK files which showcase many of the tutorials and use cases talked about here on the forums. 


Confirmed working in the August 2011 release of UDK.

NOTE: Flash files (.FLA) require Adobe Flash Pro CS4 or better.



UDK - August 2011 - Scaleform Sandbox

/************************************************** ********************
These file are provided
AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE WARRANTY
OF DESIGN, MERCHANTABILITY AND FITNESS FOR ANY PURPOSE.
************************************************** ********************/

Instructions:

    Unzip the contents into the root UDK directory.
    Add to [UnrealEd.EditorEngine] in DefaultEngine.ini:
    +ModEditPackages=SFTutorial
    Add to DefaultInput.ini:
    .Bindings=(Name="LeftShift",Command="SetShowCursor true | Onrelease SetShowCursor false")
    .Bindings=(Name="Enter",Command="ChatHandler")
    Comment out (or delete) the following line in DefaultInput.ini: .Bindings=(Name="Enter",Command="GBA_Use")
    Add to [Engine.GameInfo] in DefaultGame.ini:
    DefaultGame=SFTutorial.SFTutorialGame
    DefaultServerGame=SFTutorial.SFTutorialGame
    PlayerControllerClassName=SFTutorial.SFPlayerContr oller
    +DefaultMapPrefixes(Prefix="SF",bUsesCommonPackage =FALSE,GameType="SFTutorial.SFTutorialGame")


NOTE: Any maps that you want to use this game type (SFTutorialGame) must be prefixed with "SF-" in the map name.

Launching From the FrontEnd

    Launch the UDK Frontend. (\Binaries\UnrealFrontend.exe)
    Right click DM-Deck and choose Clone Profile
    Rename the newly cloned profile: DM-Deck.udk - Copy to SFTutorial
    Remove DM-Deck.udk under Maps to Cook.
    Click Add under Maps to Cook, and select all the maps beginning with SF-
    Put a check in the Override Default checkbox, and choose SF-MenuDemo.udk in the dropdown.
    Put -log resx=1280 resy=720 in the Launch Options text field.
    You can now launch using the Start button.


Launching From the Game Shortcut

You can also launch straight into the SFTutorial game from the desktop UDK game shortcut:

    Open DefaultEngine.ini
    Select the two lines Map= and LocalMap= under [URL] and copy and paste them immediately below themselves.
    Put a semi-colon in front of the original Map=UDKFrontEndMap.udk and LocalMap=UDKFrontEndMap.udk lines.
    Change both the new lines to point to SF-MenuDemo.udk instead.


You should now have something like this:

[URL]
MapExt=udk
; Any additional map extension to support for map loading.  
; Maps without an extension always saved with the above MapExt
AdditionalMapExt=mobile
;Map=UDKFrontEndMap.udk
;LocalMap=UDKFrontEndMap.udk
TransitionMap=EnvyEntry.udk
Map=SF-MenuDemo.udk
LocalMap=SF-MenuDemo.udk

Notes:

    While in game, hold down left shift to display the mouse cursor and interact with the various HUD elements.
    The menu screen demonstrates back and forth communication between UnrealScript and ActionScript, as well as how to implement drop down/pop-up UI that stays beneath the mouse cursor, and a working animated mask.
    Use the top slider on the HUD to rotate the armor in the middle of the room.
    The two flags can be captured, demonstrating two ways to display a Scaleform capture graphic in UnrealScript.
    The Set Resolution button will change the game window size, and demonstrates how to adjust the location of UI elements (using ActionScript).
    The Toggle MovieClip button demonstrates dynamically loading/unloading an image using the Scaleform UILoader component.
    The Chat window demonstrates a draggable multiplayer multi-line chat window.
    Pressing Enter will enable chatting, as well as sending/completing the chat message.
    In the SF-Tutorial.udk map, walk up to the red bar, and use the Y & U keys on your keyboard to rotate it. This file demonstrates the use of capture keys in Kismet.



Files Provided:

    Maps: \UDKGame\Content\Maps\SFTutorials\
    Config Files: \UDKGame\Config\DefaultScaleformMenu.ini
    INT Files: \UDKGame\Localization\INT\SFTutorial.int
    Packages: \UDKGame\Content\ScaleformTutorial\UDKSFTutorial.u pk
    Flash Files & Assets: \UDKGame\Flash\UDKSFTutorial\
    UnrealScript: \Development\Src\SFTutorial\
