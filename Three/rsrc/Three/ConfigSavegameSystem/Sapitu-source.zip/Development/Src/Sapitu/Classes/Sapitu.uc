/**
 * Savegames Are Possible In The UDK. Well, sort of.
 *
 * By Michiel 'elmuerte' Hendriks for Epic Games, Inc.
 *
 * You are free to use this example as you see fit, as long as you
 * properly attribute the origin.
 */
class Sapitu extends Object dependsOn(SapituItem);

/**
 * struct used to cache the list of items
 */
struct ItemRecord
{
	var string itemName;
	var SapituItem item;
};

/**
 * Contains all known items
 */
var array<ItemRecord> items;

/**
 * Load a character using it's id
 *
 * @param charId
 *		The identifier for the character
 * @return The created character, or none if it could not be created/loaded
 */
function SapituCharacter loadCharacter(string charId)
{
	local SapituCharacter char;
	local SapituItem item;
	local SapituInventory inv;
	local int i;
	local array<string> chars;

	chars = getCharacters();
	if (chars.find(charId) == INDEX_NONE) return none;

	char = new(none, charId) class'SapituCharacter';
	if (char == none) return none;
	// load the inventory
	for (i = 0; i < char.inventoryRecords.length; ++i)
	{
		 inv = new(none, char.inventoryRecords[i]) class'SapituInventory';
		 if (inv == none) continue;
		 item = getItem(inv.itemName);
		 if (item == none) continue;
		 inv.item = item;
		 char.inventory.addItem(inv);
	}
	return char;
}

/**
 * Get a list of all existing character ids
 *
 * @return The list of character ids.
 */
function array<string> getCharacters()
{
	local array<string> res;
	local int i, idx;
	GetPerObjectConfigSections(class'SapituCharacter', res);
	// the result contains: "ObjectName ClassName" but we only need the ObjectNames
	for (i = 0; i < res.length; ++i)
	{
		idx = InStr(res[i], " ");
		if (idx != INDEX_NONE)
		{
			res[i] = left(res[i], idx);
		}
	}
	return res;
}

/**
 * Create a new character instance. None of it's fields have been initialized.
 * It is just created with a proper id, and not saved yet.
 *
 * @param charId
 *		Optionally character id to use. This must be unique.
 * @return The newly created character
 */
function SapituCharacter createCharacter(optional string charId = "Char_"$TimeStamp()$rand(100)$"_")
{
    // note: object names shouldn't end with a number
	local SapituCharacter char;
	charId -= " ";
	charId -= ":";
	charId -= "/";
	charId -= "-";
	char = new(none, charId) class'SapituCharacter';
	return char;
}

/**
 * Initialize the item database
 */
function loadItemDB()
{
	local array<UTUIResourceDataProvider> ProviderList;
	local int i;

	if (items.length == 0)
	{
		// fill the list
		class'UTUIDataStore_MenuItems'.static.GetAllResourceDataProviders(class'SapituItem', ProviderList);
		items.length = ProviderList.length;
		for (i = 0; i < ProviderList.length; ++i)
		{
			items[i].itemName = string(ProviderList[i].name);
			items[i].item = SapituItem(ProviderList[i]);
		}
	}
}

/**
 * Get the SapituItem instance for a given name
 *
 * @param itemName
 *		The name of the item
 * @return The SapituItem instance, or none
 */
function SapituItem getItem(String itemName)
{
	local int i;
	loadItemDB();

	i = items.find('itemName', itemName);
	if (i != INDEX_NONE)
	{
		return items[i].item;
	}
	return none;
}

/**
 * Create a new inventory item.
 *
 * @param fromItem
 *		The item to create an inventory item from
 * @return
 *		The inventory item which can be added to the character
 */
function SapituInventory createInventory(SapituItem fromItem)
{
	local string invId;
	local SapituInventory inv;

    // note: object names shouldn't end with a number
	invId = string(fromItem.name)$"_"$TimeStamp()$rand(100)$"_";
	invId -= " ";
	invId -= ":";
	invId -= "/";
	invId -= "-";
	inv = new(none, invId) class'SapituInventory';
	inv.item = fromItem;
	inv.itemName = string(fromItem.name);
	inv.quality = 100;
	inv.level = fromItem.level.min+Rand(fromItem.level.max-fromItem.level.min);
	inv.characterLevel = fromItem.characterLevel.min+Rand(fromItem.characterLevel.max-fromItem.characterLevel.min);
	inv.weight = calcValue(inv.level, fromItem.weight);
	inv.value = calcValue(inv.level, fromItem.value);
	return inv;
}

/**
 * Calculate the value using the given value forumula
 *
 * @param level
 *		The level to use as input
 * @param form
 *		The forumula configuration
 * @return the value
 */
function int calcValue(int level, ValueFormula form)
{
	return form.base + Round(form.levelMult * level) + Round(FRand() * form.randMult);
}
