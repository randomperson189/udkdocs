/**
 * Savegames Are Possible In The UDK. Well, sort of.
 *
 * By Michiel 'elmuerte' Hendriks for Epic Games, Inc.
 *
 * You are free to use this example as you see fit, as long as you
 * properly attribute the origin.
 */
class SapituCharacter extends Object config(Sapitu) perobjectconfig;

/**
 * The name of the character
 */
var config string CharacterName;

/**
 * The character class (i.e. Warrior, Wizard, Wuxtory, ..)
 */
var config string CharacterClass;

/**
 * The current health
 */
var config int health;

/**
 * The maximum health
 */
var config int maxHealth;

/**
 * The current mana
 */
var config int mana;

/**
 * The maximum mana
 */
var config int maxMana;

/**
 * The amount of gold
 */
var config int gold;

/**
 * Character level
 */
var config int level;

/**
 * The strength value
 */
var config int strength;

/**
 * The dexterity value
 */
var config int dexterity;

/**
 * The magic level
 */
var config int magic;

/**
 * The defense level
 */
var config int defense;

/**
 * The identifiers of the inventory items.
 */
var config array<string> inventoryRecords;

/**
 * The instantiated inventory
 */
var array<SapituInventory> inventory;

/**
 * Save this character and it's inventory. Do not use SaveConfig() to save
 * the character, because it won't save its inventory.
 */
function save()
{
	local int i;
	for (i = 0; i < inventory.Length; i++)
	{
		inventory[i].SaveConfig();
	}
	SaveConfig();
}

/**
 * Add an item to the inventory
 *
 * @param item
 *		The item to add.
 * @return
 *		True if the item was added
 */
function bool addInventory(SapituInventory item)
{
	local int i;
	i = inventory.find(item);
	if (i != INDEX_NONE) return false;
	inventory.addItem(item);
	inventoryRecords.addItem(string(item.name));
	return true;
}

/**
 * Remove an item from the inventory
 * @param item
 *		The item to remove
 * @return
 *		True if the item was removed
 */
function bool removeInventory(SapituInventory item)
{
	local int i;
	i = inventory.find(item);
	if (i == INDEX_NONE) return false;
	inventory.removeItem(item);
	inventoryRecords.removeItem(string(item.name));
	return true;
}
