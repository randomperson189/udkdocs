/**
 * Savegames Are Possible In The UDK. Well, sort of. This gameinfo class is
 * only used to provide an entry point for messing with the Sapitu system.
 *
 * By Michiel 'elmuerte' Hendriks for Epic Games, Inc.
 *
 * You are free to use this example as you see fit, as long as you
 * properly attribute the origin.
 */
class SapituGame extends GameInfo;

var Sapitu sapitu;

event PreBeginPlay()
{
	super.PreBeginPlay();
	sapitu = new class'Sapitu';
	sapitu.loadItemDB();
}

defaultproperties
{
	PlayerControllerClass=class'SapituPC'
}
