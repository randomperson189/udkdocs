/**
 * Savegames Are Possible In The UDK. Well, sort of. This player controller is
 * only used to expose some exec functions.
 *
 * By Michiel 'elmuerte' Hendriks for Epic Games, Inc.
 *
 * You are free to use this example as you see fit, as long as you
 * properly attribute the origin.
 */
class SapituPC extends PlayerController;

var Sapitu sapitu;

/**
 * The current character
 */
var SapituCharacter char;

/**
 * The items on the ground
 */
var array<SapituInventory> items;

simulated event PostBeginPlay()
{
	super.PostBeginPlay();
	sapitu = SapituGame(WorldInfo.Game).sapitu;
}

/**
 * Create a new character
 */
exec function createChar(string charName)
{
	if (len(charName) == 0)
	{
		TeamMessage(none, "The character must have a name", 'none');
		return;
	}
	if (char != none)
	{
		TeamMessage(none, "Discarding previous character: "$char.CharacterName$" (id:"$char.Name$")", 'none');
	}
	char = sapitu.createCharacter(charName);
	char.CharacterName = charName;
	char.CharacterClass = "UDK Game Maker";
	char.level = 1;
	char.health = 100;
	char.maxHealth = 100;
	char.strength = 5;
	char.dexterity = 5;
	char.magic = 10;
	char.defense = 5;
	TeamMessage(none, "New character created", 'none');
	showChar();
}

/**
 * Save the current character
 */
exec function saveChar()
{
	if (char != none)
	{
		char.save();
		TeamMessage(none, "Current character saved", 'none');
	}
}

/**
 * Load a given character
 */
exec function loadChar(String charId)
{
	if (len(charId) == 0)
	{
		TeamMessage(none, "No character id given", 'none');
		return;
	}
	if (char != none)
	{
		TeamMessage(none, "Discarding previous character: "$char.CharacterName$" (id:"$char.Name$")", 'none');
	}
	char = sapitu.loadCharacter(charId);
	if (char == none)
	{
		TeamMessage(none, "No character found with id: "$charId, 'none');
	}
	else {
		TeamMessage(none, "Character loaded", 'none');
		showChar();
	}
}

/**
 * Print a list of the current known characters
 */
exec function printChars()
{
	local array<string> chars;
	local int i;
	chars = sapitu.getCharacters();
	if (chars.length == 0)
	{
		TeamMessage(none, "There are no saved characters", 'none');
		return;
	}
	TeamMessage(none, "The following character ids exist:", 'none');
	for (i = 0; i < chars.length; ++i)
	{
		TeamMessage(none, "    "$chars[i], 'none');
	}
}

/**
 * Print the current character to the console
 */
exec function showChar()
{
	local int i;
	if (char == none)
	{
		TeamMessage(none, "There is no character", 'none');
	}
	TeamMessage(none, "ID:        "$char.name, 'none');
	TeamMessage(none, "Name:      "$char.CharacterName, 'none');
	TeamMessage(none, "Class:     "$char.CharacterClass, 'none');
	TeamMessage(none, "Level:     "$char.level, 'none');
	TeamMessage(none, "Health:    "$char.health$"/"$char.maxHealth, 'none');
	TeamMessage(none, "Mana:      "$char.mana$"/"$char.maxMana, 'none');
	TeamMessage(none, "Strength:  "$char.strength, 'none');
	TeamMessage(none, "Dexterity: "$char.dexterity, 'none');
	TeamMessage(none, "Magic:     "$char.magic, 'none');
	TeamMessage(none, "Defense:   "$char.defense, 'none');
	TeamMessage(none, "Inventory: "$char.inventory.length$" item(s)", 'none');
	for (i = 0; i < char.inventory.Length; ++i)
	{
		TeamMessage(none, "+   Item:       "$char.inventory[i].item.DisplayName, 'none');
		TeamMessage(none, "    Item level: "$char.inventory[i].level, 'none');
		TeamMessage(none, "    Quality:    "$char.inventory[i].quality, 'none');
		TeamMessage(none, "    Weight:     "$char.inventory[i].weight, 'none');
		TeamMessage(none, "    Value:      "$char.inventory[i].value, 'none');
	}
}

/**
 * Create a random item on the ground
 */
exec function createRandomItem()
{
	local int idx;
	idx = rand(sapitu.items.length);
	if (idx != INDEX_NONE)
	{
		createItem(sapitu.items[idx].itemName);
	}
}

/**
 * Create a specific item on the ground
 */
exec function createItem(String baseItem)
{
	local SapituInventory inv;
	local SapituItem itm;
	itm = sapitu.getItem(baseItem);
	if (itm == none)
	{
		TeamMessage(none, "No item type exists with id: "$baseItem, 'none');
		return;
	}
	inv = sapitu.createInventory(itm);
	if (inv == none)
	{
		TeamMessage(none, "Error creating inventory item from: "$baseItem, 'none');
		return;
	}
	TeamMessage(none, "A "$itm.DisplayName$" fell on the ground (id:"$inv.Name$")", 'none');
	items.addItem(inv);
}

/**
 * Pick up and item from the ground and put it in the inventory of the character
 */
exec function pickupItem(String itemId)
{
	local int i;
	if (char == none)
	{
		TeamMessage(none, "There is no character to pick up the item", 'none');
		return;
	}
	for (i = 0; i < items.length; ++i)
	{
		if (string(items[i].Name) ~= itemId)
		{
			char.addInventory(items[i]);
			TeamMessage(none, "You picked up a "$items[i].item.DisplayName$" (id:"$items[i].Name$")", 'none');
			items.remove(i, 1);
			return;
		}
	}
	TeamMessage(none, "No item on the ground with id: "$itemId, 'none');
}

/**
 * Pickup everything on the ground
 */
exec function pickupAll()
{
	if (char == none)
	{
		TeamMessage(none, "There is no character to pick up the item", 'none');
		return;
	}
	while (items.length > 0)
	{
		pickupItem(string(items[0].name));
	}
}

/**
 * Show all items on the ground
 */
exec function findItems()
{
	local int i;
	for (i = 0; i < items.length; ++i)
	{
		TeamMessage(none, "You see a "$items[i].item.DisplayName$" (id:"$items[i].Name$")", 'none');
	}
}

/**
 * Show all items on the ground
 */
exec function listItemTypes()
{
	local int i;
	for (i = 0; i < sapitu.items.length; ++i)
	{
		TeamMessage(none, "Available item type: "$sapitu.items[i].item.DisplayName$" (id:"$sapitu.items[i].itemName$")", 'none');
	}
}
