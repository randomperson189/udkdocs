﻿// force units to pixels and display no dialogs
app.preferences.rulerUnits = Units.PIXELS
app.preferences.typeUnits = TypeUnits.PIXELS
app.displayDialogs = DialogModes.NO

//save doc height and width
var docW = app.activeDocument.width.value
var docH = app.activeDocument.height.value

var selectionArray = app.activeDocument.selection.bounds   //get selection bounds
var mySelection = selectionArray   // remember my selection because it will go away when we switch to a new file (once we duplicate)

//backup selection
//save selection to an alpha channel for future use
var newChan = app.activeDocument.channels.add();
app.activeDocument.selection.store(app.activeDocument.channels[newChan.name], SelectionType.EXTEND);
app.activeDocument.activeChannels = app.activeDocument.componentChannels;

//convert positions to floats based on corners of selection
tLeftXM = selectionArray[0] / docW
tLeftYM = selectionArray[1] / docH
bRightXM = selectionArray[2] / docW
bRightYM = selectionArray[3] / docH

//round values to nearest 1000th
tLeftX = Math.round(tLeftXM * 1000) / 1000
tLeftY = Math.round(tLeftYM * 1000) / 1000
bRightX = Math.round(bRightXM * 1000) / 1000
bRightY = Math.round(bRightYM * 1000) / 1000

//titles for alerts
var titles = new Array("Upper Left Corner X = ",
						"Upper Left Corner Y = ",
						"Lower Right Corner X = ",
						"Lower Right Corner Y = ");
						
//create a string for diplay in message box to get values input now as opposed to later
var message = "INPUT THESE VALUES IN MATERIAL NOW"

//create string of resulting floats
coords = titles[0] + tLeftX + "\r" + titles[1] + tLeftY + "\r\r" + titles[2] + bRightX + "\r" + titles[3] + bRightY

saveCroppedEmissive();  // duplicate the current psd, flatten, resize, and save as new emissive texture
app.activeDocument.close(SaveOptions.DONOTSAVECHANGES);



//report values
alert(message + "\r\r" + coords);


//------------------------------------------------------------------------------------------------------
//
//
//duplicate current document, crop to selection, close & save file
function saveCroppedEmissive() 
{
	//duplicate current document and crop to values saved off of original selection
	app.activeDocument.duplicate();
	app.activeDocument.crop(mySelection);

	//flatten all visible layers, do not prompt
	app.activeDocument.flatten(DialogModes.NO);
	
	//create reference to document
	//write coords to document info
	var docRef = app.activeDocument
	docRef.info.title = "Top Left: " + tLeftX + ", " + tLeftY + "    Bottom Right: " + bRightX + ", " + bRightY 
	
	//auto resize image based on largest edge and closest pow2
	imageResizing();
	
	//open image size dialog
	openImageSize();
	
	//Photoshop file > save
	ErrStrs = {}; 
	ErrStrs.USER_CANCELLED=localize("$$$/ScriptingSupport/Error/UserCancelled=User cancelled the operation"); 
	try 
	{
		var idsave = charIDToTypeID( "save" )	; 
		var desc43 = new ActionDescriptor(); 
		var idCpy = charIDToTypeID( "Cpy " ); 
		desc43.putBoolean( idCpy, true ); 
		executeAction( idsave, desc43, DialogModes.ALL );
	} 
	catch(e)
	{
		if (e.toString().indexOf(ErrStrs.USER_CANCELLED)!=-1) 
		{
			;
		}
		else
		{
			alert(localize("$$$/ScriptingSupport/Error/CommandNotAvailable=The command is currently not available"));
		}
	}
	
	//open image size window
	function openImageSize()
	{
		ErrStrs = {}; 
		ErrStrs.USER_CANCELLED=localize("$$$/ScriptingSupport/Error/UserCancelled=User cancelled the operation"); 
		try 
		{
			var idImgS = charIDToTypeID( "ImgS" ); 
			executeAction( idImgS, undefined, DialogModes.ALL );
		}
		catch(e)
		{
			if (e.toString().indexOf(ErrStrs.USER_CANCELLED)!=-1) 
			{
				;
			}
			else
			{
				alert(localize("$$$/ScriptingSupport/Error/CommandNotAvailable=The command is currently not available"));
			}
		}
	}
	
	//auto size the image
	function imageResizing()
	{
		var croppedW = app.activeDocument.width.value
		var croppedH = app.activeDocument.height.value
		if (croppedW != croppedH)
		{
			//determine larger size
			if (croppedW < croppedH)
			{
				newSize = croppedH
			}
			else
			{
				newSize = croppedW
			}
			
			var autoSize = nearestPow2(newSize);
			
			//resize document to new size
			app.activeDocument.resizeImage(autoSize,autoSize);
			
			//find nearest pow2
			function nearestPow2( aSize )
			{
				return Math.pow( 2, Math.round( Math.log( aSize ) / Math.log( 2 ) ) ); 
			}
		}
	}
}