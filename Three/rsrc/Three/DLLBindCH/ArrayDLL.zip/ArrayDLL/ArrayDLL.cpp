// ArrayDLL.cpp : Defines the exported functions for the DLL application.

#include "stdafx.h"
#include <stdio.h>
#include <assert.h>

template<typename DataType>
struct TArray
{
	DataType* Data;

	int Num()
	{
		return ArrayNum;
	}

	void Reallocate(int NewNum, bool bCompact=false)
	{
		ArrayNum = NewNum;
		if( ArrayNum > ArrayMax || bCompact )
		{
			ArrayMax = ArrayNum;
			Data = (DataType*)(*ReallocFunctionPtr)( Data, ArrayMax * sizeof(DataType), 8);
		}
	}
private:
	int ArrayNum;
	int ArrayMax;
};

struct MyNavigationStruct
{
	TArray<int> NavigationData;
};


extern "C"
{
	typedef void* (*ReallocFunctionPtrType)(void* Original, DWORD Count, DWORD Alignment);

	ReallocFunctionPtrType ReallocFunctionPtr = NULL;

	struct FDLLBindInitData
	{
		INT Version;
		ReallocFunctionPtrType ReallocFunctionPtr;
	};

	__declspec(dllexport) void DLLBindInit(FDLLBindInitData* InitData)
	{
		ReallocFunctionPtr = InitData->ReallocFunctionPtr;
	}

	__declspec(dllexport) void GetNavData(struct MyNavigationStruct* NavData)
	{
		NavData->NavigationData.Reallocate(1000);

		for( int i=0;i<1000;i++ )
		{
			NavData->NavigationData.Data[i] = i;
		}
	}
}


