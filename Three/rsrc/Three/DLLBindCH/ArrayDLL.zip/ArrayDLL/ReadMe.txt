This is a Visual Studio 2008 project to demonstrate DLLBind with a struct with a dynamic array in it.

1. Build ArrayDLL.dll and place in your Binaries\Win32\UserCode folder.
2. Put the *.uc files from the Classes folder in your Developement\Src\MyMod\Classes folder.
3. Edit your UDKGame\Config\UDKEngine.ini file to remove the semicolon from the line that says ModEditPackages=MyMod
4. Recompile scripts and then launch UDK.exe, for example UDK.exe dm-deck?game=MyMod.ArrayDLLGameInfo

Please refer to this document for more information: http://udn.epicgames.com/Three/DLLBind.html
