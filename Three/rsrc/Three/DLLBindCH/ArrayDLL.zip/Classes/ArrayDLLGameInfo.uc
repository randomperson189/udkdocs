class ArrayDLLGameInfo extends GameInfo;

defaultproperties
{
	PlayerControllerClass=class'ArrayDLLPlayerController'
}