class ArrayDLLPlayerController extends PlayerController
	DLLBind(ArrayDLL);

struct MyNavigationStruct
{
	var array<int> NavigationData;
};

dllimport final function GetNavData(out MyNavigationStruct NavData);

exec function Test()
{
	local MyNavigationStruct MyData;
	local int i;

	GetNavData(MyData);

	for( i=0;i<MyData.NavigationData.length;i++ )
	{
		`Log("Entry "$i$" has value "$MyData.NavigationData[i]);
	}
}
