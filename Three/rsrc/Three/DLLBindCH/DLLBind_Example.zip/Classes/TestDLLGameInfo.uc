class TestDLLGameInfo extends GameInfo;

defaultproperties
{
	PlayerControllerClass=class'TestDLLPlayerController'
}