class TestDLLPlayerController extends PlayerController
	DLLBind(TestDLL);

dllimport final function CallDLL1(out string s);
dllimport final function vector CallDLL2(float x, float y, float z);
dllimport final function bool CallDLL3(string s, int i[2], out float f, out vector v);

exec function Test1(string s)
{
	CallDLL1(s);
	say("s was changed by the DLL to: "$s);
}

exec function Test2(float x, float y, float z)
{
	local vector V;
	V = CallDLL2(x, y, z);
	say("DLL returned vector "$V);
}

exec function Test3(string s, int i, float f)
{
	local vector V;
	local int j[2];
	local bool b;
	V = vect(1,2,3);
	j[0] = i;
	j[1] = -i;
	b = CallDLL3(s, j, f, V);
	say("v was set to "$V$" and f to "$f$". DLL returned value "$b);
}
