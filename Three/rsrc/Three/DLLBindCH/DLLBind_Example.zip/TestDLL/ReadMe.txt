This is a Visual Studio 2008 project for a test DLL for use with the UDK DllBind feature.

1. Build TestDLL.dll and place in your Binaries\Win32\UserCode folder.
2. Put the *.uc files from the Classes folder in your Developement\Src\MyMod\Classes folder.
3. Edit your UTGame\Config\UTEngine.ini file to remove the semicolon from the line that says ModEditPackages=MyMod
4. Recompile scripts and then launch UDK.exe, for example UDK.exe dm-deck?game=MyMod.TestDLLGameInfo
5. Use the console commands Test1, Test2 and Test3 to call the DLL functions from UnrealScript.

Please refer to this document for more information: http://udn.epicgames.com/Three/DLLBind.html
