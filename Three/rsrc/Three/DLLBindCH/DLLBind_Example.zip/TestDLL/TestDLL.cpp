// TestDLL.cpp : Defines the exported functions for the DLL application.

#include "stdafx.h"
#include <stdio.h>

extern "C"
{
	struct FVector
	{
		float x,y,z;
	};

	__declspec(dllexport) void CallDLL1(wchar_t* s)
	{
		MessageBox(0, s, L"Inside the DLL: CallDLL1", MB_OK);
		// reverse the out parameter string
		int len = wcslen(s);
		for(int i=0; i<len>>1;i++)
		{
			wchar_t temp = s[i];
			s[i] = s[len-i-1];
			s[len-i-1] = temp;
		}
	}

	__declspec(dllexport) FVector* CallDLL2(float x, float y, float z)
	{
		static FVector result;	// declared static so that the struct's memory is still valid after the function returns.
		result.x = x;
		result.y = y;
		result.z = z;
		return &result;
	}

	__declspec(dllexport) bool CallDLL3(wchar_t* s, int i[2], float* f, FVector* V)
	{
		wchar_t temp[1024];
		swprintf_s(temp, 1024, L"string: %s, i: {%d,%d}, float: %f, V was (%f,%f,%f)", s, i[0], i[1], *f, V->x, V->y, V->z);
		V->x = (float)i[0];
		V->y = (float)i[1];
		V->z = (*f);
		return (MessageBox(0, temp, L"Inside the DLL: CallDLL3", MB_OKCANCEL) == IDOK);
	}
}
