class StringDLLGameInfo extends GameInfo;

defaultproperties
{
	PlayerControllerClass=class'StringDLLPlayerController'
}