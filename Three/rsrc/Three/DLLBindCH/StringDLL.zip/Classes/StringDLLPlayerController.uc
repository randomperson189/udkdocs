class StringDLLPlayerController extends PlayerController
	DLLBind(StringDLL);

struct MyPlayerStruct
{
	var string PlayerName;
	var string PlayerPassword;
	var float Health;
	var float Score;
};

dllimport final function ShowPlayerInfo(MyPlayerStruct PlayerStruct);
dllimport final function bool UpdatePassword(out MyPlayerStruct PlayerStruct, string NewPassword);

exec function Test(string NewPassword)
{
	local MyPlayerStruct MyPlayer;

	MyPlayer.PlayerName = "Jack";
	MyPlayer.Health = 100;
	MyPlayer.Score = 10;

	ShowPlayerInfo(MyPlayer);

	// allocate memory for new password value to be set by DLL. Allocate space for at least 10 characters.
	MyPlayer.PlayerPassword = "xxxxxxxxxx";

	if( !UpdatePassword(MyPlayer, NewPassword) )
	{
		`Log("DLL could not update new password");
	}

	ShowPlayerInfo(MyPlayer);
}
