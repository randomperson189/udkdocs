This is a Visual Studio 2008 project to demonstrate DLLBind with structs with strings

1. Build StringDLL.dll and place in your Binaries\Win32\UserCode folder.
2. Put the *.uc files from the Classes folder in your Developement\Src\MyMod\Classes folder.
3. Edit your UTGame\Config\UTEngine.ini file to remove the semicolon from the line that says ModEditPackages=MyMod
4. Recompile scripts and then launch UDK.exe, for example UDK.exe dm-deck?game=MyMod.StringDLLGameInfo

Please refer to this document for more information: http://udn.epicgames.com/Three/DLLBind.html
