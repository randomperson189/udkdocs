// StringDLL.cpp : Defines the exported functions for the DLL application.

#include "stdafx.h"
#include <stdio.h>
#include <assert.h>

extern "C"
{
	struct FString
	{
		wchar_t* Data;
		int ArrayNum;
		int ArrayMax;

		void UpdateArrayNum()
		{
			ArrayNum = wcslen(Data)+1;
			assert(ArrayNum <= ArrayMax);
		}
	};

	struct MyPlayerStruct
	{
		FString PlayerName;
		FString PlayerPassword;
		float Health;
		float Score;			
	};

	__declspec(dllexport) void ShowPlayerInfo(MyPlayerStruct* Player)
	{
		wchar_t temp[1024];
		swprintf_s(temp, 1024, L"PlayerName: '%s', PlayerPassword: '%s', Health: %f, Score: %f",
			Player->PlayerName.Data ? Player->PlayerName.Data : L"",			// Player->PlayerName.Data could be NULL in the case of an empty string.
			Player->PlayerPassword.Data ? Player->PlayerPassword.Data : L"",	// Player->PlayerPassword.Data could be NULL in the case of an empty string.
			Player->Health,
			Player->Score);
		MessageBox(0, temp, L"StructTest", MB_OK);
	}

	__declspec(dllexport) bool UpdatePassword(MyPlayerStruct* Player, wchar_t* NewPassword)
	{
		wchar_t temp[1024];
		swprintf_s(temp, 1024, L"ArrayMax is %d, new password is %s", Player->PlayerPassword.ArrayMax, NewPassword);
		MessageBox(0, temp, L"StructTest", MB_OK);

		// Check if there is enough memory allocated for the new password
		if(wcslen(NewPassword) >= (size_t)Player->PlayerPassword.ArrayMax)
			return false;

		wcscpy_s(Player->PlayerPassword.Data, Player->PlayerPassword.ArrayMax, NewPassword);

		// Update the ArrayNum variable to match the new data, so as not to confuse Unreal.
		Player->PlayerPassword.UpdateArrayNum();
		return true;
	}
}
