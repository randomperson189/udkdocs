class UTRadarGameInfo extends UTTeamGame;

defaultproperties
{
	HUDType=class'UTRadarHUD'
	bUseClassicHUD=true
}