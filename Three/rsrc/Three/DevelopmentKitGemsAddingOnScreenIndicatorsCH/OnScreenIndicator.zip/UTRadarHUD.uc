class UTRadarHUD extends UTTeamHUD;

struct SRadarInfo
{
	var UTPawn UTPawn;
	var MaterialInstanceConstant MaterialInstanceConstant;
	var bool DeleteMe;
	var Vector2D Offset;
	var float Opacity;
};

var array<SRadarInfo> RadarInfo;

function AddPostRenderedActor(Actor A)
{
	// Remove post render call for UTPawns as we don't want the name bubbles showing
	if (UTPawn(A) != None)
	{
		return;
	}

	Super.AddPostRenderedActor(A);
}

event PostRender()
{
	local int i, Index;
	local Vector WorldHUDLocation, ScreenHUDLocation, ActualPointerLocation, CameraViewDirection, PawnDirection, CameraLocation;
	local Rotator CameraRotation;
	local UTPawn UTPawn;
	local LinearColor TeamLinearColor;
	local float PointerSize;

	if (PlayerOwner == None || PlayerOwner.Pawn == None)
	{
		return;
	}

	// Set up the render delta
	RenderDelta = WorldInfo.TimeSeconds - LastHUDRenderTime;

	// Set all radar infos to delete if not found 
	for (i = 0; i < RadarInfo.Length; ++i)
	{
		RadarInfo[i].DeleteMe = true;
	}
	
	// Update the radar infos and see if we need to add or remove any
	ForEach DynamicActors(class'UTPawn', UTPawn)
	{
		if (UTPawn != PlayerOwner.Pawn)
		{
			Index = RadarInfo.Find('UTPawn', UTPawn);
			// This pawn was not found in our radar infos, so add it
			if (Index == INDEX_NONE && UTPawn.Health > 0)
			{
				i = RadarInfo.Length;
				RadarInfo.Length = RadarInfo.Length + 1;
				RadarInfo[i].UTPawn = UTPawn;
				RadarInfo[i].MaterialInstanceConstant = new () class'MaterialInstanceConstant';

				if (RadarInfo[i].MaterialInstanceConstant != None)
				{
					RadarInfo[i].MaterialInstanceConstant.SetParent(Material'GemOnscreenRadarContent.PointerMaterial');

					if (UTPawn.PlayerReplicationInfo != None && UTPawn.PlayerReplicationInfo.Team != None)
					{
						TeamLinearColor = (UTPawn.PlayerReplicationInfo.Team.TeamIndex == 0) ? Default.RedLinearColor : Default.BlueLinearColor;
						RadarInfo[i].MaterialInstanceConstant.SetVectorParameterValue('TeamColor', TeamLinearColor);
					}
					else
					{
						RadarInfo[i].MaterialInstanceConstant.SetVectorParameterValue('TeamColor', Default.DMLinearColor);
					}
				}

				RadarInfo[i].DeleteMe = false;
			}
			else if (UTPawn.Health > 0)
			{
				RadarInfo[Index].DeleteMe = false;
			}
		}
	}

	// Handle rendering of all of the radar infos
	PointerSize = Canvas.ClipX * 0.083f;
	PlayerOwner.GetPlayerViewPoint(CameraLocation, CameraRotation);
	CameraViewDirection = Vector(CameraRotation);

	for (i = 0; i < RadarInfo.Length; ++i)
	{
		if (!RadarInfo[i].DeleteMe)
		{
			if (RadarInfo[i].UTPawn != None && RadarInfo[i].MaterialInstanceConstant != None)
			{
				// Handle the opacity of the pointer. If the player cannot see this pawn,
				// then fade it out half way, otherwise if he can, fade it in
				if (WorldInfo.TimeSeconds - RadarInfo[i].UTPawn.LastRenderTime > 0.1f)
				{
					// Player has not seen this pawn in the last 0.1 seconds
					RadarInfo[i].Opacity = Lerp(RadarInfo[i].Opacity, 0.4f, RenderDelta * 4.f);
				}
				else
				{
					// Player has seen this pawn in the last 0.1 seconds
					RadarInfo[i].Opacity = Lerp(RadarInfo[i].Opacity, 1.f, RenderDelta * 4.f);
				}
				// Apply the opacity
				RadarInfo[i].MaterialInstanceConstant.SetScalarParameterValue('Opacity', RadarInfo[i].Opacity);

				// Get the direction from the player's pawn to the pawn
				PawnDirection = Normal(RadarInfo[i].UTPawn.Location - PlayerOwner.Pawn.Location);

				// Check if the pawn is in front of me
				if (PawnDirection dot CameraViewDirection >= 0.f)
				{
					// Get the world HUD location, which is just above the pawn's head
					WorldHUDLocation = RadarInfo[i].UTPawn.Location + (RadarInfo[i].UTPawn.GetCollisionHeight() * Vect(0.f, 0.f, 1.f));
					// Project the world HUD location into screen HUD location
					ScreenHUDLocation = Canvas.Project(WorldHUDLocation);

					// If the screen HUD location is more to the right, then swing it to the left
					if (ScreenHUDLocation.X > (Canvas.ClipX * 0.5f))
					{
						RadarInfo[i].Offset.X -= PointerSize * RenderDelta * 4.f;
					}
					else
					{
						// If the screen HUD location is more to the left, then swing it to the right
						RadarInfo[i].Offset.X += PointerSize * RenderDelta * 4.f;
					}
					RadarInfo[i].Offset.X = FClamp(RadarInfo[i].Offset.X, PointerSize * -0.5f, PointerSize * 0.5f);
				
					// Set the rotation of the material icon
					ActualPointerLocation.X = Clamp(ScreenHUDLocation.X, 8, Canvas.ClipX - 8) + RadarInfo[i].Offset.X;
					ActualPointerLocation.Y = Clamp(ScreenHUDLocation.Y - PointerSize + RadarInfo[i].Offset.Y, 8, Canvas.ClipY - 8 - PointerSize) + (PointerSize * 0.5f);
					RadarInfo[i].MaterialInstanceConstant.SetScalarParameterValue('Rotation', GetAngle(ActualPointerLocation, ScreenHUDLocation));

					// Draw the material pointer
					Canvas.SetPos(ActualPointerLocation.X - (PointerSize * 0.5f), ActualPointerLocation.Y - (PointerSize * 0.5f));
					Canvas.DrawMaterialTile(RadarInfo[i].MaterialInstanceConstant, PointerSize, PointerSize, 0.f, 0.f, 1.f, 1.f);
				}
				else
				{
					// Handle rendering the on screen indicator when the actor is behind the camera
					// Project the pawn's location
					ScreenHUDLocation = Canvas.Project(RadarInfo[i].UTPawn.Location);

					// Inverse the Screen HUD location
					ScreenHUDLocation.X = Canvas.ClipX - ScreenHUDLocation.X;

					// If the screen HUD location is on the right edge, then swing it to the left
					if (ScreenHUDLocation.X > (Canvas.ClipX - 8))
					{
						RadarInfo[i].Offset.X -= PointerSize * RenderDelta * 4.f;
						RadarInfo[i].Offset.X = FClamp(RadarInfo[i].Offset.X, PointerSize * -0.5f, PointerSize * 0.5f);
					}
					else if (ScreenHUDLocation.X < 8)
					{
						// If the screen HUD location is on the left edge, then swing it to the right
						RadarInfo[i].Offset.X += PointerSize * RenderDelta * 4.f;
						RadarInfo[i].Offset.X = FClamp(RadarInfo[i].Offset.X, PointerSize * -0.5f, PointerSize * 0.5f);
					}
					else
					{
						// If the screen HUD location is somewhere in the middle, then straighten it up
						RadarInfo[i].Offset.X = Lerp(RadarInfo[i].Offset.X, 0.f, 4.f * RenderDelta);
					}

					// Set the screen HUD location
					ScreenHUDLocation.X = Clamp(ScreenHUDLocation.X, 8, Canvas.ClipX - 8);
					ScreenHUDLocation.Y = Canvas.ClipY - 8;

					// Set the actual pointer location
					ActualPointerLocation.X = ScreenHUDLocation.X + RadarInfo[i].Offset.X;
					ActualPointerLocation.Y = ScreenHUDLocation.Y - (PointerSize * 0.5f);

					// Set the rotation of the material icon
					RadarInfo[i].MaterialInstanceConstant.SetScalarParameterValue('Rotation', GetAngle(ActualPointerLocation, ScreenHUDLocation));

					// Draw the material pointer
					Canvas.SetPos(ActualPointerLocation.X - (PointerSize * 0.5f), ActualPointerLocation.Y - (PointerSize * 0.5f));
					Canvas.DrawMaterialTile(RadarInfo[i].MaterialInstanceConstant, PointerSize, PointerSize, 0.f, 0.f, 1.f, 1.f);
				}
			}
		}
		else
		{
			// Null the variables previous stored so garbage collection can occur
			RadarInfo[i].UTPawn = None;
			RadarInfo[i].MaterialInstanceConstant = None;
			// Remove from the radar info array
			RadarInfo.Remove(i, 1);
			// Back step one, to maintain the for loop
			--i;
		}
	}

	// Setup the render delta
	LastHUDRenderTime = WorldInfo.TimeSeconds;
	Super.PostRender();
}

function float GetAngle(Vector PointB, Vector PointC)
{
	// Check if angle can easily be determined if it is up or down
	if (PointB.X == PointC.X)
	{
		return (PointB.Y < PointC.Y) ? Pi : 0.f;
	}

	// Check if angle can easily be determined if it is left or right
	if (PointB.Y == PointC.Y)
	{
		return (PointB.X < PointC.X) ? (Pi * 1.5f) : (Pi * 0.5f);
	}

	return (2.f * Pi) - atan2(PointB.X - PointC.X, PointB.Y - PointC.Y);
}

defaultproperties
{
}