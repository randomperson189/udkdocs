class HUDKismetSeqAct_RenderMaterial extends HUDKismetSeqAct_RenderObject
	DependsOn(HUDKismetSeqAct_RenderTexture);

// Condition to using actual size coordinates
var bool UsingActualSize;
// Condition to using relative size coordinates
var bool UsingRelativeSize;
// Condition to using actual position coordinates
var bool UsingActualPosition;
// Condition to using relative position coordinates
var bool UsingRelativePosition;

// Material to render. Overrided if the user sets the material variable link
var(RenderMaterial) Object Material;
// Actual size to render the material
var(RenderMaterial) IntPoint ActualSize<EditCondition=UsingActualSize>;
// Relative size, to the viewport resolution, to render the material
var(RenderMaterial) Vector2D RelativeSize<EditCondition=UsingRelativeSize>;
// Actual position to render the material
var(RenderMaterial) IntPoint ActualPosition<EditCondition=UsingActualPosition>;
// Relative position, to the viewport resolution, to render the material
var(RenderMaterial) Vector2D RelativePosition<EditCondition=UsingRelativePosition>;
// Rotation of the material to render
var(RenderMaterial) TextureRotation Rotation;
// Coordinates of the material to render
var(RenderMaterial) TextureCoords Coords;

function Render(Canvas Canvas)
{
	local IntPoint RenderPosition;
	local IntPoint RenderSize;
	local MaterialInterface RenderMaterial;
	local int UL;
	local int VL;
	local Rotator R;
	local SeqVar_Object SeqVar_Object;

	if (Canvas != None && (UsingActualSize || UsingRelativeSize) && (UsingActualPosition || UsingRelativePosition))
	{
		// Check if the user has set the material kismet node link
		if (VariableLinks[0].LinkedVariables.Length > 0)
		{
			SeqVar_Object = SeqVar_Object(VariableLinks[0].LinkedVariables[0]);

			if (SeqVar_Object != None)
			{
				if (MaterialInterface(SeqVar_Object.GetObjectValue()) != None)
				{
					RenderMaterial = MaterialInterface(SeqVar_Object.GetObjectValue());
				}
				else if (MaterialInstanceActor(SeqVar_Object.GetObjectValue()) != None)
				{
					RenderMaterial = MaterialInstanceActor(SeqVar_Object.GetObjectValue()).MatInst;
				}
			}
		}
		else
		{
			if (MaterialInterface(Material) != None)
			{
				RenderMaterial = MaterialInterface(Material);
			}
			else if (MaterialInstanceActor(Material) != None)
			{
				RenderMaterial = MaterialInstanceActor(Material).MatInst;
			}
		}

		if (RenderMaterial != None)
		{
			// Calculate the position
			if (UsingRelativePosition)
			{
				RenderPosition.X = Canvas.ClipX * RelativePosition.X;
				RenderPosition.Y = Canvas.ClipY * RelativePosition.Y;
			}
			else
			{
				RenderPosition = ActualPosition;
			}

			// Calculate the size
			if (UsingRelativeSize)
			{
				RenderSize.X = Canvas.ClipX * RelativeSize.X;
				RenderSize.Y = Canvas.ClipY * RelativeSize.Y;
			}
			else
			{
				RenderSize = ActualSize;
			}

			// Calculate the texture width
			UL = (Coords.UL == -1) ? 1.f : Coords.UL;
			// Calculate the texture height
			VL = (Coords.VL == -1) ? 1.f : Coords.VL;

			// Set the position to render
			Canvas.SetPos(RenderPosition.X, RenderPosition.Y);

			if (Rotation.Rotation == 0)
			{
				// Render the material normally
				Canvas.DrawMaterialTile(RenderMaterial, RenderSize.X, RenderSize.Y, Coords.U, Coords.V, UL, VL);
			}
			else
			{
				// Render the material rotated
				R.Pitch = 0;
				R.Yaw = Rotation.Rotation;
				R.Roll = 0;
				Canvas.DrawRotatedMaterialTile(RenderMaterial, R, RenderSize.X, RenderSize.Y, Coords.U, Coords.V, UL, VL, Rotation.Anchor.X, Rotation.Anchor.Y);
			}
		}
	}

	Super.Render(Canvas);
}

defaultproperties
{
	ObjName="Render Material"
	ObjCategory="ExtHUD"

	VariableLinks(0)=(ExpectedType=class'SeqVar_Object',LinkDesc="Material",PropertyName=Material)
}