class SeqAct_SetAmbientOcclusionEffectProperties extends SeqAct_SetPostProcessEffectProperties
	DependsOn(AmbientOcclusionEffect);

var() LinearColor OcclusionColor;
var() float OcclusionPower<UIMin=0.1|UIMax=20.0>;
var() float OcclusionScale<UIMin=0.0|UIMax=10.0>;
var() float OcclusionBias<UIMin=-1.0|UIMax=4.0>;
var() float MinOcclusion;
var() bool bAngleBasedSSAO;
var() float OcclusionRadius<UIMin=0.0|UIMax=256.0>;
var() EAmbientOcclusionQuality OcclusionQuality;
var() float OcclusionFadeoutMinDistance;
var() float OcclusionFadeoutMaxDistance;
var() float HaloDistanceThreshold;
var() float HaloDistanceScale;
var() float HaloOcclusion;
var() float EdgeDistanceThreshold;
var() float EdgeDistanceScale;
var() float FilterDistanceScale;
var() float HistoryConvergenceTime;
var() float HistoryWeightConvergenceTime;

event Activated()
{
	local array<PostProcessEffect> PostProcessEffects;
	local int i;
	local AmbientOcclusionEffect AmbientOcclusionEffect;

	GetPostProcessEffects(PostProcessEffects, class'AmbientOcclusionEffect');

	if (PostProcessEffects.Length > 0)
	{
		for (i = 0; i < PostProcessEffects.length; ++i)
		{
			AmbientOcclusionEffect = AmbientOcclusionEffect(PostProcessEffects[i]);

			if (AmbientOcclusionEffect != None)
			{
				AmbientOcclusionEffect.OcclusionColor = OcclusionColor;
				AmbientOcclusionEffect.OcclusionPower = OcclusionPower;
				AmbientOcclusionEffect.OcclusionScale = OcclusionScale;
				AmbientOcclusionEffect.OcclusionBias = OcclusionBias;
				AmbientOcclusionEffect.MinOcclusion = MinOcclusion;
				AmbientOcclusionEffect.bAngleBasedSSAO = bAngleBasedSSAO;
				AmbientOcclusionEffect.OcclusionRadius = OcclusionRadius;
				AmbientOcclusionEffect.OcclusionQuality = OcclusionQuality;
				AmbientOcclusionEffect.OcclusionFadeoutMinDistance = OcclusionFadeoutMinDistance;
				AmbientOcclusionEffect.OcclusionFadeoutMaxDistance = OcclusionFadeoutMaxDistance;
				AmbientOcclusionEffect.HaloDistanceThreshold = HaloDistanceThreshold;
				AmbientOcclusionEffect.HaloDistanceScale = HaloDistanceScale;
				AmbientOcclusionEffect.HaloOcclusion = HaloOcclusion;
				AmbientOcclusionEffect.EdgeDistanceThreshold = EdgeDistanceThreshold;
				AmbientOcclusionEffect.EdgeDistanceScale = EdgeDistanceScale;
				AmbientOcclusionEffect.FilterDistanceScale = FilterDistanceScale;
				AmbientOcclusionEffect.HistoryConvergenceTime = HistoryConvergenceTime;
				AmbientOcclusionEffect.HistoryWeightConvergenceTime = HistoryWeightConvergenceTime;
			}
		}
	}
}

defaultproperties
{
	ObjName="Set Ambient Occlusion Effect Properties"
	ObjCategory="Post Process"

	VariableLinks(0)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Occlusion Power",PropertyName=OcclusionPower)
	VariableLinks(1)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Occlusion Scale",PropertyName=OcclusionScale)
	VariableLinks(2)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Occlusion Bias",PropertyName=OcclusionBias)
	VariableLinks(3)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Min Occlusion",PropertyName=MinOcclusion)
	VariableLinks(4)=(ExpectedType=class'SeqVar_Bool',bHidden=true,LinkDesc="Angle Based SSAO",PropertyName=bAngleBasedSSAO)
	VariableLinks(5)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Occlusion Radius",PropertyName=OcclusionRadius)
	VariableLinks(6)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Occlusion Fadeout Min Distance",PropertyName=OcclusionFadeoutMinDistance)
	VariableLinks(7)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Occlusion Fadeout Max Distance",PropertyName=OcclusionFadeoutMaxDistance)
	VariableLinks(8)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Halo Distance Threshold",PropertyName=HaloDistanceThreshold)
	VariableLinks(9)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Halo Distance Scale",PropertyName=HaloDistanceScale)
	VariableLinks(10)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Halo Occlusion",PropertyName=HaloOcclusion)
	VariableLinks(11)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Edge Distance Threshold",PropertyName=EdgeDistanceThreshold)
	VariableLinks(12)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Edge Distance Scale",PropertyName=EdgeDistanceScale)
	VariableLinks(13)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Filter Distance Scale",PropertyName=FilterDistanceScale)
	VariableLinks(14)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="History Convergence Time",PropertyName=HistoryConvergenceTime)
	VariableLinks(15)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="History Weight Convergence Time",PropertyName=HistoryWeightConvergenceTime)
	
	OcclusionColor=(R=0.0,G=0.0,B=0.0,A=1.0)
	OcclusionPower=4.0
	OcclusionScale=20.0
	OcclusionBias=0
	MinOcclusion=.1
	OcclusionRadius=25.0
	OcclusionQuality=AO_Medium
	OcclusionFadeoutMinDistance=4000.0
	OcclusionFadeoutMaxDistance=4500.0
	HaloDistanceThreshold=40.0
	HaloDistanceScale=.1
	HaloOcclusion=.04
	EdgeDistanceThreshold=10.0
	EdgeDistanceScale=.003
	FilterDistanceScale=10.0
	HistoryConvergenceTime=0
	HistoryWeightConvergenceTime=.07
}