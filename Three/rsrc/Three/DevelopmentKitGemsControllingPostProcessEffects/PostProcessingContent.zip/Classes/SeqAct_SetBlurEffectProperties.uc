class SeqAct_SetBlurEffectProperties extends SeqAct_SetPostProcessEffectProperties
	DependsOn(BlurEffect);

var() float BlurKernelSize;

event Activated()
{
	local array<PostProcessEffect> PostProcessEffects;
	local int i;
	local BlurEffect BlurEffect;

	GetPostProcessEffects(PostProcessEffects, class'BlurEffect');

	if (PostProcessEffects.Length > 0)
	{
		for (i = 0; i < PostProcessEffects.length; ++i)
		{
			BlurEffect = BlurEffect(PostProcessEffects[i]);

			if (BlurEffect != None)
			{
				BlurEffect.BlurKernelSize = BlurKernelSize;
			}
		}
	}
}

defaultproperties
{
	ObjName="Set Blur Effect Properties"
	ObjCategory="Post Process"

	VariableLinks(0)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Blur Kernel Size",PropertyName=BlurKernelSize)
}