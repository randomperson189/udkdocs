class SeqAct_SetDOFAndBloomEffectProperties extends SeqAct_SetDOFEffectProperties
	DependsOn(DOFAndBloomEffect);

var() float BloomScale;
var() float BloomThreshold;
var() color BloomTint;
var() float BloomScreenBlendThreshold;
var() float BlurBloomKernelSize;
var() EDOFType DepthOfFieldType;
var() EDOFQuality DepthOfFieldQuality;
var() Texture2D BokehTexture;

function SetProperties(PostProcessEffect PostProcessEffect)
{
	local DOFAndBloomEffect DOFAndBloomEffect;

	Super.SetProperties(PostProcessEffect);
	DOFAndBloomEffect = DOFAndBloomEffect(PostProcessEffect);

	if (DOFAndBloomEffect != None)
	{
		DOFAndBloomEffect.BloomScale = BloomScale;
		DOFAndBloomEffect.BloomThreshold = BloomThreshold;
		DOFAndBloomEffect.BloomTint = BloomTint;
		DOFAndBloomEffect.BloomScreenBlendThreshold = BloomScreenBlendThreshold;
		DOFAndBloomEffect.BlurBloomKernelSize = BlurBloomKernelSize;
		DOFAndBloomEffect.DepthOfFieldType = DepthOfFieldType;
		DOFAndBloomEffect.DepthOfFieldQuality = DepthOfFieldQuality;
		DOFAndBloomEffect.BokehTexture = BokehTexture;
	}
}

defaultproperties
{
	ObjName="Set DOF And Bloom Effect Properties"
	ObjCategory="Post Process"

	BloomScale=1.0
	BloomThreshold=1.0
	BloomTint=(R=255,G=255,B=255)
	BloomScreenBlendThreshold=10
	BlurKernelSize=16.0
	BlurBloomKernelSize=16.0

	VariableLinks(8)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Bloom Scale",PropertyName=BloomScale)
	VariableLinks(9)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Bloom Threshold",PropertyName=BloomThreshold)
	VariableLinks(10)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Bloom Screen Blend Threshold",PropertyName=BloomScreenBlendThreshold)
	VariableLinks(11)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Blur Bloom Kernel Size",PropertyName=BlurBloomKernelSize)
}