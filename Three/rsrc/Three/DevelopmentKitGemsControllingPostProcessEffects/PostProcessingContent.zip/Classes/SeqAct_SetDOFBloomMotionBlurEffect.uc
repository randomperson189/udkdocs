class SeqAct_SetDOFBloomMotionBlurEffect extends SeqAct_SetDOFAndBloomEffectProperties
	DependsOn(DOFBloomMotionBlurEffect);

var() float MaxVelocity;
var() float MotionBlurAmount;
var() bool FullMotionBlur;
var() float CameraRotationThreshold;
var() float CameraTranslationThreshold;

function SetProperties(PostProcessEffect PostProcessEffect)
{
	local DOFBloomMotionBlurEffect DOFBloomMotionBlurEffect;

	Super.SetProperties(PostProcessEffect);
	DOFBloomMotionBlurEffect = DOFBloomMotionBlurEffect(PostProcessEffect);

	if (DOFBloomMotionBlurEffect != None)
	{
		DOFBloomMotionBlurEffect.MaxVelocity = MaxVelocity;
		DOFBloomMotionBlurEffect.MotionBlurAmount = MotionBlurAmount;
		DOFBloomMotionBlurEffect.FullMotionBlur = FullMotionBlur;
		DOFBloomMotionBlurEffect.CameraRotationThreshold = CameraRotationThreshold;
		DOFBloomMotionBlurEffect.CameraTranslationThreshold = CameraTranslationThreshold;
	}
}

defaultproperties
{
	ObjName="Set DOF, Bloom and Motion Blur Effect Properties"
	ObjCategory="Post Process"

	MotionBlurAmount=0.5f
	MaxVelocity=1.0f
	FullMotionBlur=true
	CameraRotationThreshold=90.0f
	CameraTranslationThreshold=10000.0f

	VariableLinks(12)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Max Velocity",PropertyName=MaxVelocity)
	VariableLinks(13)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Motion Blur Amount",PropertyName=MotionBlurAmount)
	VariableLinks(14)=(ExpectedType=class'SeqVar_Bool',bHidden=true,LinkDesc="Full Motion Blur",PropertyName=FullMotionBlur)
	VariableLinks(15)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Camera Rotation Threshold",PropertyName=CameraRotationThreshold)
	VariableLinks(16)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Camera Translation Threshold",PropertyName=CameraTranslationThreshold)
}