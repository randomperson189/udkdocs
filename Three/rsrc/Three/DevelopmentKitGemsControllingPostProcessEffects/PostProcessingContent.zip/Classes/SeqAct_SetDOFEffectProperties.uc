class SeqAct_SetDOFEffectProperties extends SeqAct_SetPostProcessEffectProperties
	DependsOn(DOFEffect)
	abstract;

var() float FalloffExponent;
var() float BlurKernelSize;
var() float MaxNearBlurAmount<DisplayName=MaxNear>;
var() float MinBlurAmount<DisplayName=Min>;
var() float MaxFarBlurAmount<DisplayName=MaxFar>;
var() EFocusType FocusType;
var() float FocusInnerRadius;
var() float FocusDistance;
var() vector FocusPosition;

event Activated()
{
	local array<PostProcessEffect> PostProcessEffects;
	local int i;	

	GetPostProcessEffects(PostProcessEffects);

	if (PostProcessEffects.Length > 0)
	{
		for (i = 0; i < PostProcessEffects.length; ++i)
		{
			SetProperties(PostProcessEffects[i]);
		}
	}
}

function SetProperties(PostProcessEffect PostProcessEffect)
{
	local DOFEffect DOFEffect;

	DOFEffect = DOFEffect(PostProcessEffect);

	if (DOFEffect != None)
	{
		DOFEffect.FalloffExponent = FalloffExponent;
		DOFEffect.BlurKernelSize = BlurKernelSize;
		DOFEffect.MaxNearBlurAmount = MaxNearBlurAmount;
		DOFEffect.MinBlurAmount = MinBlurAmount;
		DOFEffect.MaxFarBlurAmount = MaxFarBlurAmount;
		DOFEffect.FocusType = FocusType;
		DOFEffect.FocusInnerRadius = FocusInnerRadius;
		DOFEffect.FocusDistance = FocusDistance;
		DOFEffect.FocusPosition = FocusPosition;
	}
}

defaultproperties
{
	FocusType=FOCUS_Distance
	FocusDistance=800
	FocusInnerRadius=400
	FalloffExponent=2
	BlurKernelSize=2
	MaxNearBlurAmount=1
	MinBlurAmount=0
	MaxFarBlurAmount=1

	VariableLinks(0)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Falloff Exponent",PropertyName=FalloffExponent)
	VariableLinks(1)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Blur Kernel Size",PropertyName=BlurKernelSize)
	VariableLinks(2)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Max Near",PropertyName=MaxNearBlurAmount)
	VariableLinks(3)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Min",PropertyName=MinBlurAmount)
	VariableLinks(4)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Max Far",PropertyName=MaxFarBlurAmount)
	VariableLinks(5)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Focus Inner Radius",PropertyName=FocusInnerRadius)
	VariableLinks(6)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Focus Distance",PropertyName=FocusDistance)
	VariableLinks(7)=(ExpectedType=class'SeqVar_Vector',bHidden=true,LinkDesc="Focus Position",PropertyName=FocusPosition)
}