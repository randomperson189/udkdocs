class SeqAct_SetMotionBlurEffectProperties extends SeqAct_SetPostProcessEffectProperties
	DependsOn(MotionBlurEffect);

var() float MaxVelocity;
var() float MotionBlurAmount;
var() bool FullMotionBlur;
var() float CameraRotationThreshold;
var() float CameraTranslationThreshold;

event Activated()
{
	local array<PostProcessEffect> PostProcessEffects;
	local int i;
	local MotionBlurEffect MotionBlurEffect;

	GetPostProcessEffects(PostProcessEffects, class'MotionBlurEffect');

	if (PostProcessEffects.Length > 0)
	{
		for (i = 0; i < PostProcessEffects.length; ++i)
		{
			MotionBlurEffect = MotionBlurEffect(PostProcessEffects[i]);

			if (MotionBlurEffect != None)
			{
				MotionBlurEffect.MaxVelocity = MaxVelocity;
				MotionBlurEffect.MotionBlurAmount = MotionBlurAmount;
				MotionBlurEffect.FullMotionBlur = FullMotionBlur;
				MotionBlurEffect.CameraRotationThreshold = CameraRotationThreshold;
				MotionBlurEffect.CameraTranslationThreshold = CameraTranslationThreshold;
			}
		}
	}
}

defaultproperties
{
	ObjName="Set Motion Blur Effect Properties"
	ObjCategory="Post Process"

	MotionBlurAmount=0.5f
	MaxVelocity=1.0f
	FullMotionBlur=true
	CameraRotationThreshold=90.0f
	CameraTranslationThreshold=10000.0f

	VariableLinks(0)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Max Velocity",PropertyName=MaxVelocity)
	VariableLinks(1)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Motion Blur Amount",PropertyName=MotionBlurAmount)
	VariableLinks(2)=(ExpectedType=class'SeqVar_Bool',bHidden=true,LinkDesc="Full Motion Blur",PropertyName=FullMotionBlur)
	VariableLinks(3)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Camera Rotation Threshold",PropertyName=CameraRotationThreshold)
	VariableLinks(4)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Camera Translation Threshold",PropertyName=CameraTranslationThreshold)
}