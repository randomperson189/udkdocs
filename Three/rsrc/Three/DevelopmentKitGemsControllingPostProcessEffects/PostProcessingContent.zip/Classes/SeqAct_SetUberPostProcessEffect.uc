class SeqAct_SetUberPostProcessEffect extends SeqAct_SetPostProcessEffectProperties
	DependsOn(UberPostProcessEffect);

var() vector SceneShadows<DisplayName=Shadows>;
var() vector SceneHighLights<DisplayName=HighLights>;
var() vector SceneMidTones<DisplayName=MidTones>;
var() float SceneDesaturation<DisplayName=Desaturation>;
var() vector SceneColorize<DisplayName=Colorize>;
var() ETonemapperType TonemapperType;
var() float TonemapperRange;
var() float TonemapperToeFactor<DisplayName=ToeFactor>;
var() float TonemapperScale;
var() float MotionBlurSoftEdgeKernelSize<DisplayName=SoftEdgeKernelSize>;
var() bool bEnableImageGrain;
var() float SceneImageGrainScale;
var() float BloomWeightSmall<DisplayName=Weight Small>;
var() float BloomWeightMedium<DisplayName=Weight Medium>;
var() float BloomWeightLarge<DisplayName=Weight Large>;
var() float BloomSizeScaleSmall<DisplayName=Size Multiplier Small>;
var() float BloomSizeScaleMedium<DisplayName=Size Multiplier Medium>;
var() float BloomSizeScaleLarge<DisplayName=Size Multiplier Large>;
var() bool bScaleEffectsWithViewSize;

event Activated()
{
	local array<PostProcessEffect> PostProcessEffects;
	local int i;
	local UberPostProcessEffect UberPostProcessEffect;

	GetPostProcessEffects(PostProcessEffects, class'UberPostProcessEffect');

	if (PostProcessEffects.Length > 0)
	{
		for (i = 0; i < PostProcessEffects.length; ++i)
		{
			UberPostProcessEffect = UberPostProcessEffect(PostProcessEffects[i]);

			if (UberPostProcessEffect != None)
			{
				UberPostProcessEffect.SceneShadows = SceneShadows;
				UberPostProcessEffect.SceneHighLights = SceneHighLights;
				UberPostProcessEffect.SceneMidTones = SceneMidTones;
				UberPostProcessEffect.SceneDesaturation = SceneDesaturation;
				UberPostProcessEffect.SceneColorize = SceneColorize;
				UberPostProcessEffect.TonemapperType = TonemapperType;
				UberPostProcessEffect.TonemapperRange = TonemapperRange;
				UberPostProcessEffect.TonemapperToeFactor = TonemapperToeFactor;
				UberPostProcessEffect.TonemapperScale = TonemapperScale;
				UberPostProcessEffect.MotionBlurSoftEdgeKernelSize = MotionBlurSoftEdgeKernelSize;
				UberPostProcessEffect.bEnableImageGrain = bEnableImageGrain;
				UberPostProcessEffect.SceneImageGrainScale = SceneImageGrainScale;
				UberPostProcessEffect.BloomWeightSmall = BloomWeightSmall;
				UberPostProcessEffect.BloomWeightMedium = BloomWeightMedium;
				UberPostProcessEffect.BloomWeightLarge = BloomWeightLarge;
				UberPostProcessEffect.BloomSizeScaleSmall = BloomSizeScaleSmall;
				UberPostProcessEffect.BloomSizeScaleMedium = BloomSizeScaleMedium;
				UberPostProcessEffect.BloomSizeScaleLarge = BloomSizeScaleLarge;
				UberPostProcessEffect.bScaleEffectsWithViewSize = bScaleEffectsWithViewSize;
			}
		}
	}
}

defaultproperties
{
	ObjName="Set Uber Post Process Effect Properties"
	ObjCategory="Post Process"

    SceneShadows=(X=0.0,Y=0.0,Z=-0.003)
    SceneHighLights=(X=0.8,Y=0.8,Z=0.8)
    SceneMidTones=(X=1.3,Y=1.3,Z=1.3)
    SceneDesaturation=0.4
    SceneColorize=(X=1,Y=1,Z=1)
	bEnableImageGrain=false
	TonemapperScale=1.0
	SceneImageGrainScale=0.02
	TonemapperRange=8
	TonemapperToeFactor=1
	BloomWeightSmall=0
	BloomWeightMedium=1
	BloomWeightLarge=0
	BloomSizeScaleSmall=0.25
	BloomSizeScaleMedium=1
	BloomSizeScaleLarge=3

	VariableLinks(0)=(ExpectedType=class'SeqVar_Vector',bHidden=true,LinkDesc="Scene Shadows",PropertyName=SceneShadows)
	VariableLinks(1)=(ExpectedType=class'SeqVar_Vector',bHidden=true,LinkDesc="Scene HighLights",PropertyName=SceneHighLights)
	VariableLinks(2)=(ExpectedType=class'SeqVar_Vector',bHidden=true,LinkDesc="Scene MidTones",PropertyName=SceneMidTones)
	VariableLinks(3)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Scene Desaturation",PropertyName=SceneDesaturation)
	VariableLinks(4)=(ExpectedType=class'SeqVar_Vector',bHidden=true,LinkDesc="Scene Colorize",PropertyName=SceneColorize)
	VariableLinks(5)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Tonemapper Range",PropertyName=TonemapperRange)
	VariableLinks(6)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Tonemapper Toe Factor",PropertyName=TonemapperToeFactor)
	VariableLinks(7)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Tonemapper Scale",PropertyName=TonemapperScale)
	VariableLinks(8)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Motion Blur Soft Edge Kernel Size",PropertyName=MotionBlurSoftEdgeKernelSize)
	VariableLinks(9)=(ExpectedType=class'SeqVar_Bool',bHidden=true,LinkDesc="Enable Image Grain",PropertyName=bEnableImageGrain)
	VariableLinks(10)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Scene Image Grain Scale",PropertyName=SceneImageGrainScale)
	VariableLinks(11)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Bloom Weight Small",PropertyName=BloomWeightSmall)
	VariableLinks(12)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Bloom Weight Medium",PropertyName=BloomWeightMedium)
	VariableLinks(13)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Bloom Weight Large",PropertyName=BloomWeightLarge)
	VariableLinks(14)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Bloom Size Scale Small",PropertyName=BloomSizeScaleSmall)
	VariableLinks(15)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Bloom Size Scale Medium",PropertyName=BloomSizeScaleMedium)
	VariableLinks(16)=(ExpectedType=class'SeqVar_Float',bHidden=true,LinkDesc="Bloom Size Scale Large",PropertyName=BloomSizeScaleLarge)
	VariableLinks(17)=(ExpectedType=class'SeqVar_Bool',bHidden=true,LinkDesc="Scale Effects With View Size",PropertyName=bScaleEffectsWithViewSize)
}