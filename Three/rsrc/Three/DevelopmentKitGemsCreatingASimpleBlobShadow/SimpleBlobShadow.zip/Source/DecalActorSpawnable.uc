class DecalActorSpawnable extends DecalActorMovable;

defaultproperties
{
	bStatic=false
	bNoDelete=false
}