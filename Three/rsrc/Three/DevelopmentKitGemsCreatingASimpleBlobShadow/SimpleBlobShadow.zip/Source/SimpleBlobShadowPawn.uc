class SimpleBlobShadowPawn extends UTPawn
	placeable;

var PrivateWrite DecalActorSpawnable SimpleBlobShadowDecal;
var(Shadow) const DecalActorSpawnable SimpleBlobShadowDecalArchetype;

simulated function PostBeginPlay()
{
	local MaterialInstanceConstant DecalMaterialInstanceConstant;

	Super.PostBeginPlay();

	// Dedicated servers do not need to spawn the simple blob shadow
	if (WorldInfo.NetMode == NM_DedicatedServer)
	{
		return;
	}

	// No blob shadow archetype
	// The archetype was not the correct class type
	if (SimpleBlobShadowDecalArchetype == None)
	{
		return;
	}

	SimpleBlobShadowDecal = Spawn(SimpleBlobShadowDecalArchetype.Class, Self,, Location, Rot(49152, 0, 0), SimpleBlobShadowDecalArchetype);

	if (SimpleBlobShadowDecal != None)
	{		
		if (SimpleBlobShadowDecal.Decal != None && SimpleBlobShadowDecal.Decal.GetDecalMaterial() != None)
		{
			DecalMaterialInstanceConstant = new class'MaterialInstanceConstant';

			if (DecalMaterialInstanceConstant != None)
			{
				DecalMaterialInstanceConstant.SetParent(SimpleBlobShadowDecal.Decal.GetDecalMaterial());
				SimpleBlobShadowDecal.Decal.SetDecalMaterial(DecalMaterialInstanceConstant);
			}
		}

		Attach(SimpleBlobShadowDecal);
	}
}

defaultproperties
{
}