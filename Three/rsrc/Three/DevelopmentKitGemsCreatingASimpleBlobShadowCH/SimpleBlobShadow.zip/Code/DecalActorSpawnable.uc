class DecalActorSpawnable extends DecalActorMovable;

defaultproperties
{
	bStatic=false
	bNoDelete=false
	Name="Default__DecalActorSpawnable"
}