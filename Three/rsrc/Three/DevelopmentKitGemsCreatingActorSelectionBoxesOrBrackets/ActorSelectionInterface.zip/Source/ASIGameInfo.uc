class ASIGameInfo extends UTDeathMatch;

defaultproperties
{
	bUseClassicHUD=true
	HUDType=class'ASIHUD'
}