UDK PhysX Particle Mutator Instructions

1) To install this mutator copy the content over the installation of UDK.  The folder layout should match what you see in UDK.

2) Add "+ModEditPackages=PhysXMod" to the [UnrealEd.EditorEngine] section of UDKGame\Config\DefaultEngine.ini

3) When you run UDK the first time it should ask you if you want to build scripts.  Answer yes to this to build the mutator scripts

4) In order to enable NVIDIA GPU Hardware support for the particle simulation set the bDisablePhysXHardwareSupport flag to "False" in Engine\Config\BaseEngine.ini  

5) Run UDK, go into the Mutator menu and enable the "PhysX Weapons" mutator.

6) When you play the game you should see additional debris on weapon impact.

