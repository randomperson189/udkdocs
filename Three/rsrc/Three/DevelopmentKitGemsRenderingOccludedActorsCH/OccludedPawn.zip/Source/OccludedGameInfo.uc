class OccludedGameInfo extends UTDeathmatch;

defaultproperties
{
	DefaultPawnClass=class'OccludedPawn'
}