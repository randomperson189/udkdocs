class OccludedPawn extends UTPawn;

var(Pawn) const SkeletalMeshComponent OccludedMesh;

simulated function SetMeshVisibility(bool bVisible)
{
	Super.SetMeshVisibility(bVisible);

	if (OccludedMesh != None)
	{
		OccludedMesh.SetOwnerNoSee(!bVisible);
	}
}

simulated function SetCharacterMeshInfo(SkeletalMesh SkelMesh, MaterialInterface HeadMaterial, MaterialInterface BodyMaterial)
{
	Super.SetCharacterMeshInfo(SkelMesh, HeadMaterial, BodyMaterial);

	if (OccludedMesh != None)
	{
		OccludedMesh.SetSkeletalMesh(SkelMesh);
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=OPawnSkeletalMeshComponent
		Materials(0)=Material'OccludedPawnContent.OccludedMaterial'
		Materials(1)=Material'OccludedPawnContent.OccludedMaterial'
		DepthPriorityGroup=SDPG_Foreground // Render the occluded skeletal mesh in the foreground layer
		ShadowParent=WPawnSkeletalMeshComponent
		ParentAnimComponent=WPawnSkeletalMeshComponent
		bCacheAnimSequenceNodes=false
		AlwaysLoadOnClient=true
		AlwaysLoadOnServer=true
		bOwnerNoSee=true
		CastShadow=false // Casting shadows is not required
		BlockRigidBody=true
		bUpdateSkelWhenNotRendered=false
		bIgnoreControllersWhenNotRendered=true
		bUpdateKinematicBonesFromAnimation=true
		bCastDynamicShadow=false // Casting shadows is not required
		RBChannel=RBCC_Untitled3
		RBCollideWithChannels=(Untitled3=true)
		LightEnvironment=MyLightEnvironment
		bOverrideAttachmentOwnerVisibility=true
		bAcceptsDynamicDecals=false
		bHasPhysicsAssetInstance=true
		TickGroup=TG_PreAsyncWork
		MinDistFactorForKinematicUpdate=0.2f
		bChartDistanceFactor=true
		RBDominanceGroup=20
		MotionBlurScale=0.f
		bAllowAmbientOcclusion=false
		bUseOnePassLightingOnTranslucency=true
		bPerBoneMotionBlur=true
	End Object
	OccludedMesh=OPawnSkeletalMeshComponent
	Components.Add(OPawnSkeletalMeshComponent)

	CamOffset=(X=16.0,Y=64.0,Z=-52.0)
}