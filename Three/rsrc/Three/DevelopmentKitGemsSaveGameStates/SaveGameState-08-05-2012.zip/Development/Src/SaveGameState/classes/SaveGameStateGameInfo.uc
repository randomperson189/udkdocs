//=============================================================================
// SaveGameStateGameInfo: GameInfo used for testing the SaveGameState.
//
// This game info has an example of how you would use the SaveGameState
// code base within your game.
// 
// Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
//=============================================================================
class SaveGameStateGameInfo extends UTGame;

// Pending save game state file name
var private string PendingSaveGameFileName;
// Pending player pawn for the player controller to spawn when loading a game state
var Pawn PendingPlayerPawn;
// Save game state used for when streaming levels is waiting to be finished. This is cleared when streaming levels are completed.
var SaveGameState StreamingSaveGameState;

/* 
 * Initialize the game. The GameInfo's InitGame() function is called before any other scripts (including PreBeginPlay()), and is used by the GameInfo to initialize parameters and spawn its helper classes.
 *
 * @param		Options				Passed options from the command line
 * @param		ErrorMessage		Out going error messages
 */
event InitGame(string Options, out string ErrorMessage)
{
	Super.InitGame(Options, ErrorMessage);

	// Set the pending save game file name if required
	if (HasOption(Options, "SaveGameState"))
	{
		PendingSaveGameFileName = ParseOption(Options, "SaveGameState");
	}
	else
	{
		PendingSaveGameFileName = "";
	}
}

/**
 * Start the match - inform all actors that the match is starting, and spawn player pawns. Remember that StartMatch is called automatically if bDelayedStart is false and bWaitingToStartMatch is true within 
 * GameInfo::PostLogin(). If these variables don't make sense on your game type, remember to call StartMatch() yourself when the game should start. However, the code within this function may be moved around
 * as it only needs a valid PlayerController.
 */
function StartMatch()
{
	local SaveGameState SaveGameState;
	local PlayerController PlayerController;
	local int i;

	// Check if we need to load the game or not
	if (PendingSaveGameFileName != "")
	{
		// Instance the save game state
		SaveGameState = new () class'SaveGameState';
		if (SaveGameState == None)
		{
			return;
		}

		// Attempt to deserialize the save game state object from disk
		if (class'Engine'.static.BasicLoadObject(SaveGameState, PendingSaveGameFileName, true, class'SaveGameState'.const.SAVEGAMESTATE_REVISION))
		{
			// Synchrously load in any streaming levels
			if (SaveGameState.StreamingMapFileNames.Length > 0)
			{
				// Ask every player controller to load up the streaming map
				ForEach WorldInfo.AllControllers(class'PlayerController', PlayerController)
				{
					// Stream map files now
					for (i = 0; i < SaveGameState.StreamingMapFileNames.Length; ++i)
					{												
						PlayerController.ClientUpdateLevelStreamingStatus(Name(SaveGameState.StreamingMapFileNames[i]), true, true, true);
					}

					// Block everything until pending loading is done
					PlayerController.ClientFlushLevelStreaming();
				}

				// Store the save game state in StreamingSaveGameState
				StreamingSaveGameState = SaveGameState;
				// Start the looping timer which waits for all streaming levels to finish loading
				SetTimer(0.05f, true, NameOf(WaitingForStreamingLevelsTimer));
				return;
			}

			// Load the game state
			SaveGameState.LoadGameState();
		}

		// Send a message to all player controllers that we've loaded the save game state
		ForEach WorldInfo.AllControllers(class'PlayerController', PlayerController)
		{
			PlayerController.ClientMessage("Loaded save game state from "$PendingSaveGameFileName$".", 'System');
		}
	}

	Super.StartMatch();
}

function WaitingForStreamingLevelsTimer()
{
	local int i;
	local PlayerController PlayerController;

	for (i = 0; i < WorldInfo.StreamingLevels.Length; ++i)
	{
		// If any levels still have the load request pending, then return
		if (WorldInfo.StreamingLevels[i].bHasLoadRequestPending)
		{
			return;
		}
	}

	// Clear the looping timer
	ClearTimer(NameOf(WaitingForStreamingLevelsTimer));

	// Load the save game state
	StreamingSaveGameState.LoadGameState();
	// Clear it for garbage collection
	StreamingSaveGameState = None;

	// Send a message to all player controllers that we've loaded the save game state
	ForEach WorldInfo.AllControllers(class'PlayerController', PlayerController)
	{
		PlayerController.ClientMessage("Loaded save game state from "$PendingSaveGameFileName$".", 'System');
	}

	// Start the match
	Super.StartMatch();
}

/**
 * Restarts a controller
 *
 * @param		NewPlayer		Player to restart
 */
function RestartPlayer(Controller NewPlayer)
{
	local int Idx;
	local array<SequenceObject> Events;
	local SaveGameState_SeqEvent_SavedGameStateLoaded SavedGameStateLoaded;
	local LocalPlayer LP; 
	local PlayerController PC; 

	// Ensure that we have a controller
	if (NewPlayer == None)
	{
		return;
	}

	// If we have a pending player pawn, then just possess that one
	if (PendingPlayerPawn != None)
	{
		// Assign the pending player pawn as the new player's pawn
		NewPlayer.Pawn = PendingPlayerPawn;

		// Initialize and start it up
		if (PlayerController(NewPlayer) != None)
		{
			PlayerController(NewPlayer).TimeMargin = -0.1;
		}

		NewPlayer.Pawn.LastStartTime = WorldInfo.TimeSeconds;
		NewPlayer.Possess(NewPlayer.Pawn, false);		
		NewPlayer.ClientSetRotation(NewPlayer.Pawn.Rotation, true);

		if (!WorldInfo.bNoDefaultInventoryForPlayer)
		{
			AddDefaultInventory(NewPlayer.Pawn);
		}

		SetPlayerDefaults(NewPlayer.Pawn);

		// Activate saved game state loaded events
		if (WorldInfo.GetGameSequence() != None)
		{
			WorldInfo.GetGameSequence().FindSeqObjectsByClass(class'SaveGameState_SeqEvent_SavedGameStateLoaded', true, Events);
			for (Idx = 0; Idx < Events.Length; Idx++)
			{
				SavedGameStateLoaded = SaveGameState_SeqEvent_SavedGameStateLoaded(Events[Idx]);				
				if (SavedGameStateLoaded != None)
				{
					SavedGameStateLoaded.CheckActivate(NewPlayer, NewPlayer);
				}
			}
		}

		// Clear the pending pawn
		PendingPlayerPawn = None;
	}
	else // Otherwise spawn a new pawn for the player to possess
	{
		Super.RestartPlayer(NewPlayer);
	}

	// To fix custom post processing chain when not running in editor or PIE.
	PC = PlayerController(NewPlayer);
	if (PC != none)
	{
		LP = LocalPlayer(PC.Player); 

		if (LP != None) 
		{ 
			LP.RemoveAllPostProcessingChains(); 
			LP.InsertPostProcessingChain(LP.Outer.GetWorldPostProcessChain(), INDEX_NONE, true);

			if (PC.myHUD != None)
			{
				PC.myHUD.NotifyBindPostProcessEffects();
			}
		} 
	}
}

defaultproperties
{
	bDelayedStart=false
	bWaitingToStartMatch=true
	PlayerControllerClass=class'SaveGameStatePlayerController'
	DefaultPawnClass=class'SaveGameStatePawn'
}