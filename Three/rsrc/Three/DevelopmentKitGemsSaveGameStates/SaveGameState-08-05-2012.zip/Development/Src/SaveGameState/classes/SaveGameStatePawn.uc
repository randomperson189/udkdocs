//=============================================================================
// SaveGameStatePawn: Example a pawn using the save game state system
//
// This pawn is normally player controlled, and is able to save itself to the
// save game state. When the save game state is loaded, it will instance the
// pawn and get the player controller to possess it instead of spawning a 
// new pawn for the player.
// 
// Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
//=============================================================================
class SaveGameStatePawn extends UTPawn
	Implements(SaveGameStateInterface);

/**
 * Serializes the actor's data into JSon
 *
 * @return		JSon data representing the state of this actor
 */
function String Serialize()
{
	local JSonObject JSonObject;

	// Instance the JSonObject, abort if one could not be created
	JSonObject = new () class'JSonObject';
	if (JSonObject == None)
	{
		`Warn(Self$" could not be serialized for saving the game state.");
		return "";
	}

	// Serialize the path name so that it can be looked up later
	JSonObject.SetStringValue("Name", PathName(Self));

	// Serialize the object archetype, in case this needs to be spawned
	JSonObject.SetStringValue("ObjectArchetype", PathName(ObjectArchetype));

	// Save the location
	JSonObject.SetFloatValue("Location_X", Location.X);
	JSonObject.SetFloatValue("Location_Y", Location.Y);
	JSonObject.SetFloatValue("Location_Z", Location.Z);

	// Save the rotation
	JSonObject.SetIntValue("Rotation_Pitch", Rotation.Pitch);
	JSonObject.SetIntValue("Rotation_Yaw", Rotation.Yaw);
	JSonObject.SetIntValue("Rotation_Roll", Rotation.Roll);

	// If the controller is the player controller, then saved a flag to say that it should be repossessed by the player when we reload the game state
	JSonObject.SetIntValue("IsPlayerControlled", (PlayerController(Controller) != None) ? 1 : 0);

	// Send the encoded JSonObject
	return class'JSonObject'.static.EncodeJson(JSonObject);
}

/**
 * Deserializes the actor from the data given
 *
 * @param		Data		JSon data representing the differential state of this actor
 */
function Deserialize(JSonObject Data)
{
	local Vector SavedLocation;
	local Rotator SavedRotation;
	local SaveGameStateGameInfo SaveGameStateGameInfo;

	// Deserialize the location and set it
	SavedLocation.X = Data.GetFloatValue("Location_X");
	SavedLocation.Y = Data.GetFloatValue("Location_Y");
	SavedLocation.Z = Data.GetFloatValue("Location_Z");
	SetLocation(SavedLocation);

	// Deserialize the rotation and set it
	SavedRotation.Pitch = Data.GetIntValue("Rotation_Pitch");
	SavedRotation.Yaw = Data.GetIntValue("Rotation_Yaw");
	SavedRotation.Roll = Data.GetIntValue("Rotation_Roll");
	SetRotation(SavedRotation);

	// Deserialize if this was a player controlled pawn, if it was then tell the game info about it
	if (Data.GetIntValue("IsPlayerControlled") == 1)
	{
		SaveGameStateGameInfo = SaveGameStateGameInfo(WorldInfo.Game);
		if (SaveGameStateGameInfo != None)
		{
			SaveGameStateGameInfo.PendingPlayerPawn = Self;
		}
	}
}

defaultproperties
{
}