//=============================================================================
// SaveGameStatePlayerController: Player Controller used to test the 
// SaveGameState.
//
// This player controller has an example of how you would use the SaveGameState
// code base within your game.
// 
// Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
//=============================================================================
class SaveGameStatePlayerController extends UTPlayerController;

/**
 * This exec function will save the game state to the file name provided.
 *
 * @param		FileName		File name to save the SaveGameState to
 */
exec function SaveGameState(string FileName)
{
	local SaveGameState SaveGameState;

	// Instance the save game state
	SaveGameState = new () class'SaveGameState';
	if (SaveGameState == None)
	{
		return;
	}

	// Scrub the file name
	FileName = ScrubFileName(FileName);

	// Ask the save game state to save the game
	SaveGameState.SaveGameState();

	// Serialize the save game state object onto disk
	if (class'Engine'.static.BasicSaveObject(SaveGameState, FileName, true, class'SaveGameState'.const.SAVEGAMESTATE_REVISION))
	{
		// If successful then send a message
		ClientMessage("Saved game state to "$FileName$".", 'System');
	}
}

/**
 * This exec function will load the game state from the file name provided
 *
 * @param		FileName		File name of load the SaveGameState from
 */
exec function LoadGameState(string FileName)
{
	local SaveGameState SaveGameState;

	// Instance the save game state
	SaveGameState = new () class'SaveGameState';
	if (SaveGameState == None)
	{
		return;
	}

	// Scrub the file name
	FileName = ScrubFileName(FileName);

	// Attempt to deserialize the save game state object from disk
	if (class'Engine'.static.BasicLoadObject(SaveGameState, FileName, true, class'SaveGameState'.const.SAVEGAMESTATE_REVISION))
	{
		// Start the map with the command line parameters required to then load the save game state
		ConsoleCommand("start "$SaveGameState.PersistentMapFileName$"?Game="$SaveGameState.GameInfoClassName$"?SaveGameState="$FileName);
	}
}

/**
 * This function just scrubs the FileName to ensure that it is valid
 *
 * @param		FileName		Unscrubbed file name
 * @return						Returns the scrubbed file name
 */
function String ScrubFileName(string FileName)
{
	// Add the extension if it does not exist
	if (InStr(FileName, ".sav",, true) == INDEX_NONE)
	{
		FileName $= ".sav";
	}

	// If the file name has spaces, replace then with under scores
	FileName = Repl(FileName, " ", "_");

	return FileName;
}

defaultproperties
{
}