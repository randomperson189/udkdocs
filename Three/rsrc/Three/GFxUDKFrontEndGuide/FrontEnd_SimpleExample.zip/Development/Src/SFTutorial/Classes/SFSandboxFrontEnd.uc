class SFSandBoxFrontEnd extends GFxMoviePlayer
    config(ScaleformSandboxUI);

/** Reference to _root of the movie's (udk_manager.swf) stage. */
var GFxObject RootMC;

/** Reference to the manager MovieClip (_root.manager) where views will be attached. */
var GFxObject ManagerMC;

var bool bInitialized;

/** View declarations. */
var SFSandboxFrontEnd_MainMenu MainMenuView;
var SFSandboxFrontEnd_Options OptionsView;

/** Structure which defines a unique menu view to be loaded. */
struct ViewInfo
{
	/** Unique string. */
	var name ViewName;

    /** SWF content to be loaded. */
    var string SWFName;

    /** Dependant views that should be loaded if this view is displayed. */
    var array<name> DependantViews;
};

/** Array of all menu views to be loaded, defined in DefaultUI.ini. */
var config array<ViewInfo>			ViewData;

/** 
 *  Shadow of the AS view stack. Necessary to update ( View.OnTopMostView(false) ) views that
 *  alreday exist on the stack. 
 */
var array<SFSandboxFrontEnd_View>		ViewStack;

/**
 * An array of names of views which have been attachMovie()'d and loadMovie()'d. Views
 * are loaded based on their DependantViews array, defined in Default.ini.
 */
var array<name>						LoadedViews;

function bool Start(optional bool StartPaused = false)
{
	super.Start();
	Advance(0);

	if (!bInitialized)
	{
		ConfigFrontEnd();
	}

	LoadViews();
	return true;
}

/** 
 *  Configuration method which stores references to _root and
 *  _root.manager for use in attaching views.
 */
final function ConfigFrontEnd()
{ 
	`log("ConfigFrontEnd() executed.");
	RootMC = GetVariableObject("_root");
	ManagerMC = RootMC.GetObject("manager");

	bInitialized = true;
}

/** 
 *  Creates MovieClips in ManagerMC into which the views are loaded. These MovieClips
 *  are then stored in MenuViews for later manipulation.
 */
final function LoadViews()
{
	local byte i;
	for (i = 0; i < ViewData.Length; i++) 
	{
		`log("Loading View: "@ViewData[i].ViewName);
		LoadView( ViewData[i] );
	}
}

/** 
 *  Create a view using existing ViewInfo. 
 *
 *  @param InViewInfo, the data for the view which includes the SWFName and the name for the view.
 */
final function LoadView(ViewInfo InViewInfo)
{
	local ASValue asval;
	local array<ASValue> args;
	local GFxObject ViewContainer, ViewLoader;

	ViewContainer = ManagerMC.CreateEmptyMovieClip( String(InViewInfo.ViewName) $ "Container" );
	ViewLoader = ViewContainer.CreateEmptyMovieClip( String(InViewInfo.ViewName) );

	asval.Type = AS_String;
	asval.s = InViewInfo.SWFName;
	args[0] = asval;

	ViewContainer.SetVisible( false );
	ViewLoader.Invoke( "loadMovie", args );
	LoadedViews.AddItem( InViewInfo.ViewName );
	`log("Loaded View: "@InViewInfo.ViewName);
}

/** Pushes a view onto MenuManager.as view stack. */
function PushView(coerce SFSandboxFrontEnd_View targetView) 
{   
	`log("PushView() executed");
    ActionScriptVoid("pushStandardView"); 
}

final function PushViewByName(name TargetViewName, optional GFxUDKFrontEnd_Screen ParentView)
{
	`log( "GFxUDKFrontEnd::PushViewByName(" @ string(TargetViewName) @ ")",,'DevUI');    
	switch (TargetViewName)
	{
		case ( 'Options' ): 
			ConfigureTargetView( OptionsView ); 
			break;
		default:
			`log( "View ["$TargetViewName$"] not found." ,,'DevUI');  
			break;
	}
}

/** Pops a view from the view stack and handles update/close of existing views. */
function GFxObject PopView() 
{       
    if ( ViewStack.Length <= 1 ) 
    {
        return none;
    }

    // Remove the view from the stack in US so we know what's still on top.   
    ViewStack.Remove(ViewStack.Length-1, 1);     

    // Update the new top most view.    
    ViewStack[ViewStack.Length-1].OnTopMostView( false ); 

    return PopViewStub();
}

/** Pops a view from the MenuManager.as view stack. */
final function GFxObject PopViewStub() { return ActionScriptObject("popView"); }

final function ConfigureView(SFSandboxFrontEnd_View InView, name WidgetName, name WidgetPath)
{	
	`log("ConfigureView() executed");
	
	// All widget's found in the view's path will send their initCallBack events to the view's WidgetInitialized() handler.
    SetWidgetPathBinding(InView, WidgetPath);
	
    InView.MenuManager = self;
    InView.ViewName = WidgetName;
    InView.OnViewLoaded();
}

/** 
 * Activates, updates, and pushes a view on the stack if it is allowed.
 * This method is called when a view is created by name using PushViewByName().
 */
function ConfigureTargetView(SFSandboxFrontEnd_View TargetView)
{
	`log("ConfigureTargetView() executed");
    TargetView.OnViewActivated();
    TargetView.OnTopMostView( true );

    ViewStack.AddItem( TargetView );
    PushView( TargetView );      
}

event bool WidgetInitialized(name WidgetName, name WidgetPath, GFxObject Widget)
{    
	local bool bResult;
	bResult = false;

    switch(WidgetName)
    {           
        case ('MainMenu'):
            if (MainMenuView == none)
            {
				`log("MainMenuView widget callback received");
                MainMenuView = SFSandboxFrontEnd_MainMenu(Widget);
                ConfigureView(MainMenuView, WidgetName, WidgetPath);

                // Currently here because need to ensure MainMenuView has loaded.
                ConfigureTargetView(MainMenuView);                 
                bResult = true;
            }            
            break;
		case ('Options'):
            if (OptionsView == none)
            {
                OptionsView = SFSandboxFrontEnd_Options(Widget);
                ConfigureView(OptionsView, WidgetName, WidgetPath);
                bResult = true;
            }
            break;
        default:
            break;
    }
    return bResult;
}

defaultproperties
{    
	//Views
    WidgetBindings.Add((WidgetName="MainMenu",WidgetClass=class'SFSandboxFrontEnd_MainMenu'))
	WidgetBindings.Add((WidgetName="Options",WidgetClass=class'SFSandboxFrontEnd_Options'))

    bDisplayWithHudOff = true   
    TimingMode = TM_Real
    bInitialized = false
	MovieInfo=SwfMovie'SFSandbox.Manager'
	bPauseGameWhileActive = true
	bCaptureInput=true
	bIgnoreMouseInput=false
}