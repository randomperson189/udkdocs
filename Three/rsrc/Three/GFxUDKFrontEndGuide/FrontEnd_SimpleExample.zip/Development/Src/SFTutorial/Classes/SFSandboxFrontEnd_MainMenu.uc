class SFSandboxFrontEnd_MainMenu extends SFSandboxFrontEnd_Screen
	config(Scaleform);
	
/** These CLIK Widgets are setup in the WidgetInitialized() callback and bound in default properties. */
var GFxClikWidget OptionsButton;

/** Configures the view when it is first loaded. */
function OnViewLoaded()
{
	Super.OnViewLoaded();
}

/** 
 *  Update the view.  
 *  This method is called whenever the view is pushed or popped from the view stakc.
 */
function OnTopMostView(optional bool bPlayOpenAnimation = false)
{   		
	Super.OnTopMostView(bPlayOpenAnimation);    		          
}

function Select_Options()
{    
	MenuManager.PushViewByName('Options');
}

private final function OnOptionsButtonPress(GFxClikWidget.EventData ev)
{
	Select_Options(); 
}

/** Callback when a CLIK widget with enableInitCallback set to TRUE is initialized.  Returns TRUE if the widget was handled, FALSE if not. */
event bool WidgetInitialized(name WidgetName, name WidgetPath, GFxObject Widget)
{    
	local bool bWasHandled;
	bWasHandled = false;
	
    switch(WidgetName)
    {                 
        case ('optionsBtn'):
            OptionsButton = GFxClikWidget(Widget);
            OptionsButton.AddEventListener('CLIK_press', OnOptionsButtonPress);
            break;
		default:
			bWasHandled = false;
	}

	if (!bWasHandled)
	{
		bWasHandled = Super.WidgetInitialized(WidgetName, WidgetPath, Widget);  
	}
	return bWasHandled;
}

defaultproperties
{
	SubWidgetBindings.Add((WidgetName="optionsBtn",WidgetClass=class'GFxClikWidget'))
}