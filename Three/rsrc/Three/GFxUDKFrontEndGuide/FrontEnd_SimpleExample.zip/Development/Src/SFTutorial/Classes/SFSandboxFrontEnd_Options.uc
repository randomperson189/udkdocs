class SFSandboxFrontEnd_Options extends SFSandboxFrontEnd_Screen;

/** These CLIK Widgets are setup in the WidgetInitialized() callback and bound in default properties. */
var GFxClikWidget OKButton, CancelButton;

/** Configures the view when it is first loaded. */
function OnViewLoaded()
{
	Super.OnViewLoaded();
}

/** 
 *  Update the view.  
 *  This method is called whenever the view is pushed or popped from the view stakc.
 */
function OnTopMostView(optional bool bPlayOpenAnimation = false)
{   		
	Super.OnTopMostView(bPlayOpenAnimation);    		          
}

function Press_OK(GFxClikWidget.EventData ev)
{
    MoveBackImpl();
}

function Press_Cancel(GFxClikWidget.EventData ev)
{
	MoveBackImpl();
}

function MoveBackImpl()
{
    if (MenuManager != none)
    {
        MenuManager.PopView();        
    }
}

/** Callback when a CLIK widget with enableInitCallback set to TRUE is initialized.  Returns TRUE if the widget was handled, FALSE if not. */
event bool WidgetInitialized(name WidgetName, name WidgetPath, GFxObject Widget)
{    
	local bool bWasHandled;
	bWasHandled = false;
	
    switch(WidgetName)
    {                 
        case ('okBtn'):
            OKButton = GFxClikWidget(Widget);
            OKButton.AddEventListener('CLIK_press', Press_OK);
            break;
		case ('cancelBtn'):
			CancelButton = GFxClikWidget(Widget);
			CancelButton.AddEventListener('CLIK_press', Press_Cancel);
			break;
		default:
			bWasHandled = false;
	}

	if (!bWasHandled)
	{
		bWasHandled = Super.WidgetInitialized(WidgetName, WidgetPath, Widget);  
	}
	return bWasHandled;
}

defaultproperties
{
	SubWidgetBindings.Add((WidgetName="okBtn",WidgetClass=class'GFxClikWidget'))
	SubWidgetBindings.Add((WidgetName="cancelBtn",WidgetClass=class'GFxClikWidget'))
}