class SFSandboxFrontEnd_Screen extends SFSandboxFrontEnd_View
    config(ScaleformSandboxUI);

/** Title of the view. Defined in DefaultScaleformSandboxUI.ini. */
var config String ViewTitle;

defaultproperties
{
}