﻿import com.scaleformsandbox.udk.views.View;
import gfx.controls.Button;

class com.scaleformsandbox.udk.views.MainMenuView extends View
{     
	private var optionsBtn:Button;   

    public function MainMenuView() {
        super();
		trace("MainMenuView.as");
    }    
}