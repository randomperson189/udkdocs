﻿import com.scaleformsandbox.udk.views.View;
import gfx.controls.Button;

class com.scaleformsandbox.udk.views.OptionsView extends View
{     
	private var okBtn:Button;

    public function OptionsView() {
        super();
		trace("OptionsView.as");
    }    
}