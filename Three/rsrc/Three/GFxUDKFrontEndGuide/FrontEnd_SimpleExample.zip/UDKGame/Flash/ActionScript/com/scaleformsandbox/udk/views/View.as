﻿import gfx.core.UIComponent;
import flash.external.ExternalInterface;
 
class com.scaleformsandbox.udk.views.View extends UIComponent
{    
    public function View() 
	{         
        super();   		
    }  
}