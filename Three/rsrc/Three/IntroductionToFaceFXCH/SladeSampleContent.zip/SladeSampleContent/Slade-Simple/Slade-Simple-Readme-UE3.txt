The Slade-Maya sample content is for demo purposes.  It contains quite a few poses 
that are seldom used, and an overly complex face graph setup.  In particular, the 
Slade's eyelid setup can easily be replaced by bone poses that both rotate the eyes 
and move the eyelids. The eyelid setup's primary goal is to demonstrate the power of 
the Face Graph, which it does quite well.

The Slade-Simple sample content was created to give game developers a more 
practical example to use as a base.  The Slade-Simple-Batch-Export.txt file
and Slade-Simple_FG-setup.fxl files can be used to create an FXA file
that has a minimal facegraph setup for Slade, capable of lip-synchronization
and automatic gestures.
