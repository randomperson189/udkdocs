class ExampleGCStatsRead extends OnlineStatsRead;

const PROPERTY_FOOTSTEPS = 1;

defaultproperties
{
	ColumnIds.Empty
	ColumnIds(0)=PROPERTY_FOOTSTEPS
}