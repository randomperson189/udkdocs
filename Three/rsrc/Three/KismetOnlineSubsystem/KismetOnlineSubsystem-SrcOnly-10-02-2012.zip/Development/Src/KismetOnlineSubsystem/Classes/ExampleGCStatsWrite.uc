class ExampleGCStatsWrite extends OnlineStatsWrite;

const PROPERTY_FOOTSTEPS = 1;

defaultproperties
{
	Properties.Empty
	Properties(0)=(PropertyId=PROPERTY_FOOTSTEPS,Data=(Type=SDT_Int32))
}