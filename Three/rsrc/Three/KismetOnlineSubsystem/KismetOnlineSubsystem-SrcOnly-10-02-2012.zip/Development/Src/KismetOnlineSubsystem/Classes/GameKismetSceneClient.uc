/**
 * A GameKismetSceneClient is an interaction which watches when a game session ends. This is required to clean up all of the Kismet nodes that may have
 * bindings to the OnlineSubsystems
 *
 * Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
 */
class GameKismetSceneClient extends Interaction;

/**
 * Called when the current game session has ended. Cleans up all OnlineSubsystemBase Kismet nodes
 */
function NotifyGameSessionEnded()
{
	local Sequence GameSequence;
	local array<SequenceObject> SequenceObjects;
	local SeqAct_OnlineSubsystemBase SeqAct_OnlineSubsystemBase;
	local int i;
	local WorldInfo WorldInfo;

	// Get the world info
	WorldInfo = class'WorldInfo'.static.GetWorldInfo();
	if (WorldInfo == None)
	{
		return;
	}
	
	// Clean up all of the online subsystem base Kismet nodes
	GameSequence = WorldInfo.GetGameSequence();
	if (GameSequence != None)
	{
		GameSequence.FindSeqObjectsByClass(class'SeqAct_OnlineSubsystemBase', true, SequenceObjects);
		if (SequenceObjects.Length > 0)
		{
			for (i = 0; i < SequenceObjects.Length; ++i)
			{
				SeqAct_OnlineSubsystemBase = SeqAct_OnlineSubsystemBase(SequenceObjects[i]);
				if (SeqAct_OnlineSubsystemBase != None)
				{
					SeqAct_OnlineSubsystemBase.CleanUp(true);
				}
			}
		}
	}
}

defaultproperties
{
}