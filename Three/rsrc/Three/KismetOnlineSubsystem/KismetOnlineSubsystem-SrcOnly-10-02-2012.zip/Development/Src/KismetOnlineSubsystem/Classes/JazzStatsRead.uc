class JazzStatsRead extends OnlineStatsRead;

const LEADERBOARDS_SCORE = 1;

defaultproperties
{
	ColumnIds.Empty	
	ColumnIds(0)=LEADERBOARDS_SCORE
}