class JazzStatsWrite extends OnlineStatsWrite;

defaultproperties
{
	Properties.Empty
	Properties(0)=(PropertyId=1,Data=(Type=SDT_Int32))	// Kills
}