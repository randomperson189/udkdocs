/**
 * A Mobile Show Achievements UI Action is used to display the achievements UI.
 *
 * Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
 */
class SeqAct_Mobile_ShowAchievementsUI extends SeqAct_OnlineSubsystemBase
`if(`notdefined(USE_GAMECENTER))	
	abstract
	HideDropDown;
`else
	;

/**
 * Called when this sequence action should do something attached with a local user num
 */
protected function InternalOnActivated()
{
	local OnlineSubsystem OnlineSubsystem;

	// Get the online sub system
	OnlineSubSystem = class'GameEngine'.static.GetOnlineSubsystem();
	// Check that the online subsystem and player interface ex is accessible
	if (OnlineSubSystem != None && OnlineSubSystem.PlayerInterfaceEx != None)
	{
		OnlineSubSystem.PlayerInterfaceEx.ShowAchievementsUI(ProcessingPlayers[0].LocalUserNum);
		FinishedProcessPlayerIndex(true);
	}	
	else
	{
		FinishedProcessPlayerIndex(false);
	}
}
`endif

defaultproperties
{
	ObjName="Show Achievements UI"
}