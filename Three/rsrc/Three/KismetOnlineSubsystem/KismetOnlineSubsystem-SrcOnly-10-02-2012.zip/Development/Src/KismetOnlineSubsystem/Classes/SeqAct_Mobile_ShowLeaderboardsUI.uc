/**
 * A Mobile Show Leaderboards UI Action is used to display the leaderboards UI.
 *
 * Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
 */
class SeqAct_Mobile_ShowLeaderboardsUI extends SeqAct_OnlineSubsystemBase
`if(`notdefined(USE_GAMECENTER))
	abstract
	HideDropDown;
`else
	;

var() const class<OnlineStatsRead> OnlineStatsReadClass;

/**
 * Called when this sequence action should do something attached with a local user num
 */
protected function InternalOnActivated()
{
	local OnlineSubsystem OnlineSubsystem;
	local OnlineSuppliedUIInterface OnlineSuppliedUIInterface;
	local array<UniqueNetId> PlayerIds;
	local OnlineStatsRead OnlineStatsRead;
	local int i;

	// If this class is none, then abort 
	if (OnlineStatsReadClass == None)
	{
		return;
	}

	// Get the online sub system
	OnlineSubSystem = class'GameEngine'.static.GetOnlineSubsystem();
	// Check that the online subsystem is accessible
	if (OnlineSubSystem != None)
	{
		// Create the PlayerIds array from all the processing players array
		for (i = 0; i < ProcessingPlayers.Length; ++i)
		{
			PlayerIds.AddItem(ProcessingPlayers[i].LocalNetId);
		}

		// Get the online supplied UI interface
		OnlineSuppliedUIInterface = OnlineSuppliedUIInterface(OnlineSubSystem.GetNamedInterface('SuppliedUI'));
		if (OnlineSuppliedUIInterface != None)
		{
			// Instance the online stats read class
			OnlineStatsRead = new () OnlineStatsReadClass;
			if (OnlineStatsRead != None)
			{
				// Bind to the online stats UI delegate
				OnlineSuppliedUIInterface.AddShowOnlineStatsUICompleteDelegate(InternalOnShowOnlineStatsUIComplete);

				// Show the online stats UI
				OnlineSuppliedUIInterface.ShowOnlineStatsUI(PlayerIds, OnlineStatsRead);
				FinishedProcessPlayerIndex(true, true);
			}
		}
	}
	else
	{
		FinishedProcessPlayerIndex(false);
	}
}

/**
 * Delegate fired when the supplied stats UI is closed
 */
function InternalOnShowOnlineStatsUIComplete()
{
	// Activate the fourth output
	ForceActivateOutput(4);
}

/**
 * Called when this Kismet node should clean up all variable or delegate references so that garbage collection can occur
 *
 * @param		IsExiting			If exiting, then clean up everything
 */
function CleanUp(optional bool IsExiting)
{
	local OnlineSubsystem OnlineSubsystem;
	local OnlineSuppliedUIInterface OnlineSuppliedUIInterface;

	Super.CleanUp(IsExiting);

	if (IsExiting)
	{
		// Get the online sub system
		OnlineSubSystem = class'GameEngine'.static.GetOnlineSubsystem();
		// Check that the online subsystem is accessible
		if (OnlineSubSystem != None)
		{
			// Get the online supplied UI interface
			OnlineSuppliedUIInterface = OnlineSuppliedUIInterface(OnlineSubSystem.GetNamedInterface('SuppliedUI'));
			if (OnlineSuppliedUIInterface != None)
			{
				OnlineSuppliedUIInterface.ClearShowOnlineStatsUICompleteDelegate(InternalOnShowOnlineStatsUIComplete);
			}
		}
	}
}
`endif

defaultproperties
{
	ObjName="Show Leaderboards UI"

	OutputLinks(4)=(LinkDesc="Closed")
}