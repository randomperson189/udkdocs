/**
 * An Modify Online Stat Action is used to modify and upload stats.
 *
 * Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
 */
class SeqAct_ModifyOnlineStat extends SeqAct_OnlineSubsystemBase;

// Stat base struct
struct SStat
{
	var() Name LinkedVariableName;
	var() int StatId;
};

// Integer based stat
struct SIntStat extends SStat
{
	var() int Value;
};

// Float based stat
struct SFloatStat extends SStat
{
	var() float Value;
};

// What method does the user want to modify the stat
enum EModifyMethod
{
	MM_Set<DisplayName=Set>,
// ==========
// Steamworks
// ==========
`if(`isdefined(USE_STEAMWORKS))
	MM_Add<DisplayName=Add>,
	MM_Subtract<DisplayName=Subtract>,
`endif
};

// Online stats write class associated with the stats
var() class<OnlineStatsWrite> OnlineStatsWriteClass;
// ==========
// Steamworks
// ==========
`if(`isdefined(USE_STEAMWORKS))
// Online stats read class associated with the stats
var() class<OnlineStatsRead> OnlineStatsReadClass;
`endif
// Array of integer based stats
var() array<SIntStat> IntStats;
// Array of float based stats
var() array<SFloatStat> FloatStats;
// Method to modify the stat
var() EModifyMethod ModifyMethod;
// Session name
var() Name SessionName;

// Online stats write object instance
var protected OnlineStatsWrite OnlineStatsWrite;
// Online stats read object instance
var protected OnlineStatsRead OnlineStatsRead;

/**
 * Called when this sequence action should do something attached with a local user num
 */
protected function InternalOnActivated()
{
	// Abort if the online stats write class is none
	// Abort if there are no column ids
	if (OnlineStatsWriteClass == None || IntStats.Length <= 0)
	{
		return;
	}
	
// ==========
// Steamworks
// ==========
`if(`isdefined(USE_STEAMWORKS))
	// User wants to modify the stats using add or subtract
	if (ModifyMethod == MM_Add || ModifyMethod == MM_Subtract)
	{
		ReadOnlineStats();
	}
	// User wants to modify the stats by setting the value
	else
	{
`endif
		SetStatValue();
// ==========
// Steamworks
// ==========
`if(`isdefined(USE_STEAMWORKS))
	}
`endif
}

// ==========
// Steamworks
// ==========
`if(`isdefined(USE_STEAMWORKS))
/**
 * Called when the user wants to modify the stats using increment or decrement
 */
protected function ReadOnlineStats()
{
	local OnlineSubsystem OnlineSubsystem;
	local array<UniqueNetId> PlayerIds;

	// Attempt to read the online stats
	OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
	if (OnlineSubsystem != None && OnlineSubsystem.StatsInterface != None)
	{
		OnlineSubsystem.StatsInterface.AddReadOnlineStatsCompleteDelegate(InternalOnReadOnlineStatsComplete);

		PlayerIds.AddItem(ProcessingPlayers[0].LocalNetId);
		OnlineStatsRead = new () OnlineStatsReadClass;
		if (OnlineStatsRead != None)
		{
			OnlineSubsystem.StatsInterface.ReadOnlineStats(PlayerIds, OnlineStatsRead);
		}
	}
}

/**
 * Called when reading the online stats has finished
 *
 * @param		bWasSuccessful			True if reading the online stats succeeded
 */
function InternalOnReadOnlineStatsComplete(bool bWasSuccessful)
{
	local OnlineSubsystem OnlineSubsystem;
	local int i, ReadIntStatValue;
	local float ReadFloatStatValue;
	local SeqVar_Int SeqVar_Int;
	local SeqVar_Float SeqVar_Float;

	// If reading the stats is successful
	if (bWasSuccessful && OnlineStatsRead != None)
	{
		// Write stats
		OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
		if (OnlineSubsystem != None && OnlineSubsystem.StatsInterface != None)
		{		
			// Instance the stats write object
			OnlineStatsWrite = new () OnlineStatsWriteClass;
			if (OnlineStatsWrite != None)
			{
				// Modify the int stats write values
				for (i = 0; i < IntStats.Length; ++i)
				{
					OnlineStatsRead.GetIntStatValueForPlayer(ProcessingPlayers[0].LocalNetId, IntStats[i].StatId, ReadIntStatValue);

					// If this state has a variable name, then perform a look up
					if (IntStats[i].LinkedVariableName != '' && IntStats[i].LinkedVariableName != 'None')
					{
						ForEach LinkedVariables(class'SeqVar_Int', SeqVar_Int)
						{
							if (SeqVar_Int.VarName == IntStats[i].LinkedVariableName)
							{
								switch (ModifyMethod)
								{							
								case MM_Add:
									OnlineStatsWrite.SetIntStat(IntStats[i].StatId, ReadIntStatValue + SeqVar_Int.IntValue);
									break;

								case MM_Subtract:
									OnlineStatsWrite.SetIntStat(IntStats[i].StatId, ReadIntStatValue - SeqVar_Int.IntValue);
									break;

								default:
									break;
								}
							}
						}
					}
					// Otherwise use the value defined in the struct
					else
					{
						switch (ModifyMethod)
						{							
						case MM_Add:
							OnlineStatsWrite.SetIntStat(IntStats[i].StatId, ReadIntStatValue + IntStats[i].Value);
							break;

						case MM_Subtract:
							OnlineStatsWrite.SetIntStat(IntStats[i].StatId, ReadIntStatValue - IntStats[i].Value);
							break;

						default:
							break;
						}
					}
				}

				// Modify the float stats write values
				for (i = 0; i < FloatStats.Length; ++i)
				{
					OnlineStatsRead.GetFloatStatValueForPlayer(ProcessingPlayers[0].LocalNetId, FloatStats[i].StatId, ReadFloatStatValue);

					// If this state has a variable name, then perform a look up
					if (FloatStats[i].LinkedVariableName != '' && FloatStats[i].LinkedVariableName != 'None')
					{
						ForEach LinkedVariables(class'SeqVar_Float', SeqVar_Float)
						{
							if (SeqVar_Float.VarName == FloatStats[i].LinkedVariableName)
							{
								switch (ModifyMethod)
								{							
								case MM_Add:
									OnlineStatsWrite.SetFloatStat(FloatStats[i].StatId, ReadFloatStatValue + SeqVar_Float.FloatValue);
									break;

								case MM_Subtract:
									OnlineStatsWrite.SetFloatStat(FloatStats[i].StatId, ReadFloatStatValue - SeqVar_Float.FloatValue);
									break;

								default:
									break;
								}
							}
						}
					}
					// Otherwise use the value defined in the struct
					else
					{
						switch (ModifyMethod)
						{							
						case MM_Add:
							OnlineStatsWrite.SetFloatStat(FloatStats[i].StatId, ReadFloatStatValue + FloatStats[i].Value);
							break;

						case MM_Subtract:
							OnlineStatsWrite.SetFloatStat(FloatStats[i].StatId, ReadFloatStatValue - FloatStats[i].Value);
							break;

						default:
							break;
						}
					}
				}

				// Send the write request to the stat handler			
				if (OnlineSubsystem.StatsInterface.WriteOnlineStats(SessionName, ProcessingPlayers[0].LocalNetId, OnlineStatsWrite))
				{
					// Add the flush delegate
					OnlineSubsystem.StatsInterface.AddFlushOnlineStatsCompleteDelegate(InternalOnFlushOnlineStatsComplete);
					// Flush the online stats
					OnlineSubsystem.StatsInterface.FlushOnlineStats(SessionName);
				}
				// Activate the failed output link
				else
				{
					ForceActivateOutput(3);
				}
			}
		}
	}
	else
	{
		FinishedProcessPlayerIndex(bWasSuccessful);
	}
}
`endif

/**
 * Called when this Kismet node should just set the stats value
 */
protected function SetStatValue()
{
	local OnlineSubsystem OnlineSubsystem;	
	local int i;
	local SeqVar_Int SeqVar_Int;	
	local SeqVar_Float SeqVar_Float;

	// Write stats
	OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
	if (OnlineSubsystem != None && OnlineSubsystem.StatsInterface != None)
	{		
		// Instance the stats write object
		OnlineStatsWrite = new () OnlineStatsWriteClass;
		if (OnlineStatsWrite != None)
		{
			// Set the int stats write values
			for (i = 0; i < IntStats.Length; ++i)
			{
				// If this state has a variable name, then perform a look up
				if (IntStats[i].LinkedVariableName != '' && IntStats[i].LinkedVariableName != 'None')
				{
					ForEach LinkedVariables(class'SeqVar_Int', SeqVar_Int)
					{
						if (SeqVar_Int.VarName == IntStats[i].LinkedVariableName)
						{
							OnlineStatsWrite.SetIntStat(IntStats[i].StatId, SeqVar_Int.IntValue);
							break;
						}
					}
				}
				// Otherwise use the value defined in the struct
				else
				{
					OnlineStatsWrite.SetIntStat(IntStats[i].StatId, IntStats[i].Value);
					break;
				}
			}

			// Modify the float stats write values
			for (i = 0; i < FloatStats.Length; ++i)
			{
				// If this state has a variable name, then perform a look up
				if (FloatStats[i].LinkedVariableName != '' && FloatStats[i].LinkedVariableName != 'None')
				{
					ForEach LinkedVariables(class'SeqVar_Float', SeqVar_Float)
					{
						if (SeqVar_Float.VarName == FloatStats[i].LinkedVariableName)
						{
							OnlineStatsWrite.SetFloatStat(FloatStats[i].StatId, SeqVar_Float.FloatValue);
						}
					}
				}
				// Otherwise use the value defined in the struct
				else
				{
					OnlineStatsWrite.SetFloatStat(FloatStats[i].StatId, FloatStats[i].Value);
				}
			}

			// Send the write request to the stat handler		
			if (OnlineSubsystem.StatsInterface.WriteOnlineStats(SessionName, ProcessingPlayers[0].LocalNetId, OnlineStatsWrite))
			{
// ==========
// SteamWorks
// ==========
`if(`isdefined(USE_STEAMWORKS))
				// Add the flush delegates
				OnlineSubsystem.StatsInterface.AddFlushOnlineStatsCompleteDelegate(InternalOnFlushOnlineStatsComplete);
`endif
				// Flush the online stats
				OnlineSubsystem.StatsInterface.FlushOnlineStats(SessionName);
// ==========
// GameCenter
// ==========
`if(`isdefined(USE_GAMECENTER))
				// Clear all object refs
				OnlineStatsWrite = None;
				OnlineStatsRead = None;

				// Handle process player index
				FinishedProcessPlayerIndex(true);
`endif
			}
			// Activate the failed output link
			else
			{
				ForceActivateOutput(3);
			}
		}
	}
}

`if(`isdefined(USE_STEAMWORKS))
/**
 * Called when the stats flush operation has completed
 *
 * @param SessionName the name of the session having stats flushed for
 * @param bWasSuccessful true if the async action completed without error, false if there was an error
 */
function InternalOnFlushOnlineStatsComplete(Name InSessionName, bool bWasSuccessful)
{
	// Clear all object refs
	OnlineStatsWrite = None;
	OnlineStatsRead = None;

	// Handle process player index
	FinishedProcessPlayerIndex(bWasSuccessful);
}
`endif

/**
 * Called when this Kismet node should clean up all variable or delegate references so that garbage collection can occur
 *
 * @param		IsExiting			If exiting, then clean up everything
 */
function CleanUp(optional bool IsExiting)
{
// ==========
// SteamWorks
// ==========
`if(`isdefined(USE_STEAMWORKS))
	local OnlineSubsystem OnlineSubsystem;
	local int i, InPlayerIndex;

	// Grab the online subsystem and remove all delegate binds
	OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
	if (OnlineSubsystem != None && OnlineSubsystem.StatsInterface != None)
	{
		// There can only be 4 maximum split screen local players
		for (i = 0; i < 4; ++i)
		{
			// Get the player index
			InPlayerIndex = class'UIInteraction'.static.GetPlayerIndex(i);
			if (InPlayerIndex >= 0)
			{
				// Clear the delegates
				OnlineSubsystem.StatsInterface.ClearFlushOnlineStatsCompleteDelegate(InternalOnFlushOnlineStatsComplete);
				OnlineSubsystem.StatsInterface.ClearReadOnlineStatsCompleteDelegate(InternalOnReadOnlineStatsComplete);
			}
		}
	}
`endif

	// Clear the online stats write object
	OnlineStatsWrite = None;
	// Clear the online stats read object
	OnlineStatsRead = None;

	// Call the super just in case we are exiting
	Super.CleanUp(IsExiting);
}

defaultproperties
{
	SessionName="Game"
	ObjName="Modify Online Stat"	

	VariableLinks(1)=(ExpectedType=class'SeqVar_Int',LinkDesc="Stat Values")
}