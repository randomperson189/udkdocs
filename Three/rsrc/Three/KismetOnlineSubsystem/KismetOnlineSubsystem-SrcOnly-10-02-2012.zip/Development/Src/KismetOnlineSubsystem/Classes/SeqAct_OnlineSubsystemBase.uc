/**
 * An OnlineSubsystemBase action is an abstract Action which is used to call other online subsystem functions which require local user nums
 *
 * Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
 */
class SeqAct_OnlineSubsystemBase extends SequenceAction
	abstract
	HideDropDown;

struct SProcessingPlayer
{
	var byte LocalUserNum;
	var UniqueNetId LocalNetId;
};

var private bool IsProcessing;
var protected array<SProcessingPlayer> ProcessingPlayers;
var protected bool HasCreatedSceneClient;

/**
 * Called when this event is activated.
 */
event Activated()
{
	local SeqVar_Player SeqVar_Player;
	local bool AllPlayers;
	local array<int> PlayerIndices, ExistingPlayerIndices;
	local WorldInfo WorldInfo;
	local PlayerController PlayerController;
	local LocalPlayer LocalPlayer;
	local int i;
	local SProcessingPlayer ProcessingPlayer;
	local OnlineSubSystem OnlineSubSystem;
	local Sequence GameSequence;
	local array<SequenceObject> SequenceObjects;
	local SeqAct_OnlineSubsystemBase SeqAct_OnlineSubsystemBase;
	
	// Check if we need to insert the GameKismetSceneClient to watch for garbage collection events
	if (!HasCreatedSceneClient)
	{
		// Insert the game kismet scene client
		WorldInfo = GetWorldInfo();
		if (WorldInfo != None)
		{
			// Get the local player controller
			PlayerController = WorldInfo.GetALocalPlayerController();
			if (PlayerController != None)
			{
				LocalPlayer = LocalPlayer(PlayerController.Player);
				if (LocalPlayer != None && LocalPlayer.ViewportClient != None)
				{
					LocalPlayer.ViewportClient.InsertInteraction(new (LocalPlayer.ViewportClient) class'GameKismetSceneClient');
				}
			}
		}

		// Flag all SeqAct_OnlineSubsystemBase that the game kismet scene client has been created
		GameSequence = WorldInfo.GetGameSequence();
		if (GameSequence != None)
		{
			GameSequence.FindSeqObjectsByClass(class'SeqAct_OnlineSubsystemBase', true, SequenceObjects);
			if (SequenceObjects.Length > 0)
			{
				for (i = 0; i < SequenceObjects.Length; ++i)
				{
					SeqAct_OnlineSubsystemBase = SeqAct_OnlineSubsystemBase(SequenceObjects[i]);
					if (SeqAct_OnlineSubsystemBase != None)
					{
						SeqAct_OnlineSubsystemBase.NotifyGameKismetSceneClientCreated();
					}
				}
			}
		}
	}

	if (IsProcessing)
	{
		// Activate the Busy output
		ActivateOutputLink(1);
		return;
	}

	// Get the online subsystem
	OnlineSubSystem = class'GameEngine'.static.GetOnlineSubSystem();
	if (OnlineSubSystem == None || OnlineSubSystem.PlayerInterface == None)
	{
		return;
	}

	// Get the player indices
	ForEach LinkedVariables(class'SeqVar_Player', SeqVar_Player)
	{
		if (SeqVar_Player.bAllPlayers)
		{
			AllPlayers = true;
			break;
		}
		else
		{
			PlayerIndices.AddItem(SeqVar_Player.PlayerIdx);
		}
	}

	// Find the players that need to be processed
	WorldInfo = GetWorldInfo();
	if (WorldInfo != None)
	{
		// If all players is true, then iterate for each player
		if (AllPlayers)
		{
			ForEach WorldInfo.AllControllers(class'PlayerController', PlayerController)
			{
				LocalPlayer = LocalPlayer(PlayerController.Player);
				if (LocalPlayer != None)
				{
					// Create the processing player struct
					ProcessingPlayer.LocalUserNum = class'UIInteraction'.static.GetPlayerIndex(LocalPlayer.ControllerId);
					OnlineSubSystem.PlayerInterface.GetUniquePlayerId(ProcessingPlayer.LocalUserNum, ProcessingPlayer.LocalNetId);

					// Append the processing player struct to the processing players array
					ProcessingPlayers.AddItem(ProcessingPlayer);
				}
			}
		}
		// Otherwise iterate for each player index
		else if (PlayerIndices.Length > 0)
		{
			// Get all of the existing player indices first
			ForEach WorldInfo.AllControllers(class'PlayerController', PlayerController)
			{
				LocalPlayer = LocalPlayer(PlayerController.Player);
				if (LocalPlayer != None)
				{
					ExistingPlayerIndices.AddItem(class'UIInteraction'.static.GetPlayerIndex(LocalPlayer.ControllerId));
				}
			}

			for (i = 0; i < PlayerIndices.Length; ++i)
			{
				if (ExistingPlayerIndices.Find(PlayerIndices[i]) != INDEX_NONE)
				{
					// Create the processing player struct
					ProcessingPlayer.LocalUserNum = PlayerIndices[i];
					OnlineSubSystem.PlayerInterface.GetUniquePlayerId(ProcessingPlayer.LocalUserNum, ProcessingPlayer.LocalNetId);

					// Append the processing player struct to the processing players array
					ProcessingPlayers.AddItem(ProcessingPlayer);
				}
			}
		}

		// Process the first one
		if (ProcessingPlayers.Length > 0)
		{
			// Set processing to true
			IsProcessing = true;

			// Activate
			InternalOnActivated();
		}
	}

	// Activate the Out output
	ActivateOutputLink(0);
}

/**
 * Called when the Kismet node has finished processing for this player
 *
 * @param			bWasSuccessful				True if the Kismet node was successful in what it was doing
 * @param			bProcessedAllPlayers		True if this Kismet node processed all players in one go, rather then doing one player at a time
 */
protected function FinishedProcessPlayerIndex(bool bWasSuccessful, optional bool bProcessedAllPlayers)
{
	// Perform clean up of this Kismet node
	CleanUp();

	// Pop the first processing player index
	if (ProcessingPlayers.Length > 0)
	{
		// If processed all players, then remove all of them now
		if (bProcessedAllPlayers)
		{
			ProcessingPlayers.Remove(0, ProcessingPlayers.Length);
		}
		// Otherwise we've only processed one, so pop it off the top
		else
		{
			ProcessingPlayers.Remove(0, 1);
		}
	}

	// If there is still more player indices to process, process the next one
	if (ProcessingPlayers.Length > 0)
	{
		InternalOnActivated();
	}
	// Otherwise, this Kismet node has finished processing and should activate one of the outputs
	else
	{
		IsProcessing = false;
		ForceActivateOutput((bWasSuccessful) ? 2 : 3);
	}	
}

/**
 * Called when this sequence action should do something attached with a local user num
 */
protected function InternalOnActivated();

/**
 * Called when this Kismet node should clean up all variable or delegate references so that garbage collection can occur
 *
 * @param		IsExiting			If exiting, then clean up everything
 */
function CleanUp(optional bool IsExiting)
{
	// Clear processing players array
	if (IsExiting)
	{
		ProcessingPlayers.Remove(0, ProcessingPlayers.Length);
	}
}

/**
 * Called when a Kismet node has created the GameKismetSceneClient which is used to catch when the game session has finished and when game clean up should occur
 */
function NotifyGameKismetSceneClientCreated()
{
	HasCreatedSceneClient = true;
}

defaultproperties
{
`if(`isdefined(USE_STEAMWORKS))
	ObjCategory="Steamworks"
`elseif(`isdefined(USE_GAMECENTER))
	ObjCategory="Game Center"
`endif
	ObjColor=(R=0,G=63,B=127,A=255)

	bAutoActivateOutputLinks=false

	VariableLinks.Empty
	VariableLinks(0)=(ExpectedType=class'SeqVar_Player',LinkDesc="Player")

	OutputLinks(1)=(LinkDesc="Busy")
	OutputLinks(2)=(LinkDesc="Succeeded")
	OutputLinks(3)=(LinkDesc="Failed")
}