/**
 * A Read Online Stat Action is used to read online stats.
 *
 * Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
 */
class SeqAct_ReadOnlineStat extends SeqAct_OnlineSubsystemBase
// ==========
// GameCenter
// ==========
`if(`isdefined(USE_GAMECENTER))
	abstract
	HideDropdown;
`else
	;
//
enum EReadStatsMethod
{
	RST_ReadAll<DisplayName=Read all stats>,
	RST_ReadFriendsOnly<DisplayName=Read stats of friends>,
	RST_ReadByRank<DisplayName=Read stats by rank>,
	RST_ReadByRankAroundPlayer<DisplayName=Read stats around player>
};

//
struct SLinkedVariableName
{
	var() int StatId;
	var() Name LinkedVariableName;
};

// Class to use which reads the stats
var() class<OnlineStatsRead> OnlineStatsReadClass;
// Method to read stats
var() EReadStatsMethod ReadStatsMethod;
// If use a read stats ranked method, which starting rank index to use
var() int StartRankIndex;
// How many rows to read if using read stats rank or rank around player methods
var() int RowCount;
// Linked variables to output to
var() array<SLinkedVariableName> LinkedVariableNames;

// Online stats read object instance
var protected OnlineStatsRead OnlineStatsRead;
// Rank variable mapped to a Kismet variable
var int Rank;

/**
 * Called when this sequence action should do something attached with a local user num
 */
protected function InternalOnActivated()
{
	local OnlineSubSystem OnlineSubSystem;
	local array<UniqueNetId> PlayerIds;

	// Abort if the online stats read class is none
	// Abort if there are no column ids
	if (OnlineStatsReadClass == None || LinkedVariableNames.Length <= 0)
	{
		return;
	}
	
	// Request stats
	OnlineSubSystem = class'GameEngine'.static.GetOnlineSubSystem();
	if (OnlineSubSystem != None && OnlineSubSystem.StatsInterface != None)
	{		
		// Instance the online stats
		OnlineStatsRead = new () OnlineStatsReadClass;
		if (OnlineStatsRead != None)
		{
			// Free the stats
			OnlineSubsystem.StatsInterface.FreeStats(OnlineStatsRead);

			// Bind the read online stats delegate
			OnlineSubsystem.StatsInterface.AddReadOnlineStatsCompleteDelegate(InternalOnReadOnlineStatsComplete);

			switch (ReadStatsMethod)
			{					
			// Read stats for friends only
			case RST_ReadFriendsOnly:
				OnlineSubsystem.StatsInterface.ReadOnlineStatsForFriends(ProcessingPlayers[0].LocalUserNum, OnlineStatsRead);
				break;

			// Read stats by rank only
			case RST_ReadByRank:
				OnlineSubsystem.StatsInterface.ReadOnlineStatsByRank(OnlineStatsRead, StartRankIndex, RowCount);
				break;

			// Read stats around player
			case RST_ReadByRankAroundPlayer:
				OnlineSubsystem.StatsInterface.ReadOnlineStatsByRankAroundPlayer(ProcessingPlayers[0].LocalUserNum, OnlineStatsRead, RowCount);
				break;

				// Read all stats
			case RST_ReadAll:
			default:
				PlayerIds.AddItem(ProcessingPlayers[0].LocalNetId);
				OnlineSubsystem.StatsInterface.ReadOnlineStats(PlayerIds, OnlineStatsRead);
				break;
			}
		}
	}
}

/**
 * Notifies the interested party that the last stats read has completed
 *
 * @param bWasSuccessful true if the async action completed without error, false if there was an error
 */
function InternalOnReadOnlineStatsComplete(bool bWasSuccessful)
{
	local int i;
	local SeqVar_Int SeqVar_Int;
	local SeqVar_Float SeqVar_Float;

	if (OnlineStatsRead != None)
	{
		// Output the stat id for the processing player
		if (LinkedVariableNames.Length > 0)
		{
			for (i = 0; i < LinkedVariableNames.Length; ++i)
			{
				if (LinkedVariableNames[i].LinkedVariableName != '' && LinkedVariableNames[i].LinkedVariableName != 'None')
				{
					// Copy the int stats over to the sequence variable
					ForEach LinkedVariables(class'SeqVar_Int', SeqVar_Int)
					{
						if (SeqVar_Int.VarName == LinkedVariableNames[i].LinkedVariableName)
						{
							OnlineStatsRead.GetIntStatValueForPlayer(ProcessingPlayers[0].LocalNetId, LinkedVariableNames[i].StatId, SeqVar_Int.IntValue);
						}
					}

					// Copy the float stats over to the sequence variable
					ForEach LinkedVariables(class'SeqVar_Float', SeqVar_Float)
					{
						if (SeqVar_Float.VarName == LinkedVariableNames[i].LinkedVariableName)
						{
							OnlineStatsRead.GetFloatStatValueForPlayer(ProcessingPlayers[0].LocalNetId, LinkedVariableNames[i].StatId, SeqVar_Float.FloatValue);
						}
					}
				}
			}
		}

		// Output rank
		Rank = OnlineStatsRead.GetRankForPlayer(ProcessingPlayers[0].LocalNetId);
		// Populate the linked variables
		PopulateLinkedVariableValues();
	}

	// Finished processing players
	FinishedProcessPlayerIndex(bWasSuccessful);
	// Remove reference to online stats read 
	OnlineStatsRead = None;
}

/**
 * Called when this Kismet node should clean up all variable or delegate references so that garbage collection can occur
 *
 * @param		IsExiting			If exiting, then clean up everything
 */
function CleanUp(optional bool IsExiting)
{
	local OnlineSubsystem OnlineSubsystem;
	local int i, InPlayerIndex;

	// Grab the online subsystem and remove all delegate binds
	OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
	if (OnlineSubsystem != None && OnlineSubsystem.StatsInterface != None)
	{
		// There can only be 4 maximum split screen local players
		for (i = 0; i < 4; ++i)
		{
			// Get the player index
			InPlayerIndex = class'UIInteraction'.static.GetPlayerIndex(i);
			if (InPlayerIndex >= 0)
			{
				// Clear the delegates
				OnlineSubsystem.StatsInterface.ClearReadOnlineStatsCompleteDelegate(InternalOnReadOnlineStatsComplete);
			}
		}
	}

	// Clear the online stats read object
	OnlineStatsRead = None;

	// Call the super just in case we are exiting
	Super.CleanUp(IsExiting);
}
`endif

defaultproperties
{
	ObjName="Read Online Stat"

// ==========
// SteamWorks
// ==========
`if(`isdefined(USE_STEAMWORKS))
	StartRankIndex=1
	RowCount=50
`endif

	VariableLinks(1)=(ExpectedType=class'SeqVar_Int',LinkDesc="Stat Values",bWriteable=true)
	VariableLinks(2)=(ExpectedType=class'SeqVar_Int',LinkDesc="Rank",bWriteable=true,PropertyName=Rank)
}