/**
 * A Refresh Achievements Action is used to refresh all achievements.
 *
 * Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
 */
class SeqAct_RefreshAchievements extends SeqAct_OnlineSubsystemBase
`if(`notdefined(USE_STEAMWORKS))
	abstract
	HideDropDown;
`else
	;

/**
 * Called when this sequence action should do something attached with a local user num
 */
protected function InternalOnActivated()
{
	local OnlineSubSystem OnlineSubSystem;

	OnlineSubSystem = class'GameEngine'.static.GetOnlineSubSystem();
	if (OnlineSubSystem != None && OnlineSubSystem.PlayerInterface != None)
	{
		// Bind the delegate
		OnlineSubSystem.PlayerInterface.AddReadAchievementsCompleteDelegate(ProcessingPlayers[0].LocalUserNum, InternalOnReadAchievementsComplete);

		// Read all achievements 
		OnlineSubsystem.PlayerInterface.ReadAchievements(ProcessingPlayers[0].LocalUserNum);
	}
}

/**
 * Called when the async achievements read has completed
 *
 * @param TitleId the title id that the read was for (0 means current title)
 */
function InternalOnReadAchievementsComplete(int TitleId)
{
	FinishedProcessPlayerIndex(true);
}

/**
 * Called when this Kismet node should clean up all variable or delegate references so that garbage collection can occur
 *
 * @param		IsExiting			If exiting, then clean up everything
 */
function CleanUp(optional bool IsExiting)
{
	local OnlineSubsystem OnlineSubsystem;
	local int i, InPlayerIndex;

	// Grab the online subsystem and remove all delegate binds
	OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
	if (OnlineSubsystem != None && OnlineSubsystem.PlayerInterface != None)
	{
		// There can only be 4 maximum split screen local players
		for (i = 0; i < 4; ++i)
		{
			// Get the player index
			InPlayerIndex = class'UIInteraction'.static.GetPlayerIndex(i);
			if (InPlayerIndex >= 0)
			{
				// Clear the delegates
				OnlineSubsystem.PlayerInterface.ClearReadAchievementsCompleteDelegate(InPlayerIndex, InternalOnReadAchievementsComplete);
			}
		}
	}

	// Call the super just in case we are exiting
	Super.CleanUp(IsExiting);
}
`endif

defaultproperties
{
	ObjName="Refresh Achievements"
}