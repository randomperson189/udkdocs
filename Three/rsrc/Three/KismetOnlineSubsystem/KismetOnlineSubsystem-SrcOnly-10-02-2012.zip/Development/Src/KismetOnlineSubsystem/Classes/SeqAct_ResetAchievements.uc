/**
 * A Reset Achievements Action is used to reset all of the achievements earnt by the player.
 *
 * Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
 */
class SeqAct_ResetAchievements extends SeqAct_OnlineSubsystemBase
`if(`notdefined(USE_STEAMWORKS))
	abstract
	HideDropDown;
`else
	;

// If true, then achievements are also reset. Otherwise only stats are reset.
var() const bool ResetAchievements;

/**
 * Called when this sequence action should do something attached with a local user num
 */
protected function InternalOnActivated()
{
	local OnlineSubsystemSteamworks OnlineSubsystemSteamworks;
	local bool bWasSuccessful;

	OnlineSubsystemSteamworks = OnlineSubsystemSteamworks(class'GameEngine'.static.GetOnlineSubsystem());
	if (OnlineSubsystemSteamworks != None)
	{
		bWasSuccessful = OnlineSubsystemSteamworks.ResetStats(ResetAchievements);
	}
	else
	{
		bWasSuccessful = false;
	}

	FinishedProcessPlayerIndex(bWasSuccessful);
}
`endif

defaultproperties
{
`if(`isdefined(USE_STEAMWORKS))
	ResetAchievements=true
`endif
	ObjName="Reset Achievements/Stats"
}