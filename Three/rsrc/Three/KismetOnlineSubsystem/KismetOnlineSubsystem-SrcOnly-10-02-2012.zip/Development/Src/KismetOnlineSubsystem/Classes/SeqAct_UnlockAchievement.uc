/**
 * An UnlockAchievement Action is used to unlock an achievement.
 *
 * Copyright 1998-2012 Epic Games, Inc. All Rights Reserved.
 */
class SeqAct_UnlockAchievement extends SeqAct_OnlineSubsystemBase;

// Achievement Id that you want to unlock
var() int AchievementId;

// ==========
// GameCenter
// ==========
`if(`isdefined(USE_GAMECENTER))
// If true, then achivements that have already been unlocked, will still output the success link
var() bool AlwaysUnlockAchievement;
// Array of all downloads achievements
var protected array<AchievementDetails> DownloadedAchievements;
`endif

/**
 * Called when this sequence action should do something attached with a local user num
 */
protected function InternalOnActivated()
{
	local OnlineSubsystem OnlineSubsystem;

	// Connect to the online subsystem and link up the achievement delegates
	OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
	if (OnlineSubsystem != None && OnlineSubsystem.PlayerInterface != None)
	{
// ==========
// SteamWorks
// ==========
`if(`isdefined(USE_STEAMWORKS))
		// Begin unlocking the achievement
		BeginUnlockAchievement();

// ==========
// GameCenter
// ==========
`else
		// Game Center requires you to read the achievements list first, and then unlock the achievement.
		// Assign the read achievements delegate
		OnlineSubsystem.PlayerInterface.AddReadAchievementsCompleteDelegate(ProcessingPlayers[0].LocalUserNum, InternalOnReadAchievementsComplete);

		// Read all achievements 
		OnlineSubsystem.PlayerInterface.ReadAchievements(ProcessingPlayers[0].LocalUserNum);
`endif
	}
}

// ==========
// GameCenter
// ==========
`if(`isdefined(USE_GAMECENTER))
/**
 * Called when the async achievements read has completed.
 *
 * @param		TitleId			The title id that the read was for (0 means current title)
 */
protected function InternalOnReadAchievementsComplete(int TitleId)
{
	local OnlineSubsystem OnlineSubsystem;
	local int AchievementIndex;

	// Ensure we have an online subsystem, and an associated player interface
	OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
	if (OnlineSubsystem == None || OnlineSubsystem.PlayerInterface == None)
	{
		return;
	}

	// Read the achievements into the downloaded achievements array
	OnlineSubsystem.PlayerInterface.GetAchievements(ProcessingPlayers[0].LocalUserNum, DownloadedAchievements, TitleId);

	// Grab the achievement index
	AchievementIndex = DownloadedAchievements.Find('Id', AchievementId);

	// Unlock the achievement		
	if (AchievementIndex != INDEX_NONE)
	{
		// We haven't unlocked it yet, so start the unlock process
		if (!DownloadedAchievements[AchievementIndex].bWasAchievedOnline)
		{
			BeginUnlockAchievement();
		}
		// We've already unlocked it, so finish 
		else if (AlwaysUnlockAchievement)
		{
			InternalOnUnlockAchievementComplete(true);
		}
	}
}
`endif

/**
 * Called when unlocking the achievement should begin
 *
 * @param		AchievementId			Which achievement to unlock
 * @param		LocalUserNum			Local user index
 */
protected function BeginUnlockAchievement()
{
	local OnlineSubsystem OnlineSubsystem;

	// Grab the online subsystem
	OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
	if (OnlineSubsystem == None || OnlineSubsystem.PlayerInterface == None)
	{
		return;
	}

	// Assign the unlock achievement complete delegate
	OnlineSubsystem.PlayerInterface.AddUnlockAchievementCompleteDelegate(ProcessingPlayers[0].LocalUserNum, InternalOnUnlockAchievementComplete);
			
	// Start the unlocking process
	OnlineSubsystem.PlayerInterface.UnlockAchievement(ProcessingPlayers[0].LocalUserNum, AchievementId);
}

/**
 * Called when the achievement unlocking has completed
 *
 * @param		 bWasSuccessful			True if the async action completed without error, false if there was an error
 */
protected function InternalOnUnlockAchievementComplete(bool bWasSuccessful)
{
	// Finished unlocking this achievement
	FinishedProcessPlayerIndex(bWasSuccessful);
}

/**
 * Called when this Kismet node should clean up all variable or delegate references so that garbage collection can occur
 *
 * @param		IsExiting			If exiting, then clean up everything
 */
function CleanUp(optional bool IsExiting)
{
	local OnlineSubsystem OnlineSubsystem;
	local int i, InPlayerIndex;

	// Grab the online subsystem and remove all delegate binds
	OnlineSubsystem = class'GameEngine'.static.GetOnlineSubsystem();
	if (OnlineSubsystem != None && OnlineSubsystem.PlayerInterface != None)
	{
		// There can only be 4 maximum split screen local players
		for (i = 0; i < 4; ++i)
		{
			// Get the player index
			InPlayerIndex = class'UIInteraction'.static.GetPlayerIndex(i);
			if (InPlayerIndex >= 0)
			{
			// Clear the delegates
// ==========
// GameCenter
// ==========
`if(`isdefined(USE_GAMECENTER))
				OnlineSubsystem.PlayerInterface.ClearReadAchievementsCompleteDelegate(InPlayerIndex, InternalOnReadAchievementsComplete);
`endif
				OnlineSubsystem.PlayerInterface.ClearUnlockAchievementCompleteDelegate(InPlayerIndex, InternalOnUnlockAchievementComplete);
			}
		}
	}

	// Call the super just in case we are exiting
	Super.CleanUp(IsExiting);
}

defaultproperties
{
// ==========
// GameCenter
// ==========
`if(`isdefined(USE_GAMECENTER))
	AlwaysUnlockAchievement=true
`endif
	ObjName="Unlock Achievement"
	VariableLinks(1)=(ExpectedType=class'SeqVar_Int',LinkDesc="Achievement Id",PropertyName=AchievementId)
}