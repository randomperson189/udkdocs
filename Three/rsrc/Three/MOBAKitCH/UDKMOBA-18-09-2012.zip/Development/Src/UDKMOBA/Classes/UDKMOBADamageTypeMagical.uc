class UDKMOBADamageTypeMagical extends DamageType;
