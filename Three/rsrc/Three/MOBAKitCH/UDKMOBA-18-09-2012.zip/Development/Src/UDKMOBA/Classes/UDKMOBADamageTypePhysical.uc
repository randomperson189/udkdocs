class UDKMOBADamageTypePhysical extends DamageType;
