class UDKMOBADamageTypePure extends DamageType;
