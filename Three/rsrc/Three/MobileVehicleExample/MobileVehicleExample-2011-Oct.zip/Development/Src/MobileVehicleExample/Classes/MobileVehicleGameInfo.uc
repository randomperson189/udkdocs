class MobileVehicleGameInfo extends SimpleGame;

function RestartPlayer(Controller NewPlayer)
{
	local NavigationPoint StartSpot;
	local int Idx;
	local array<SequenceObject> Events;
	local SeqEvent_PlayerSpawned SpawnedEvent;
	local Vehicle Vehicle;

	if (bRestartLevel && WorldInfo.NetMode!= NM_DedicatedServer && WorldInfo.NetMode!= NM_ListenServer)
	{
		return;
	}

	StartSpot = FindPlayerStart(NewPlayer, 255);

	if (StartSpot == None)
	{
		if (NewPlayer.StartSpot != None)
		{
			StartSpot = NewPlayer.StartSpot;
		}
		else
		{
			return;
		}
	}

	if (NewPlayer.Pawn == None)
	{
		NewPlayer.Pawn = Spawn(class'MobileVehiclePawn',,, StartSpot.Location, StartSpot.Rotation);
	}

	if (NewPlayer.Pawn == None)
	{
		NewPlayer.GotoState('Dead');

		if (PlayerController(NewPlayer) != None)
		{
			PlayerController(NewPlayer).ClientGotoState('Dead', 'Begin');
		}
	}
	else
	{
		NewPlayer.Pawn.SetAnchor(StartSpot);

		if (PlayerController(NewPlayer) != None)
		{
			PlayerController(NewPlayer).TimeMargin = -0.1;
			StartSpot.AnchoredPawn = None;
		}

		NewPlayer.Pawn.LastStartSpot = PlayerStart(StartSpot);
		NewPlayer.Pawn.LastStartTime = WorldInfo.TimeSeconds;
		NewPlayer.Possess(NewPlayer.Pawn, false);
		NewPlayer.ClientSetRotation(NewPlayer.Pawn.Rotation, true);

		SetPlayerDefaults(NewPlayer.Pawn);

		if (WorldInfo.GetGameSequence() != None)
		{
			WorldInfo.GetGameSequence().FindSeqObjectsByClass(class'SeqEvent_PlayerSpawned', true, Events);

			for (Idx = 0; Idx < Events.Length; Idx++)
			{
				SpawnedEvent = SeqEvent_PlayerSpawned(Events[Idx]);

				if (SpawnedEvent != None && SpawnedEvent.CheckActivate(NewPlayer,NewPlayer))
				{
					SpawnedEvent.SpawnPoint = startSpot;
					SpawnedEvent.PopulateLinkedVariableValues();
				}
			}
		}

		NewPlayer.Pawn.SetCollision(false, false, false);
		Vehicle = Spawn(class'MobileVehicleScorpion',,, StartSpot.Location, StartSpot.Rotation);

		if (Vehicle != None)
		{
			Vehicle.TryToDrive(NewPlayer.Pawn);
		}
	}
}

defaultproperties
{
	HUDType=class'MobileVehicleHUD'
	PlayerControllerClass=class'MobileVehiclePlayerController'
}