class MobileVehicleHUD extends MobileHUDExt;

event PostRender()
{
	Super.PostRender();

	if (PlayerOwner != None && PlayerOwner.PlayerInput != None)
	{
		Canvas.SetDrawColor(255, 255, 255);
		Canvas.Font = class'Engine'.static.GetTinyFont();
		Canvas.SetPos(0, 0);
		Canvas.DrawText("aTilt in degrees = (Pitch = "$PlayerOwner.PlayerInput.aTilt.X * UnrRotToDeg$",Yaw = "$PlayerOwner.PlayerInput.aTilt.Y * UnrRotToDeg$",Roll = "$PlayerOwner.PlayerInput.aTilt.Z * UnrRotToDeg$")");
	}
}

defaultproperties
{
}