class MobileVehiclePawn extends SimplePawn;

event TickSpecial(float DeltaTime);

defaultproperties
{
}