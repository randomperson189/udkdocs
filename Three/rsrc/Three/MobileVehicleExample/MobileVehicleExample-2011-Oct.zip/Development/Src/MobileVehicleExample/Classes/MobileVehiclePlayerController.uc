class MobileVehiclePlayerController extends SimplePC;

function PlayerTick(float DeltaTime)
{
	Super(GamePlayerController).PlayerTick(DeltaTime);
}

state PlayerDriving
{
ignores SeePlayer, HearNoise, Bump;

	function ProcessMove(float DeltaTime, vector NewAccel, eDoubleClickDir DoubleClickMove, rotator DeltaRot);

	function ProcessDrive(float InForward, float InStrafe, float InUp, bool InJump)
	{
		local Vehicle CurrentVehicle;

		CurrentVehicle = Vehicle(Pawn);

		if (CurrentVehicle != None)
		{
			bPressedJump = InJump;
			CurrentVehicle.SetInputs(InForward, -InStrafe, InUp);
			CheckJumpOrDuck();
		}
	}

	function PlayerMove(float DeltaTime)
	{
		local float Forward, Strafe;

		UpdateRotation(DeltaTime);

		// Get the forward input information
		Forward = PlayerInput.aForward;
		// Get the strafe input information
		Strafe = PlayerInput.aStrafe;

		if (PlayerInput != None)
		{
			Forward = (((PlayerInput.aTilt.X * UnrRotToDeg) - 30.f) / 50.f) * -1.f;
			Strafe = (PlayerInput.aTilt.Z * UnrRotToDeg) / 20.f;
		}

		// Clamp the forward to within -1.f and 1.f
		Forward = FClamp(Forward, -1.f, 1.f);
		// Clamp the strafe to within -1.f and 1.f
		Strafe = FClamp(Strafe, -1.f, 1.f);

		ProcessDrive(Forward, Strafe, PlayerInput.aUp, bPressedJump);

		if (Role < ROLE_Authority)
		{
			ServerDrive(PlayerInput.aForward, PlayerInput.aStrafe, PlayerInput.aUp, bPressedJump, ((Rotation.Yaw & 65535) << 16) + (Rotation.Pitch & 65535));
		}

		bPressedJump = false;
	}

	event BeginState(Name PreviousStateName)
	{
		CleanOutSavedMoves();
	}

	event EndState(Name NextStateName)
	{
		CleanOutSavedMoves();
	}
}

defaultproperties
{
}