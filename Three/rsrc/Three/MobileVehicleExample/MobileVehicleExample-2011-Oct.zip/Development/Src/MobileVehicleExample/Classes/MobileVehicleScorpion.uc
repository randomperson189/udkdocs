class MobileVehicleScorpion extends SVehicle;

var DynamicLightEnvironmentComponent LightEnvironment;

defaultproperties
{
	Health=300
	COMOffset=(X=-40.f,Y=0.f,Z=-36.f)
	UprightLiftStrength=280.f
	UprightTime=1.25f
	UprightTorqueStrength=500.f
	bCanFlip=true
	bHasHandbrake=true
	GroundSpeed=950
	AirSpeed=1100
	HeavySuspensionShiftPercent=0.75f
	MomentumMult=0.5f
	NonPreferredVehiclePathMultiplier=1.5f
	DrawScale=1.2f
	bAlwaysRelevant=true
	SquealThreshold=0.1f
	SquealLatThreshold=0.f2f
	LatAngleVolumeMult=30.f
	EngineStartOffsetSecs=2.f
	EngineStopOffsetSecs=1.f
	bAttachDriver=false
	BaseEyeheight=30
	Eyeheight=30

	Begin Object Class=AudioComponent Name=ScorpionEngineSound
		SoundCue=SoundCue'MobileVehicleContent.Sounds.ScorpionEngineLoopSoundCue'
	End Object
	EngineSound=ScorpionEngineSound
	Components.Add(ScorpionEngineSound);

	Begin Object Class=AudioComponent Name=ScorpionSquealSound
		SoundCue=SoundCue'MobileVehicleContent.Sounds.ScorpionSlideSoundCue'
	End Object
	SquealSound=ScorpionSquealSound
	Components.Add(ScorpionSquealSound);

	CollisionSound=SoundCue'MobileVehicleContent.Sounds.ScorpionCollideSoundCue'
	EnterVehicleSound=SoundCue'MobileVehicleContent.Sounds.ScorpionStartSoundCue'

	Begin Object Name=CollisionCylinder
		BlockNonZeroExtent=false
		BlockZeroExtent=false
		BlockActors=false
		BlockRigidBody=false
		CollideActors=false
		CollisionHeight=40.f
		CollisionRadius=100.f
		Translation=(X=-25.f)
	End Object

	Begin Object Class=DynamicLightEnvironmentComponent Name=MyLightEnvironment
		bSynthesizeSHLight=true
		bIsCharacterLightEnvironment=true
		bUseBooleanEnvironmentShadowing=true
	End Object
	Components.Add(MyLightEnvironment)
	LightEnvironment=MyLightEnvironment

	Begin Object Name=SVehicleMesh
		CastShadow=true
		bCastDynamicShadow=true
		bOverrideAttachmentOwnerVisibility=true
		bAcceptsDynamicDecals=false
		bAllowAmbientOcclusion=false
		bPerBoneMotionBlur=true
		LightEnvironment=MyLightEnvironment
		SkeletalMesh=SkeletalMesh'MobileVehicleContent.SkeletalMeshes.ScorpionSkeletalMesh'
		AnimTreeTemplate=AnimTree'MobileVehicleContent.AnimTrees.ScorpionAnimTree'
		PhysicsAsset=PhysicsAsset'MobileVehicleContent.PhysicsAssets.ScorpionPhysicsAsset'
		AnimSets.Add(AnimSet'MobileVehicleContent.AnimSets.ScorpionAnimSet')
		RBCollideWithChannels=(Default=true,BlockingVolume=true,GameplayPhysics=true,EffectPhysics=true,Vehicle=true,Untitled4=true)
	End Object

	Begin Object Class=UDKVehicleSimCar Name=SimObject
		WheelSuspensionStiffness=100.f
		WheelSuspensionDamping=3.f
		WheelSuspensionBias=0.1f
		ChassisTorqueScale=0.f
		MaxBrakeTorque=5.f
		StopThreshold=100
		MaxSteerAngleCurve=(Points=((InVal=0.f,OutVal=45.f),(InVal=600.f,OutVal=15.f),(InVal=1100.f,OutVal=10.f),(InVal=1300.f,OutVal=6.f),(InVal=1600.f,OutVal=1.f)))
		SteerSpeed=110
		LSDFactor=0.f
		TorqueVSpeedCurve=(Points=((InVal=-600.f,OutVal=0.f),(InVal=-300.f,OutVal=80.f),(InVal=0.f,OutVal=130.f),(InVal=950.f,OutVal=130.f),(InVal=1050.f,OutVal=10.f),(InVal=1150.f,OutVal=0.f)))
		EngineRPMCurve=(Points=((InVal=-500.f,OutVal=2500.f),(InVal=0.f,OutVal=500.f),(InVal=549.f,OutVal=3500.f),(InVal=550.f,OutVal=1000.f),(InVal=849.f,OutVal=4500.f),(InVal=850.f,OutVal=1500.f),(InVal=1100.f,OutVal=5000.f)))
		EngineBrakeFactor=0.f25f
		ThrottleSpeed=0.2f
		WheelInertia=0.2f
		NumWheelsForFullSteering=4
		SteeringReductionFactor=0.f
		SteeringReductionMinSpeed=1100.f
		SteeringReductionSpeed=1400.f
		bAutoHandbrake=true
		bClampedFrictionModel=true
		FrontalCollisionGripFactor=0.18f
		ConsoleHardTurnGripFactor=1.f
		HardTurnMotorTorque=0.7f
		SpeedBasedTurnDamping=20.f
		AirControlTurnTorque=40.f
		InAirUprightMaxTorque=15.f
		InAirUprightTorqueFactor=-30.f
		WheelLongExtremumSlip=0.1f
		WheelLongExtremumValue=1.f
		WheelLongAsymptoteSlip=2.f
		WheelLongAsymptoteValue=0.6f
   		WheelLatExtremumSlip=0.35f
		WheelLatExtremumValue=0.9f
		WheelLatAsymptoteSlip=1.4f
		WheelLatAsymptoteValue=0.9f
		bAutoDrive=false
		AutoDriveSteer=0.3f
	End Object
	SimObj=SimObject
	Components.Add(SimObject)

	Begin Object Class=MobileVehicleScorpionWheel Name=RRWheel
		BoneName="B_R_Tire"
		BoneOffset=(X=0.f,Y=20.f,Z=0.f)
		SkelControlName="B_R_Tire_Cont"
	End Object
	Wheels(0)=RRWheel

	Begin Object Class=MobileVehicleScorpionWheel Name=LRWheel
		BoneName="B_L_Tire"
		BoneOffset=(X=0.f,Y=-20.f,Z=0.f)
		SkelControlName="B_L_Tire_Cont"
	End Object
	Wheels(1)=LRWheel

	Begin Object Class=MobileVehicleScorpionWheel Name=RFWheel
		BoneName="F_R_Tire"
		BoneOffset=(X=0.f,Y=20.f,Z=0.f)
		SteerFactor=1.f
		LongSlipFactor=2.f
		LatSlipFactor=3.f
		HandbrakeLongSlipFactor=0.8
		HandbrakeLatSlipFactor=0.8
		SkelControlName="F_R_Tire_Cont"
	End Object
	Wheels(2)=RFWheel

	Begin Object Class=MobileVehicleScorpionWheel Name=LFWheel
		BoneName="F_L_Tire"
		BoneOffset=(X=0.f,Y=-20.f,Z=0.f)
		SteerFactor=1.f
		LongSlipFactor=2.f
		LatSlipFactor=3.f
		HandbrakeLongSlipFactor=0.8f
		HandbrakeLatSlipFactor=0.8f
		SkelControlName="F_L_Tire_Cont"
	End Object
	Wheels(3)=LFWheel
}