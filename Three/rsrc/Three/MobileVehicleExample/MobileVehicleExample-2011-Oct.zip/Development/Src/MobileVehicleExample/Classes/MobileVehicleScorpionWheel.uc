class MobileVehicleScorpionWheel extends UDKVehicleWheel;

defaultproperties
{
	WheelRadius=27
	SuspensionTravel=40
	bPoweredWheel=true
	SteerFactor=0.0
	LongSlipFactor=2.0
	LatSlipFactor=2.75
	HandbrakeLongSlipFactor=0.7
	HandbrakeLatSlipFactor=0.3
	ParkedSlipFactor=10.0
}