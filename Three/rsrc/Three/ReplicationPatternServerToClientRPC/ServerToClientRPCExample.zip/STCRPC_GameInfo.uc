class STCRPC_GameInfo extends GameInfo;

/**
 * Post Begin Play is executed after the GameInfo is created
 *
 * Network: Dedicated/Listen Server
 */
function PostBeginPlay()
{
	Super.PostBeginPlay();

	// Set the timer which broad casts a random message to all players
	SetTimer(1.f, true, 'RandomBroadcast');
}

/**
 * Broadcast a random message to all players
 *
 * Network: Dedicated/Listen Server
 */
function RandomBroadcast()
{
	local STCRPC_PlayerController PlayerController;
	local int i;
	local string BroadcastMessage;

	if (WorldInfo != None)
	{
		// Constuct a random text message
		for (i = 0; i < 32; ++i)
		{
			BroadcastMessage $= Chr(Rand(255));
		}

		ForEach WorldInfo.AllControllers(class'STCRPC_PlayerController', PlayerController)
		{
			`Log(Self$":: Sending "$PlayerController$" a broadcast message which is '"$BroadcastMessage$"'.");
			PlayerController.ReceiveBroadcast(BroadcastMessage);
		}
	}
}

defaultproperties
{
	PlayerControllerClass=class'STCRPC_PlayerController'
}