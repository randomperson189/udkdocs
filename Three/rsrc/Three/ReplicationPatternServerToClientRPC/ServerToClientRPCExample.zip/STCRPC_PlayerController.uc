class STCRPC_PlayerController extends PlayerController;

/**
 * Client function which receives a broadcast from the server 
 * 
 * Network: Client
 */
reliable client function ReceiveBroadcast(String ReceivedText)
{
	`Log(Self$":: Server sent me '"$ReceivedText$"'.");
}

defaultproperties
{
}