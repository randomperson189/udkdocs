/*=============================================================================
	SourceControlIntegration.cpp: Interface for talking to source control clients
	Copyright � 2004-2005 Epic Games, Inc. All Rights Reserved.
=============================================================================*/

#include "UnrealEd.h"
#include "SourceControlIntegration.h"

/** Global pointer to the one and only SCC pointer */
FSourceControlIntegration* FSourceControlIntegration::GSourceControlIntegration = NULL;

/** 
 * Return a valid HWND for use with SCC. If we aren't running in UnrealEd, then
 * GApp is NULL.
 *
 * @return An HWND to act as the parent to the SCC windows.
 */
static inline HWND GetParentWindow()
{
	return GApp ? (HWND)GApp->EditorFrame->GetHandle() : GetConsoleWindow() ? GetConsoleWindow() : GetDesktopWindow();
}

/**
 * A pointer to this function is passed into SCC_OpenProject.  If the
 * SCC provider has anything to say, it pipes text messages through
 * here.
 */

long SCCTextOutput( LPCSTR InStr, DWORD InWord )
{
	FString wk = ANSI_TO_TCHAR( InStr );

	switch( InWord )
	{
		case SCC_MSG_DOCANCEL:
			return 0;

		case SCC_MSG_INFO:
		case SCC_MSG_STATUS:
			debugf( NAME_SourceControl, TEXT("%s"), *wk );
			break;

		case SCC_MSG_WARNING:
			debugf( NAME_SourceControl, TEXT("Warning: %s"), *wk );
			//appMsgf( AMT_OK, *wk );
			break;

		case SCC_MSG_ERROR:
			debugf( NAME_SourceControl, TEXT("ERROR: %s"), *wk );
			appMsgf( AMT_OK, *wk );
			break;
	}

	return SCC_MSG_RTN_OK;
}

FSourceControlIntegration::FSourceControlIntegration()
{
	// set the pointer to our singleton
	check(GSourceControlIntegration == NULL);
	GSourceControlIntegration = this;

	Init();

// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
	bErnestInformed = FALSE;
	bGetCanceled = FALSE;
	UpdateContent();
#endif // SCC_NXN_75
}

FSourceControlIntegration::~FSourceControlIntegration()
{
	if (bOpen == TRUE)
	{
		Close();
	}

	// we no longer have a singleton
	GSourceControlIntegration = NULL;

	// remove our Control-C handler
	SetConsoleCtrlHandler(ConsoleInterruptHandler, FALSE);

	if( LibraryHandle )
	{
		debugf( NAME_SourceControl, TEXT("Shutting down.") );
		SCC_Uninitialize( Context );
		appFreeDllHandle( LibraryHandle );
		LibraryHandle = NULL;
	}
}

FSourceControlIntegration* FSourceControlIntegration::GetGlobalSourceControlIntegration()
{
	return GSourceControlIntegration;
}

/** 
	*An interrupt function to delete the GSourceControlIntegration 
	* singleton if we get a control-c when in a console program 
	*/
UBOOL WINAPI FSourceControlIntegration::ConsoleInterruptHandler(DWORD /*ControlType*/)
{
	// if we get a control-c, we need to delete the singleton before killing the application so that 
	// it doesn't crash trying to use the global free, since it is constructed with our malloc
	delete FSourceControlIntegration::GetGlobalSourceControlIntegration();
	return FALSE;
}

/**
 * Gets a string out of the registry.
 *
 * @param	InMainKey	The primary key
 * @param	InKey		The secondary key
 *
 * @return	A char* buffer containing the string.  The caller is reponsible for freeing this!
 */
char* FSourceControlIntegration::GetRegistryString( char* InMainKey, char* InKey )
{
	HKEY Key = 0;
	char *Buffer = NULL;

	if( RegOpenKeyExA( HKEY_LOCAL_MACHINE, InMainKey, 0, KEY_READ, &Key ) == ERROR_SUCCESS )
	{
		DWORD Size = 0;

		// First, we'll call RegQueryValueEx to find out how large of a buffer we need

		RegQueryValueExA( Key, InKey, NULL, NULL, NULL, &Size );

		if( Size )
		{
			// Allocate a buffer to hold the value and call the function again to get the data

			Buffer = new char[Size];

			RegQueryValueExA( Key, InKey, NULL, NULL, (LPBYTE)Buffer, &Size );
		}

		RegCloseKey( Key );
	}

	return Buffer;
}

/**
 * Attempts to find the users SCC system, load the library associated with it and bind the functions.
 */
void FSourceControlIntegration::Init()
{
	bEnabled = 0;
	LibraryHandle = NULL;
	bOpen = 0;

	LoadFromINI();

	if (bDisabled)
		return;

	// Try to cache the firewall client if possible
	appGetDllHandle(TEXT("mswsock.dll"));
	appGetDllHandle(TEXT("dnsapi.dll"));
	appGetDllHandle(TEXT("winrnr.dll"));
	appGetDllHandle(TEXT("hnetcfg.dll"));
	appGetDllHandle(TEXT("wshtcpip.dll"));
	// Look up the path to the firewall stuff
	char* Buffer1 = GetRegistryString( "SOFTWARE\\Microsoft\\Firewall Client 2004", "InstallRoot" );
	if (Buffer1 != NULL)
	{
		FString Path(Buffer1);
		delete Buffer1;
		FString Path2(Path);
		Path += TEXT("FwcWsp.dll");
		Path2 += TEXT("FwcRes.dll");
		appGetDllHandle(*Path);
		appGetDllHandle(*Path2);
	}

	/**
	 * - Get the default SCC provider location from the reg key: HKEY_LOCAL_MACHINE\Software\SourceCodeControlProvider.
	 *
	 * - That value (hereafter called "SCCProviderLocation") is the location in the registry of the value we really want.  A new key
	 *   is then pieced together like this: HKEY_LOCAL_MACHINE\"SCCProviderLocation"\ProviderRegKey.  The value at that location
	 *   is the full path to the SCC providers DLL.
	 *
	 * - That DLL is loaded and the function pointers are bound to it.
	 */

	char* Buffer = GetRegistryString( STR_SCC_PROVIDER_REG_LOCATION, STR_PROVIDERREGKEY );

	if( Buffer )
	{
		char* DLLName = GetRegistryString( Buffer, STR_SCCPROVIDERPATH );

		if( DLLName )
		{
			LibraryHandle = appGetDllHandle( ANSI_TO_TCHAR( DLLName ) );
			if( !LibraryHandle )
			{
				debugf( NAME_Init, TEXT("Source Control : Couldn't locate %s - giving up.  Integration will be disabled."), ANSI_TO_TCHAR( DLLName ) );
				return;
			}

			// Bind function pointers

			SCC_GetVersion = (FuncSccGetVersion)appGetDllExport( LibraryHandle, TEXT("SccGetVersion") );
			SCC_Initialize = (FuncSccInitialize)appGetDllExport( LibraryHandle, TEXT("SccInitialize") );
			SCC_Uninitialize = (FuncSccUninitialize)appGetDllExport( LibraryHandle, TEXT("SccUninitialize") );
			SCC_GetProjPath = (FuncSccGetProjPath)appGetDllExport( LibraryHandle, TEXT("SccGetProjPath") );
			SCC_OpenProject = (FuncSccOpenProject)appGetDllExport( LibraryHandle, TEXT("SccOpenProject") );
			SCC_CloseProject = (FuncSccCloseProject)appGetDllExport( LibraryHandle, TEXT("SccCloseProject") );
			SCC_QueryInfo = (FuncSccQueryInfo)appGetDllExport( LibraryHandle, TEXT("SccQueryInfo") );
			SCC_History = (FuncSccHistory)appGetDllExport( LibraryHandle, TEXT("SccHistory") );
			SCC_CheckOut = (FuncSccCheckOut)appGetDllExport( LibraryHandle, TEXT("SccCheckout") );
			SCC_UncheckOut = (FuncSccUncheckOut)appGetDllExport( LibraryHandle, TEXT("SccUncheckout") );
			SCC_CheckIn = (FuncSccCheckIn)appGetDllExport( LibraryHandle, TEXT("SccCheckin") );
			SCC_Add = (FuncSccAdd)appGetDllExport( LibraryHandle, TEXT("SccAdd") );
			SCC_Remove = (FuncSccRemove)appGetDllExport( LibraryHandle, TEXT("SccRemove") );
			SCC_Rename = (FuncSccRename)appGetDllExport( LibraryHandle, TEXT("SccRename") );
// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
			SCC_Get = (FuncSccGet)appGetDllExport( LibraryHandle, TEXT("SccGet") );
			SCC_RunScc = (FuncSccRunScc)appGetDllExport( LibraryHandle, TEXT("SccRunScc") );
			SCC_PopulateList = (FuncSccPopulateList)appGetDllExport( LibraryHandle, TEXT("SccPopulateList") );
#endif // SCC_NXN_75

			// If we have all the bindings we need, source control integration is available.

			if( SCC_GetVersion
					&& SCC_Initialize
					&& SCC_Uninitialize
					&& SCC_GetProjPath
					&& SCC_OpenProject
					&& SCC_CloseProject
					&& SCC_QueryInfo
					&& SCC_History
					&& SCC_CheckOut
					&& SCC_UncheckOut
					&& SCC_CheckIn
					&& SCC_Add
					&& SCC_Remove
					&& SCC_Rename
// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
					&& SCC_Get
					&& SCC_RunScc
					&& SCC_PopulateList
#endif // SCC_NXN_75
					)
			{
				// Initialize
				if( SCC_Initialize( &Context, GetParentWindow(), "UnrealEd", ProviderName, &Caps, Label, &CheckOutCommentLen, &CommentLen ) == SCC_OK )
				{
					bSupportsRename = (Caps & SCC_CAP_RENAME) != 0;
					LONG ver = SCC_GetVersion();
					INT Lo = LOWORD(ver), Hi = HIWORD(ver);

					char* ProviderName = GetRegistryString( Buffer, STR_SCCPROVIDERNAME );

// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
					UBOOL bCorrectProvider = FALSE;
					char* regVersion = GetRegistryString( "SOFTWARE\\NxN\\alienbrain", "Version" );
					if (regVersion&&FString(ProviderName)==TEXT("Alienbrain"))
					{
						FString regVersionF = regVersion;
						regVersionF.Trim();
						delete [] regVersion;
						TArray<FString> params;
						regVersionF.ParseIntoArray(&params, TEXT("."), TRUE);
						if (params.Num()==4 && params(0).IsNumeric() && params(1).IsNumeric())// && params(2).IsNumeric() && params(3).IsNumeric())
						{
							INT v0 = _tstoi(*params(0));
							INT v1 = _tstoi(*params(1));
							//INT v2 = _tstoi(*params(2));
							//INT v3 = _tstoi(*params(3));
							bCorrectProvider = ((v0<<16)|v1) >= ((7<<16)|5); // check for version 7.5
						}
					}
					if (!bCorrectProvider)
					{
						// todo: if correct scc provider not found switch to use 'old Epic' scc integration
						bEnabled = 0;
						MessageBox(GetParentWindow(), TEXT("You need Visual Studio integration for NxN 7.5 or higher to use Advanced SCC Integration in UnrealEd."), TEXT("Advanced SCC Integration error"), MB_OK|MB_ICONINFORMATION|MB_TOPMOST);
						debugf( NAME_SourceControl, TEXT("Using provider - %s (API version: %d.%d) - NOT valid provider!!!"), ANSI_TO_TCHAR(ProviderName), Lo, Hi );
						delete [] ProviderName;
					}
					else
					{
#endif // SCC_NXN_75

					debugf( NAME_SourceControl, TEXT("Using provider - %s (API version: %d.%d)"), ANSI_TO_TCHAR(ProviderName), Lo, Hi );
					delete [] ProviderName;

					// Source control is ready for use!

					bEnabled = 1;
// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
					}
#endif // SCC_NXN_75
				}
				else
				{
					debugf( NAME_SourceControl, TEXT("Initialization failed!  Integration will be disabled.") );
				}
			}
			else
			{
				debugf( NAME_SourceControl, TEXT("Function bindings failed!  Integration will be disabled.") );
			}

			delete [] DLLName;
		}

		delete [] Buffer;
	}

	// make sure any Control-C handler is restored
	appSetConsoleInterruptHandler();
	// install our own Control-C handler to delete the SCC object
	// NOTE: This HAS to occur after the call to appSetConsoleInterruptHandler()
	SetConsoleCtrlHandler(ConsoleInterruptHandler, TRUE);
}

/**
 * Called when the user wants to connect to a different project.  Will pop
 * up the connection dialog and let them enter new info.
 */
void FSourceControlIntegration::GetProjPath()
{
	if( !IsEnabled() )
	{
		return;
	}

	// Get saved values from INI

	LoadFromINI();
	
	// Attempt to get info/log in.  If this fails, turn off integration.

	UBOOL bNew = 0;
	if( SCC_GetProjPath( Context, GetParentWindow(), UserName, ProjectPath, LocalPath, AuxProjectPath, 0, &bNew ) != SCC_OK )
	{
		debugf( NAME_SourceControl, TEXT("GetProjPath() failed - Integration will be disabled.") );
		bEnabled = 0;
	}
	else
	{
		// Write values back out to the INI

		SaveToINI();
	}
}

/**
 * Opens a project connection with the SCC.  Also handles logging the user in if they haven't been already.
 */
void FSourceControlIntegration::Open()
{
	if( !IsEnabled() || bOpen == TRUE )
	{
		return;
	}
	
	// Get saved values from INI
	LoadFromINI();
	
	// Attempt to get info/log in.  If this fails, turn off integration.
	SCCRTN ret = SCC_OpenProject( Context, GetParentWindow(), UserName, ProjectPath, LocalPath, AuxProjectPath, "", SCCTextOutput, SCC_OP_SILENTOPEN );
	if( ret != SCC_OK )
	{
		debugf( NAME_SourceControl, TEXT("Open() failed - Integration will be disabled.") );
		bEnabled = FALSE;
	}
	else
	{
		// Write values back out to the INI
		SaveToINI();
		bOpen = TRUE;
	}
}

/**
 * Closes the current project connection.
 */
void FSourceControlIntegration::Close()
{
	if( !IsEnabled() )
	{
		return;
	}

	// Project has to be open before calling this function.
	check( bOpen );

	SCC_CloseProject( Context );

	bOpen = 0;
}

/**
 * Loads user/SCC information from the INI file.
 */
void FSourceControlIntegration::LoadFromINI()
{
	// Init the values to their defaults

	ZeroMemory( UserName, SCC_USER_LEN );

// TODO: 10tacle, changed by Ernest SCC
#ifdef SCC_NXN_75
	ZeroMemory( LocalPath, SCC_PRJPATH_LEN );
#else
	strcpy( LocalPath, TCHAR_TO_ANSI(appBaseDir()) );
#endif // SCC_NXN_75

	ZeroMemory( ProjectPath, SCC_PRJPATH_LEN );
	ZeroMemory( AuxProjectPath, SCC_PRJPATH_LEN );

	// Attempt to read values from the INI file, only replacing the defaults if the value exists in the INI.

	FString Wk;

	if( GConfig->GetString( TEXT("SourceControl"), TEXT("UserName"), Wk, GEditorIni ) )
	{
		strcpy( UserName, TCHAR_TO_ANSI( *Wk ) );
	}

	if( GConfig->GetString( TEXT("SourceControl"), TEXT("LocalPath"), Wk, GEditorIni ) )
	{
		strcpy( LocalPath, TCHAR_TO_ANSI( *Wk ) );
	}

	if( GConfig->GetString( TEXT("SourceControl"), TEXT("ProjectPath"), Wk, GEditorIni ) )
	{
		strcpy( ProjectPath, TCHAR_TO_ANSI( *Wk ) );
	}

	if( GConfig->GetString( TEXT("SourceControl"), TEXT("AuxProjectPath"), Wk, GEditorIni ) )
	{
		strcpy( AuxProjectPath, TCHAR_TO_ANSI( *Wk ) );
	}

	bDisabled = false;
	GConfig->GetBool(TEXT("SourceControl"), TEXT("Disabled"), bDisabled, GEditorIni );

// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
	bDisableSccGet = false;
	GConfig->GetBool(TEXT("SourceControl"), TEXT("DisableSccGet"), bDisableSccGet, GEditorIni );
	bDisableUpdateMapsAndPackages = false;
	GConfig->GetBool(TEXT("SourceControl"), TEXT("DisableUpdateMapsAndPackages"), bDisableUpdateMapsAndPackages, GEditorIni );
#endif // SCC_NXN_75
}

/**
 * Stores user/SCC information in the INI file.  This saves the user from having to log in every
 * time they start up the editor.
 */
void FSourceControlIntegration::SaveToINI()
{
	GConfig->SetString( TEXT("SourceControl"), TEXT("UserName"), ANSI_TO_TCHAR( UserName ), GEditorIni );
	GConfig->SetString( TEXT("SourceControl"), TEXT("LocalPath"), ANSI_TO_TCHAR( LocalPath ), GEditorIni );
	GConfig->SetString( TEXT("SourceControl"), TEXT("ProjectPath"), ANSI_TO_TCHAR( ProjectPath ), GEditorIni );
	GConfig->SetString( TEXT("SourceControl"), TEXT("AuxProjectPath"), ANSI_TO_TCHAR( AuxProjectPath ), GEditorIni );
	GConfig->SetBool(	TEXT("SourceControl"), TEXT("Disabled"), bDisabled, GEditorIni);
// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
	GConfig->SetBool(TEXT("SourceControl"), TEXT("DisableSccGet"), bDisableSccGet, GEditorIni );
	GConfig->SetBool(TEXT("SourceControl"), TEXT("DisableUpdateMapsAndPackages"), bDisableUpdateMapsAndPackages, GEditorIni );
#endif // SCC_NXN_75
}

/**
 * Creates a fully qualified filename, including the path all the way back to the drive letter,
 * for the specific package.
 *
 * @param	PackageName	The name of the package (like "EngineMaterials")
 *
 * @return	The fully qualified filename
 */
FString FSourceControlIntegration::GetFullFilename(const TCHAR* PackageName)
{
	// Get the package's filename on the disk
	FFilename Filename;
	if (IsEnabled() && GPackageFileCache->FindPackageFile(PackageName, NULL, Filename))
	{
		return appConvertRelativePathToFull(Filename);
	}
	else
	{
		return TEXT("");
	}
}

/**
 * Creates a fully qualified filename, including the path all the way back to the drive letter,
 * for the specific package.
 *
 * @param	InPackage	The package we need the filename for
 *
 * @return	The fully qualified filename
 */
FString FSourceControlIntegration::GetFullFilename(UObject* InPackage)
{
	return GetFullFilename(InPackage->GetOutermost()->GetName());
}

/**
 * Updates the status flags for a set of packages.
 *
 * @param	InPackages	The packages to update status flags for
 */
void FSourceControlIntegration::Update( TArray<UPackage*>* InPackages )
{
	if (!IsEnabled())
	{
		return;
	}

	Open();

	INT NumFiles = 0;
	TArray<UPackage*> Packages;
	char** Filenames = GetFilenamesFromArray(InPackages, NumFiles, &Packages);

	if( NumFiles )
	{
		for( INT x = 0 ; x < NumFiles ; ++x )
		{
			Packages(x)->SetSCCState( SCC_DontCare );
		}

		LONG* StatusCodes = new LONG[NumFiles];
		if( SCC_QueryInfo( Context, NumFiles, (LPCSTR*)Filenames, StatusCodes ) == SCC_OK )
		{
			for( INT x = 0 ; x < NumFiles ; ++x )
			{
				if( StatusCodes[x] & SCC_STATUS_OUTBYUSER )
				{
					Packages(x)->SetSCCState( SCC_CheckedOut );
				}
				else
				{
					Packages(x)->SetSCCState( SCC_ReadOnly );

					if( StatusCodes[x] & SCC_STATUS_OUTOFDATE )
					{
						Packages(x)->SetSCCState( SCC_NotCurrent );
					}

					if( !StatusCodes[x] )
					{
						Packages(x)->SetSCCState( SCC_NotInDepot );
					}

					if( StatusCodes[x] & SCC_STATUS_OUTOTHER )
					{
						Packages(x)->SetSCCState( SCC_CheckedOutOther );
					}
				}
			}
		}

		delete [] Filenames;
		delete [] StatusCodes;
	}
}

/**
 * Creates an array of ANSI filenames from an array of packages.
 *
 * @param	InSrcPackages	The packages to get the filenames for
 * @param	InNumFiles		The number of filenames returned will be placed here
 * @param	InPackages		If this is non-NULL, this will be filled with the packages which correspond to each filename
 *
 * @return	A pointer to an array of ANSI filenames
 */

char** FSourceControlIntegration::GetFilenamesFromArray(const TArray<UPackage*>* InSrcPackages, INT& InNumFiles, TArray<UPackage*>* InPackages )
{
	if( !IsEnabled() )
	{
		return NULL;
	}

	TArray<UPackage*> SrcPackages = *InSrcPackages;

	// Prune the package list, removing any packages that we don't care about in terms of the SCC.
	FString Filename;
	for( INT x = 0 ; x < SrcPackages.Num() ; ++x )
	{
		UPackage* Package = SrcPackages(x);
		Filename = GetFullFilename(Package);
		if( Filename.Len() )
		{
			// - must be a top level package
			// - must not be named "MyLevel" or "Transient"
			// - filename on hard drive must not end with ".u"

			const TCHAR* PkgName = Package->GetName();
			const UBOOL bIsTopLevelPackage = ( Package->GetOuter() != NULL );
			const UBOOL bShouldRemove = ( bIsTopLevelPackage
											|| !appStricmp( PkgName, TEXT("MyLevel") )
											|| !appStricmp( PkgName, TEXT("Transient") )
											|| !appStricmp( *Filename.Right(2), TEXT(".u") ) );
			if ( bShouldRemove )
			{
				SrcPackages.Remove( x );
				x = -1;
			}
		}
		else
		{
			// If a filename can't be generated for this package, that means it has an invalid linker - which means
			// that it probably doesn't exist on the hard drive yet.
			Package->SetSCCState( SCC_NotInDepot );
			SrcPackages.Remove( x );
			x = -1;
		}
	}

	InNumFiles = SrcPackages.Num();

	char** Filenames = NULL;

	if( SrcPackages.Num() )
	{
		// Build the array of filenames

		Filenames = new char*[SrcPackages.Num()];

		FString Wk;
		for( INT x = 0 ; x < SrcPackages.Num() ; ++x )
		{
			Wk = *GetFullFilename( SrcPackages(x) );
			Filenames[x] = new char[ Wk.Len()+1 ];
			strcpy( Filenames[x], TCHAR_TO_ANSI( *Wk ) );

			if( InPackages )
			{
				InPackages->AddItem( SrcPackages(x) );
			}
		}
	}

	return Filenames;
}

/**
 * Displays the revision history for the specified set of packages.
 */
void FSourceControlIntegration::ShowHistory(const TArray<UPackage*>& Packages)
{
	if( !IsEnabled() )
	{
		return;
	}

	Open();

	INT NumFiles = 0;
	char** Filenames = GetFilenamesFromArray( &Packages, NumFiles, NULL );
	//char** Filenames = GetFilenames( NumFiles );

	if( Filenames )
	{
		SCCRTN ret = SCC_History( Context, GetParentWindow(), NumFiles, (LPCSTR*)Filenames, SCC_COMMAND_HISTORY, NULL );

		switch( ret )
		{
			case SCC_I_RELOADFILE:
				check(0);
				break;

			default:
				break;
		}

		// Clean up

		delete [] Filenames;
	}
}

/**
 * Checks a file out of the SCC depot.
 */
void FSourceControlIntegration::CheckOut(const TCHAR* PackageName)
{
	if (!IsEnabled())
	{
		return;
	}

	Open();

	FString FullName = GetFullFilename(PackageName);
	if (FullName.Len())
	{
		FTCHARToANSI Convert(*FullName);
		char* Filenames[2] = { (ANSICHAR*)Convert, NULL };

		SCC_CheckOut(Context, GetParentWindow(), 1, (LPCSTR*)Filenames, NULL, 0, NULL);
	}
}

/**
 * Checks a package file out of the SCC depot.
 */
void FSourceControlIntegration::CheckOut(UObject* InPackage)
{
	check(InPackage);
	CheckOut(InPackage->GetOutermost()->GetName());
}

/**
 * Reverts a file checked out of the SCC depot.
 */
void FSourceControlIntegration::UncheckOut(const TCHAR* PackageName)
{
	if( !IsEnabled() )
	{
		return;
	}

	Open();

	FString FullName = GetFullFilename(PackageName);
	if (FullName.Len())
	{
		FTCHARToANSI Convert(*FullName);
		char* Filenames[2] = { (ANSICHAR*)Convert, NULL };

		SCC_UncheckOut(Context, GetParentWindow(), 1, (LPCSTR*)Filenames, 0, NULL);
	}
}

/**
 * Reverts a package file checked out of the SCC depot.
 */
void FSourceControlIntegration::UncheckOut(UObject* InPackage)
{
	check(InPackage);
	UncheckOut(InPackage->GetOutermost()->GetName());
}

/**
 * Checks a file into the SCC depot.
 */
void FSourceControlIntegration::CheckIn(const TCHAR* PackageName)
{
	if( !IsEnabled() )
	{
		return;
	}

	Open();

	FString FullName = GetFullFilename(PackageName);
	if (FullName.Len())
	{
		FTCHARToANSI Convert(*FullName);
		char* Filenames[2] = { (ANSICHAR*)Convert, NULL };

		SCC_CheckIn(Context, GetParentWindow(), 1, (LPCSTR*)Filenames, NULL, 0, NULL);
	}
}

/**
 * Checks a package file into the SCC depot.
 */
void FSourceControlIntegration::CheckIn(UObject* InPackage)
{
	check(InPackage);
	CheckIn(InPackage->GetOutermost()->GetName());
}

/**
 * Adds a new file to the depot.
 *
 * A "gotcha" here is that the file must exist on the hard drive before this function will work (obviously),
 * so new files must be saved out before this will work.
 */
void FSourceControlIntegration::Add(const TCHAR* PackageName, UBOOL bIsBinary)
{
	if( !IsEnabled() )
	{
		return;
	}

	Open();

	FString FullName = GetFullFilename(PackageName);
	if (FullName.Len())
	{
		FTCHARToANSI Convert(*FullName);
		char* Filenames[2] = { (ANSICHAR*)Convert, NULL };
		LONG Flags[] = { bIsBinary ? SCC_FILETYPE_BINARY : SCC_FILETYPE_TEXT };

		SCC_Add(Context, GetParentWindow(), 1, (LPCSTR*)Filenames, "", Flags, NULL);
	}
}

/**
 * Adds a package new file to the depot.
 *
 * A "gotcha" here is that the file must exist on the hard drive before this function will work (obviously),
 * so new packages must be saved out before this will work.
 */
void FSourceControlIntegration::Add( UObject* InPackage )
{
	check( InPackage );
	Add(InPackage->GetOutermost()->GetName());
}


/**
 * Removes a file from the depot.
 */
void FSourceControlIntegration::Remove(const TCHAR* PackageName)
{
	if( !IsEnabled() )
	{
		return;
	}

	Open();

	FString FullName = GetFullFilename(PackageName);
	if (FullName.Len())
	{
		FTCHARToANSI Convert(*FullName);
		char* Filenames[2] = { (ANSICHAR*)Convert, NULL };

		SCC_Remove(Context, GetParentWindow(), 1, (LPCSTR*)Filenames, "", 0, NULL);
	}
}

/**
 * Removes a package file from the depot.
 */
void FSourceControlIntegration::Remove(UObject* InPackage)
{
	check(InPackage);
	Remove(InPackage->GetOutermost()->GetName());
}

/**
 * Renames a file in the depot.
 */
void FSourceControlIntegration::Rename(const TCHAR* SourceFilename, const TCHAR* DestinationFilename)
{
	if( !IsEnabled() )
	{
		return;
	}

	if (bSupportsRename)
	{
		Open();

		if (*SourceFilename && *DestinationFilename)
		{
			SCC_Rename(Context, GetParentWindow(), (LPSTR)TCHAR_TO_ANSI(DestinationFilename), (LPSTR)TCHAR_TO_ANSI(SourceFilename));
		}
	}
	else
	{
		// attempt to run p4 manually, since it doesn't support Rename over SCC
//		FString PerforceBranchCommand = TEXT("p4 rename 
//		FString PerforceDeleteCommand = TEXT("p4 rename 
	}
}

/**
 * Moves the specified package file to the trashcan director.
 */
void FSourceControlIntegration::MoveToTrash( UObject* InPackage )
{
	FFilename PackageFilename = GetFullFilename(InPackage);
	FFilename TrashFilename = appConvertRelativePathToFull(appGameDir() * TRASHCAN_DIRECTORY_NAME * PackageFilename.GetCleanFilename());

	// @todo: check for success, and mark the package as PKG_Trash!
	Rename(*PackageFilename, *TrashFilename);
}

// TODO: 10tacle, added by Ernest SCC (until the end of this file)
#ifdef SCC_NXN_75
/**
* Finds file in ContentPaths with GSys->Extensions (typically maps - *.war, packages - *upk, script - *.u).
*/
UBOOL FSourceControlIntegration::FindFile(const TCHAR* InFilename, FileInfo& fileInfo)
{
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT ]; 

	for (INT i=0; i<ContentPaths.Num(); i++)
	{
		FTCHARToANSI Convert(*ContentPaths(i));
		fileList files;
		PopulateDirectory((ANSICHAR*)Convert, files);

		for (INT j=0; j<files.Num(); j++)
		{
			_splitpath(files(j).name.c_str(), NULL, NULL, fname, ext);
			string filename = fname;
			filename += ext;
			for (INT k=0; k<GSys->Extensions.Num(); k++)
			{
				FString filenameF = FString(InFilename) + FString(".") + GSys->Extensions(k);

				FTCHARToANSI filenameT(*filenameF);
				string filename2 = (ANSICHAR*)filenameT;
				if (filename == filename2)
				{
					fileInfo = files(j);
					return TRUE;
				}
			}
		}
	}

	return FALSE;
}

/**
* Retrieves new file from depot, this is called from UObject::GetPackageLinker when file is not found.
* The problem is that InFilename is just file name, no path, no extension - I have to search ContentPaths
* created in UpdateContent().
*/
UBOOL FSourceControlIntegration::GetNew(const TCHAR* InFilename, FString& file)
{
	if( !IsEnabled() )
	{
		return FALSE;
	}

	if (bDisableSccGet||bGetCanceled)
		return FALSE;

	Open();

	if (*InFilename)
	{
		FileInfo fileInfo;
		if (FindFile(InFilename, fileInfo))
		{
            // check status
			//*file = (char*)fileInfo.name.c_str();
			FANSIToTCHAR tcharname(fileInfo.name.c_str());
			file = tcharname;
			Get(tcharname);

			LONG StatusCode;
			const char* Filenames[2] = { fileInfo.name.c_str(), NULL };
			if( SCC_QueryInfo( Context, 1, (LPCSTR*)Filenames, &StatusCode ) == SCC_OK )
			{
				if (StatusCode&SCC_STATUS_CONTROLLED)
				{
					if ((StatusCode&SCC_STATUS_OUTOFDATE) == 0)
						return TRUE;
				}
			}
		}
	}

	return FALSE;
}

/** 
* Retrieves (new/newer) file from depot.
*/
void FSourceControlIntegration::Get(const TCHAR* InFilename, UBOOL bIgnoreDisableGet, UBOOL bAddFileToList)
{
	if( !IsEnabled() )
	{
		return;
	}

	if (bGetCanceled)
		return;

	if (bDisableSccGet&&!bIgnoreDisableGet)
		return;

	Open();

	if (*InFilename)
	{
		FString p = appConvertRelativePathToFull(FString(InFilename));
		FTCHARToANSI Convert(*p);
		char* Filenames[2] = { (ANSICHAR*)Convert, NULL };

		LONG StatusCode;
		if( SCC_QueryInfo( Context, 1, (LPCSTR*)Filenames, &StatusCode ) == SCC_OK )
		{
			if (StatusCode & SCC_STATUS_CONTROLLED)
			{
				FILE* f = fopen(Filenames[0], "r");
				if (f)
					fclose(f);
				if ((StatusCode & SCC_STATUS_OUTOFDATE) || !f)
				{
					if (GetAsyncKeyState(VK_CONTROL))
					{
						MessageBox(GetParentWindow(), TEXT("Operation canceled."), TEXT("SCC file update."), MB_OK|MB_ICONINFORMATION|MB_TOPMOST);
						bGetCanceled = TRUE;
						return;
					}
					else
					{
						INT index;
						if (aAlreadyOpenedFiles.FindItem(p, index))
						{
							// this happens when duplicated (ambiguous) files are find
							if (!bErnestInformed)
							{
								FString s =	FString::Printf(TEXT("SccGet called twice for '%s' file.\nThe file will not be downloaded.\nInform Ernest (e.mikita@10tacle.com)."), *p);
								MessageBox(GetParentWindow(), *s, TEXT("Priekak."), MB_OK|MB_ICONINFORMATION|MB_TOPMOST);
								bErnestInformed = TRUE;
							}
						}
						else
						{
							if (bAddFileToList)
								aAlreadyOpenedFiles.AddItem(p);
							SCC_Get(Context, GetParentWindow(), 1, (LPCSTR*)Filenames, 0, NULL);
						}
					}
				}
			}
		}
	}
}

/** 
* Callback function for SCC_PopulateList.
*/
BOOL PopulateFn(LPVOID pvCallerData, BOOL bAddKeep, LONG nStatus, LPCSTR lpFile)
{
	FileInfo fi;
	fi.name = lpFile;
	fi.size = 0; // VS Alienbrain NxN integration does't support file size retrieving
	fileList* flist = (fileList*)pvCallerData;
	flist->AddItem(fi);

	return TRUE;
}

/** 
* Populate specific directory, recursive, returns list of ALL files from SCC.
*/
//BOOL PopulateFn(LPVOID pvCallerData, BOOL bAddKeep, LONG nStatus, LPCSTR lpFile, DWORD dwFilesize)
//{
//	fileList** pData = (fileList**)pvCallerData;
//	fileList* pFilelistNew = pData[0];
//	fileList* pFilelistNewer = pData[1];
//
//	FileInfo fi;
//	if (nStatus&(UINT)SCC_STATUS_SERVER_ONLY)
//	{
//		fi.name = lpFile;
//		fi.size = dwFilesize; 
//		pFilelistNew->AddItem(fi);
//	}
//	else
//	if (nStatus&(UINT)SCC_STATUS_OUTOFDATE)
//	{
//		fi.name = lpFile;
//		fi.size = dwFilesize; 
//		pFilelistNewer->AddItem(fi);
//	}
//
//		return TRUE;
//}

void FSourceControlIntegration::PopulateDirectory(LPCSTR pDirectory, fileList& filelist)
{
	string pathExt = pDirectory;
	if (pathExt[pathExt.size()-1]!='\\')
		pathExt += "\\";

	string filePath = pathExt;
	filePath += "*.*";
	WIN32_FIND_DATAA data;
	HANDLE h = FindFirstFileA(filePath.c_str(), &data);
	if (h!=INVALID_HANDLE_VALUE)
	{		
		do
		{
			if (data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)
			{
				if (data.cFileName[0]!='.')
				{
					string newPath(pDirectory);
					if (newPath[newPath.size()-1]!='\\')
						newPath += '\\';
					newPath += data.cFileName;
					newPath += '\\';

					LPCSTR pNewPath = newPath.c_str();
					LONG lStatus = -1;
					SCC_PopulateList(Context, SCC_COMMAND_GET, 1, &pNewPath, PopulateFn, &filelist, &lStatus, SCC_PL_DIR);
					PopulateDirectory(newPath.c_str(), filelist);
				}
			}
		} while (FindNextFileA(h, &data));
	}
}

/** 
* Populate specific directory, optionally recursive, returns lists of new and newer files from SCC.
*/
void FSourceControlIntegration::PopulateDirectory(LPCSTR pDirectory, fileList& newFiles, fileList& newerFiles, UBOOL bRecursive)
{
	fileList filelist;
	LONG lStatus = -1;
	LPCSTR pData[2] = {pDirectory, NULL};
	// this is VS Alienbrain NxN integration very specific
	SCC_PopulateList(Context, SCC_COMMAND_GET, 1, pData, PopulateFn, &filelist, &lStatus, SCC_PL_DIR);
	if (bRecursive)
		PopulateDirectory(pDirectory, filelist);

	if (filelist.Num()>0)
	{
		LPCSTR* pFilenames = new LPCSTR[filelist.Num()];
		LONG* pStatusCodes = new LONG[filelist.Num()];
		for (INT i=0; i<filelist.Num(); i++)
		{
			FileInfo* fi = &filelist(i);
			pFilenames[i] = fi->name.c_str();
		}

		if (SCC_QueryInfo(Context, filelist.Num(), pFilenames, pStatusCodes ) == SCC_OK )
		{
			for (INT i=0; i<filelist.Num(); i++)
			{
				if (pStatusCodes[i]&SCC_STATUS_CONTROLLED && pStatusCodes[i]&SCC_STATUS_OUTOFDATE)
				{
					FILE* f = fopen(pFilenames[i], "r");
					if (f)
					{
						fclose(f);
						newerFiles.AddItem(filelist(i)); // newer file on the server
					}
					else
						newFiles.AddItem(filelist(i)); // new file on the server (managed server only file)
				}
			}
		}

		delete [] pFilenames;
		delete [] pStatusCodes;
	}
}

/** 
* Informs (and optionally downloads) user about new/newer files when editor is started. This is useful when bDisableSccGet is false.
* Typically combination of bDisableUpdateMapsAndPackages and bDisableSccGet:
*				programmers:	false, true - they don't need update stuff every time
*				artists:		true, false - they should be up to date
*/
void FSourceControlIntegration::UpdateContent()
{
	if( !IsEnabled() )
	{
		return;
	}

	// fill ContentPath by GSys->Paths, you can use filter and remove some paths to speed up population and file retrieving by GetNew()
	for (INT i=0; i<GSys->Paths.Num(); i++)
	{
		FString pathF = appConvertRelativePathToFull(GSys->Paths(i));
		ContentPaths.AddItem(pathF);
		debugf(TEXT("Content path: %s"), *ContentPaths(i));
	}

	if (bDisableUpdateMapsAndPackages)
		return;

	Open();

	fileList contentFiles[2];

	//NxNPopulateDir(ProjectPath, PopulateFn, contentFiles);

	for (INT i=0; i<GSys->Paths.Num(); i++)
	{
		FTCHARToANSI ansi(*ContentPaths(i));
		PopulateDirectory(ansi, contentFiles[0], contentFiles[1], TRUE);
	}

	// inform user that new or newer file(s) found
	if (contentFiles[0].Num()||contentFiles[1].Num())
	{
		FString mess = TEXT("New files:\n");
		for (INT i=0; i<contentFiles[0].Num(); i++)
		{
			FANSIToTCHAR Convert((contentFiles[0])(i).name.c_str());
			mess += Convert + TEXT("\n");
		}
		mess += TEXT("\nNewer files:\n");
		for (INT i=0; i<contentFiles[1].Num(); i++)
		{
			FANSIToTCHAR Convert((contentFiles[1])(i).name.c_str());
			mess += Convert + TEXT("\n");
		}
		mess += TEXT("\nDownload?");
		FString caption = FString::Printf(TEXT("Update content - %d new and %d newer content files."), contentFiles[0].Num(), contentFiles[1].Num());
		int r = MessageBox(GetParentWindow(), *mess, *caption, MB_YESNO|MB_ICONINFORMATION|MB_TOPMOST);
		if (r==IDYES) // automatic
		{
			fileList bigList;
			bigList.Append(contentFiles[0]);
			bigList.Append(contentFiles[1]);
			bGetCanceled = FALSE;
			// VS Alienbrain NxN integration does not support canceling SccGet, so call it file-by-file (instead of giving it a complete list) to give user chance to cancel, don't tell it to artists :-)
			for (INT i=0; i<bigList.Num(); i++)
			{
				LPCSTR pFile = bigList(i).name.c_str();
				FANSIToTCHAR Convert(pFile);
				Get((TCHAR*)Convert, TRUE, FALSE);
				if (bGetCanceled)
				{
					bGetCanceled = FALSE;
					break;
				}
			}
		}
		else
		if (r==IDNO)
		{
		}
	}
}

/** 
* Runs database browser.
*/
void FSourceControlIntegration::RunScc(LPCSTR InFilename)
{
	if( !IsEnabled() )
	{
		return;
	}

	if (InFilename&&*InFilename)
	{
		FString p = appConvertRelativePathToFull(FString(InFilename));
		FTCHARToANSI Convert(*p);
		char* Filenames[2] = { (ANSICHAR*)Convert, NULL };
		// this will be supported by VS Alienbrain NxN integration in future, however it is safe to call it
		SCC_RunScc(Context, 0/*GetParentWindow()*/, 1, (LPCSTR*)Filenames);
	}
	else
		SCC_RunScc(Context, 0/*GetParentWindow()*/, 0, NULL);
}
#endif // SCC_NXN_75