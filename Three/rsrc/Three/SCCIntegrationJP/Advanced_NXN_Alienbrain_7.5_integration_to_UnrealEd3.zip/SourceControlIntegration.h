/**
 * Copyright � 2004-2005 Epic Games, Inc. All Rights Reserved.
 */

#ifndef __SOURCECONTORLINTEGRATION_H__
#define __SOURCECONTORLINTEGRATION_H__

#include "scc.h"

typedef LONG (*FuncSccGetVersion) ( void );
typedef SCCRTN (*FuncSccInitialize) ( LPVOID*, HWND, LPCSTR, LPSTR, LPLONG, LPSTR, LPDWORD, LPDWORD );
typedef SCCRTN (*FuncSccUninitialize) ( LPVOID );
typedef SCCRTN (*FuncSccGetProjPath) ( LPVOID, HWND, LPSTR, LPSTR, LPSTR, LPSTR, BOOL, LPBOOL );
typedef SCCRTN (*FuncSccOpenProject) ( LPVOID, HWND, LPSTR, LPSTR, LPCSTR, LPSTR, LPCSTR, LPTEXTOUTPROC, LONG );
typedef SCCRTN (*FuncSccCloseProject) ( LPVOID );
typedef SCCRTN (*FuncSccQueryInfo) ( LPVOID, LONG, LPCSTR*, LPLONG );
typedef SCCRTN (*FuncSccHistory) ( LPVOID, HWND, LONG, LPCSTR*, LONG, LPCMDOPTS );
typedef SCCRTN (*FuncSccCheckOut) ( LPVOID, HWND, LONG, LPCSTR*, LPCSTR, LONG, LPCMDOPTS );
typedef SCCRTN (*FuncSccUncheckOut) ( LPVOID, HWND, LONG, LPCSTR*, LONG, LPCMDOPTS );
typedef SCCRTN (*FuncSccCheckIn) ( LPVOID, HWND, LONG, LPCSTR*, LPCSTR, LONG, LPCMDOPTS );
typedef SCCRTN (*FuncSccAdd) ( LPVOID, HWND, LONG, LPCSTR*, LPCSTR, LONG*, LPCMDOPTS );
typedef SCCRTN (*FuncSccRemove) ( LPVOID, HWND, LONG, LPCSTR*, LPCSTR, LONG, LPCMDOPTS );
typedef SCCRTN (*FuncSccRename) ( LPVOID, HWND, LPSTR, LPSTR );

// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
typedef SCCRTN (*FuncSccGet) ( LPVOID, HWND, LONG, LPCSTR*, LONG, LPCMDOPTS);
typedef SCCRTN (*FuncSccRunScc) ( LPVOID, HWND, LONG, LPCSTR*);
typedef SCCRTN (*FuncSccPopulateList) ( LPVOID, enum SCCCOMMAND, LONG, LPCSTR*, POPLISTFUNC, LPVOID, LPLONG, LONG);

//// extra flag
//#define SCC_STATUS_SERVER_ONLY 0x2000L
//
//typedef BOOL (*POPLISTFUNC2) (LPVOID pvCallerData, BOOL bAddKeep, LONG nStatus, LPCSTR lpFile, DWORD dwFilesize);
//void NxNPopulateDir(LPCSTR pProjectWorkspace, POPLISTFUNC2 fnCallback, LPVOID pvCallerData);

#include <string>
using namespace std;
typedef struct _FileInfo
{
	string	name;
	DWORD	size;
} FileInfo;
typedef TArray<FileInfo> fileList;
#endif // SCC_NXN_75

class FSourceControlIntegration
{
public:
	FSourceControlIntegration();
	~FSourceControlIntegration();

	/**
	 * Called when the user wants to connect to a different project.  Will pop
	 * up the connection dialog and let them enter new info.
	 */
	void GetProjPath();

	/**
	 * Opens a project connection with the SCC.  Also handles logging the user in if they haven't been already.
	 */
	void Open();

	/**
	 * Closes the current project connection.
	 */
	void Close();

	/**
	 * Updates the status flags for a set of packages.
	 *
	 * @param	InPackages	The packages to update status flags for
	 */
	void Update(TArray<UPackage*>* InPackages);

	/**
	 * Displays the revision history for the specified set of packages.
	 */
	void ShowHistory(const TArray<UPackage*>& Packages);

	////////////////////
	// File based operations

	/**
	 * Checks a file out of the SCC depot.
	 */
	void CheckOut(const TCHAR* PackageName);

	/**
	 * Reverts a file checked out of the SCC depot.
	 */
	void UncheckOut(const TCHAR* PackageName);

	/**
	 * Checks a file into the SCC depot.
	 */
	void CheckIn(const TCHAR* PackageName);

	/**
	 * Adds a new file to the depot.
	 *
	 * A "gotcha" here is that the file must exist on the hard drive before this function will work (obviously),
	 * so new files must be saved out before this will work.
	 */
	void Add(const TCHAR* PackageName, UBOOL bIsBinary=TRUE);

	/**
	 * Removes a file from the depot.
	 */
	void Remove(const TCHAR* PackageName);

	/**
	 * Renames a file in the depot.
	 */
	void Rename(const TCHAR* SourceName, const TCHAR* DestinationFilename);

// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
	UBOOL FindFile(const TCHAR* InFilename, FileInfo& fileInfo);
	UBOOL GetNew(const TCHAR* InFilename, FString& file);
	void Get(const TCHAR* InFilename, UBOOL bIgnoreDisableGet = FALSE, UBOOL bAddFileToList = TRUE);
	void PopulateDirectory(LPCSTR pDirectory, fileList& filelist); // this should be private
	void PopulateDirectory(LPCSTR pDirectory, fileList& newFiles, fileList& newerFiles, UBOOL bRecursive); // this should be private
	void UpdateContent();
	void RunScc(LPCSTR InFilename);
#endif // SCC_NXN_75

	////////////////////
	// Package based operations

	/**
	 * Checks a package file out of the SCC depot.
	 */
	void CheckOut( UObject* InPackage );

	/**
	 * Reverts a package file checked out of the SCC depot.
	 */
	void UncheckOut( UObject* InPackage );

	/**
	 * Checks a package file into the SCC depot.
	 */
	void CheckIn( UObject* InPackage );

	/**
	 * Adds a new file to the depot.
	 *
	 * A "gotcha" here is that the file must exist on the hard drive before this function will work (obviously),
	 * so new packages must be saved out before this will work.
	 */
	void Add( UObject* InPackage );

	/**
	 * Removes a package file from the depot.
	 */
	void Remove( UObject* InPackage );

	/**
	 * Moves the specified package file to the trashcan director.
	 */
	void MoveToTrash( UObject* InPackage );

	/**
	 * Loads user/SCC information from the INI file.
	 */
	void LoadFromINI();

	/**
	 * Stores user/SCC information in the INI file.  This saves the user from having to log in every
	 * time they start up the editor.
	 */
	void SaveToINI();

	/**
	 * Creates a fully qualified filename, including the path all the way back to the drive letter,
	 * for the specific package.
	 *
	 * @param	PackageName	The name of the package (like "EngineMaterials")
	 *
	 * @return	The fully qualified filename
	 */
	FString GetFullFilename(const TCHAR* PackageName);

	/**
	 * Creates a fully qualified filename, including the path all the way back to the drive letter,
	 * for the specific package.
	 *
	 * @param	InPackage	The package we need the filename for
	 *
	 * @return	The fully qualified filename
	 */
	FString GetFullFilename(UObject* InPackage);

	UBOOL IsEnabled()
	{
		return bEnabled;
	}

	UBOOL IsOpen()
	{
		return bOpen;
	}

	/**
	 * Retrieve the singleton object
	 */
	static FSourceControlIntegration* GetGlobalSourceControlIntegration();

private:
	/**
	 * Attempts to find the users SCC system, load the library associated with it and bind the functions.
	 */
	void Init();

	/**
	 * Gets a string out of the registry.
	 *
	 * @param	InMainKey	The primary key
	 * @param	InKey		The secondary key
	 *
	 * @return	A char* buffer containing the string.  The caller is reponsible for freeing this!
	 */
	char* GetRegistryString( char* InMainKey, char* InKey );

	char** GetFilenamesFromArray(const TArray<UPackage*>* InSrcPackages, INT& InNumFiles, TArray<UPackage*>* InPackages = NULL );

	/** 
	 * An interrupt function to delete the GSourceControlIntegration 
	 * singleton if we get a control-c when in a console program 
	 */
	static UBOOL WINAPI ConsoleInterruptHandler(DWORD ControlType);

	/** Values returned from SCCInitialize */
	LONG Caps;
	char Label[SCC_AUXLABEL_LEN], ProviderName[SCC_NAME_LEN];
	DWORD CheckOutCommentLen;
	DWORD CommentLen;

	/** Indicates if source control integration is available or not. */
	UBOOL bEnabled;

	/** Indicates that the project is currently open. */
	UBOOL bOpen;

	/** Function bindings */
	FuncSccGetVersion SCC_GetVersion;
	FuncSccInitialize SCC_Initialize;
	FuncSccUninitialize SCC_Uninitialize;
	FuncSccGetProjPath SCC_GetProjPath;
	FuncSccOpenProject SCC_OpenProject;
	FuncSccCloseProject SCC_CloseProject;
	FuncSccQueryInfo SCC_QueryInfo;
	FuncSccHistory SCC_History;
	FuncSccCheckOut SCC_CheckOut;
	FuncSccUncheckOut SCC_UncheckOut;
	FuncSccCheckIn SCC_CheckIn;
	FuncSccAdd SCC_Add;
	FuncSccRemove SCC_Remove;
	FuncSccRename SCC_Rename;
// TODO: 10tacle, added by Ernest SCC
#ifdef SCC_NXN_75
	FuncSccGet SCC_Get;
	FuncSccRunScc SCC_RunScc;
	FuncSccPopulateList SCC_PopulateList;

	/** Flag to disable SccGet, which is called before loading any map/package. **/
	UBOOL	bDisableSccGet;
	/** Flag to disable Update maps and packages on start up feature. **/
	UBOOL	bDisableUpdateMapsAndPackages;
	UBOOL	bGetCanceled;
	UBOOL	bErnestInformed;
	TArray<FString> aAlreadyOpenedFiles;
	TArray<FString> ContentPaths;
#endif // SCC_NXN_75


	/** Flag to disable source control integration. **/
	UBOOL	bDisabled;

	/** Indicates whether or not the SCC provider support rename (p4, for example, does not, but VSS does) */
	UBOOL bSupportsRename;

	/** Handle to the loaded library. */
	void* LibraryHandle;

	/** Context pointer (used exclusively by the SCC provider) */
	void* Context;

	/** The user name we are using for log ins. */
	char UserName[SCC_USER_LEN];

	/** Not used for anything, but we need to pass it to the API for certain functions to work. */
	char LocalPath[SCC_PRJPATH_LEN];

	/** The project paths */
	char ProjectPath[SCC_PRJPATH_LEN];
	char AuxProjectPath[SCC_PRJPATH_LEN];

	/** Global pointer to the one and only SCC pointer */
	static FSourceControlIntegration* GSourceControlIntegration;
};

#endif // #define __SOURCECONTORLINTEGRATION_H__
