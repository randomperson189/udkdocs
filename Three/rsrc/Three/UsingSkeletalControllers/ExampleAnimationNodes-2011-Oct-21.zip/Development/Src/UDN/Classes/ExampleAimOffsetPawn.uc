class ExampleAimOffsetPawn extends Pawn;

var(Pawn) float ViewYawMin;
var(Pawn) float ViewYawMax;
var(Pawn) float AimSpeed;

var	AnimNodeAimOffset AimNode;
var Rotator DesiredAim;
var Rotator CurrentAim;

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	AimNode = AnimNodeAimOffset(SkelComp.FindAnimNode('AimNode'));
}

simulated event Destroyed()
{
	Super.Destroyed();

	AimNode = None;
}

simulated function Tick(float DeltaTime)
{
	local PlayerController PlayerController;

	Super.Tick(DeltaTime);

	PlayerController = GetALocalPlayerController();
	if (PlayerController != None && PlayerController.Pawn != None && AimNode != None)
	{
		DesiredAim = Rotator(Normal(Location - PlayerController.Pawn.Location));

		DesiredAim.Pitch = Clamp(DesiredAim.Pitch, ViewPitchMin, ViewPitchMax);
		DesiredAim.Yaw = Clamp(DesiredAim.Yaw, ViewYawMin, ViewYawMax);
		
		if (DesiredAim != CurrentAim)
		{
			CurrentAim = RLerp(CurrentAim, DesiredAim, AimSpeed * DeltaTime, false);
		}

		// Adjust the pitch
		if (CurrentAim.Pitch < 0)
		{
			AimNode.Aim.Y = Abs(float(CurrentAim.Pitch) / ViewPitchMax);
		}
		else if (CurrentAim.Pitch > 0)
		{
			AimNode.Aim.Y = float(CurrentAim.Pitch) / ViewPitchMin;
		}
		else
		{
			AimNode.Aim.Y = 0.f;
		}

		// Adjust the yaw
		if (CurrentAim.Yaw > 0)
		{
			AimNode.Aim.X = float(CurrentAim.Yaw) / ViewYawMax;
		}
		else if (CurrentAim.Yaw < 0)
		{
			AimNode.Aim.X = Abs(float(CurrentAim.Yaw) / ViewYawMin) * -1.f;
		}
		else
		{
			AimNode.Aim.X = 0.f;
		}
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}