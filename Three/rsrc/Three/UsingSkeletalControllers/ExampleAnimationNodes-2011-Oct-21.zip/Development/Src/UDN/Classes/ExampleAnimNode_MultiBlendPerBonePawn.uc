class ExampleAnimNode_MultiBlendPerBonePawn extends Pawn;

var AnimNode_MultiBlendPerBone AnimNode_MultiBlendPerBone;
var float NextBlendTime;
var int PreviousMaskIndex;

simulated event Destroyed()
{
	Super.Destroyed();

	AnimNode_MultiBlendPerBone = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	AnimNode_MultiBlendPerBone = AnimNode_MultiBlendPerBone(SkelComp.FindAnimNode('AnimNode_MultiBlendPerBone'));
}

simulated event Tick(float DeltaTime)
{
	local int NewMaskIndex;

	Super.Tick(DeltaTime);

	if (AnimNode_MultiBlendPerBone == None)
	{
		return;
	}

	if (WorldInfo.TimeSeconds >= NextBlendTime)
	{
		AnimNode_MultiBlendPerBone.SetMaskWeight(PreviousMaskIndex, 0.f, 0.25f);
		NewMaskIndex = Rand(AnimNode_MultiBlendPerBone.MaskList.Length);
		AnimNode_MultiBlendPerBone.SetMaskWeight(NewMaskIndex, 1.f, 0.25f);
		PreviousMaskIndex = NewMaskIndex;

		NextBlendTime = worldInfo.TimeSeconds + 2.f;
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}