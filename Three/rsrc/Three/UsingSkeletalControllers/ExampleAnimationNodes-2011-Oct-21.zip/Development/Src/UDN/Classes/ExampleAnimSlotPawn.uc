class ExampleAnimSlotPawn extends Pawn;

var(Pawn) array<Name> CustomAnimNames;
var AnimNodeSlot AnimNodeSlot;
var float NextAnimationTime;

simulated event Destroyed()
{
	Super.Destroyed();

	AnimNodeSlot = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	AnimNodeSlot = AnimNodeSlot(SkelComp.FindAnimNode('AnimNodeSlot'));
}

simulated event Tick(float DeltaTime)
{
	local float Duration;

	Super.Tick(DeltaTime);

	if (AnimNodeSlot == None)
	{
		return;
	}

	if (WorldInfo.TimeSeconds >= NextAnimationTime)
	{
		Duration = AnimNodeSlot.PlayCustomAnim(CustomAnimNames[Rand(CustomAnimNames.Length)], 1.f, 0.3f, 0.3f, false, true);
		NextAnimationTime = WorldInfo.TimeSeconds + (Duration * 0.5f);
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}