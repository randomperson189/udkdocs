class ExampleBlendByPosturePawn extends Pawn;

simulated function Tick(float DeltaTime)
{
	local PlayerController PlayerController;

	PlayerController = GetALocalPlayerController();
	if (PlayerController != None && PlayerController.Pawn != None)
	{
		ShouldCrouch(VSize(PlayerController.Pawn.Location - Location) <= 256.f);
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object

	bCanCrouch=true
}