class ExampleBlendByPropertyBytePawn extends Pawn;

var byte MyBlendProperty;
var float NextBlendTime;

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (WorldInfo.TimeSeconds >= NextBlendTime)
	{
		MyBlendProperty++;

		if (MyBlendProperty > 4)
		{
			MyBlendProperty = 0;
		}

		NextBlendTime = WorldInfo.TimeSeconds + 2.f;
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}