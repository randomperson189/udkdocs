class ExampleBlendByPropertyFloatPawn extends Pawn;

var float MyBlendProperty;

simulated event PostBeginPlay()
{
	Super.PostBeginPlay();
	IsBlendingDown();
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (IsTimerActive(NameOf(IsBlendingUp)))
	{
		MyBlendProperty = GetTimerCount(NameOf(IsBlendingUp)) / GetTimerRate(NameOf(IsBlendingUp));
	}
	else if (IsTimerActive(NameOf(IsBlendingDown)))
	{
		MyBlendProperty = 1.f - (GetTimerCount(NameOf(IsBlendingDown)) / GetTimerRate(NameOf(IsBlendingDown)));
	}
}

simulated function IsBlendingUp()
{
	SetTimer(2.f, false, NameOf(IsBlendingDown));
}

simulated function IsBlendingDown()
{
	SetTimer(2.f, false, NameOf(IsBlendingUp));
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}