class ExampleBlendListPawn extends Pawn;

var AnimNodeBlendList AnimNodeBlendList;
var float NextBlendTime;

simulated event Destroyed()
{
	Super.Destroyed();

	AnimNodeBlendList = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	AnimNodeBlendList = AnimNodeBlendList(SkelComp.FindAnimNode('AnimNodeBlendList'));
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (AnimNodeBlendList == None)
	{
		return;
	}

	if (WorldInfo.TimeSeconds > NextBlendTime)
	{
		AnimNodeBlendList.SetActiveChild(Rand(AnimNodeBlendList.Children.Length), 0.25f);
		NextBlendTime = WorldInfo.TimeSeconds + 2.f;
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}