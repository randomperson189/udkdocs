class ExampleBlendPawn extends Pawn;

var AnimNodeBlend AnimNodeBlend;

simulated event Destroyed()
{
	Super.Destroyed();

	AnimNodeBlend = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	AnimNodeBlend = AnimNodeBlend(SkelComp.FindAnimNode('AnimNodeBlend'));
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (AnimNodeBlend == None)
	{
		return;
	}

	if (AnimNodeBlend.BlendTimeToGo <= 0.f)
	{
		AnimNodeBlend.SetBlendTarget((AnimNodeBlend.Child2Weight >= 1.f) ? 0.f : 1.f, 0.5f);
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}