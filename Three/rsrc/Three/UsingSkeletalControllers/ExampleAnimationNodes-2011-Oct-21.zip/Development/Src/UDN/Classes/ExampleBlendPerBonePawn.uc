class ExampleBlendPerBonePawn extends Pawn;

var AnimNodeBlendPerBone AnimNodeBlendPerBone;
var float NextBlendTime;
var bool BlendToChildTwo;

simulated event Destroyed()
{
	Super.Destroyed();

	AnimNodeBlendPerBone = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	AnimNodeBlendPerBone = AnimNodeBlendPerBone(SkelComp.FindAnimNode('AnimNodeBlendPerBone'));
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (AnimNodeBlendPerBone == None)
	{
		return;
	}

	if (WorldInfo.TimeSeconds >= NextBlendTime)
	{
		BlendToChildTwo = !BlendToChildTwo;

		AnimNodeBlendPerBone.SetBlendTarget((BlendToChildTwo) ? 1 : 0, 0.25f);
		NextBlendTime = WorldInfo.TimeSeconds + 2.f;
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}