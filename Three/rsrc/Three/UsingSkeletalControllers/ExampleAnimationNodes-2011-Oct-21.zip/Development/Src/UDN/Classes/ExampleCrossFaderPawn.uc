class ExampleCrossFaderPawn extends Pawn;

var(Pawn) array<Name> LoopingAnimNames;
var AnimNodeCrossfader AnimNodeCrossfader;
var float NextBlendTime;

simulated event Destroyed()
{
	Super.Destroyed();

	AnimNodeCrossfader = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	AnimNodeCrossfader = AnimNodeCrossfader(SkelComp.FindAnimNode('AnimNodeCrossfader'));
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (AnimNodeCrossfader == None)
	{
		return;
	}

	if (WorldInfo.TimeSeconds >= NextBlendTime)
	{
		AnimNodeCrossfader.BlendToLoopingAnim(LoopingAnimNames[Rand(LoopingAnimNames.Length)], 0.25f, 1.f);
		NextBlendTime = worldInfo.TimeSeconds + 2.f;
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}