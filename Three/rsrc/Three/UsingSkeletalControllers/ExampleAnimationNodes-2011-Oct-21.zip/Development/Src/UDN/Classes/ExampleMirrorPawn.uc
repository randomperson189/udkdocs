class ExampleMirrorPawn extends Pawn;

var AnimNodeMirror AnimNodeMirror;
var float NextBlendTime;

simulated event Destroyed()
{
	Super.Destroyed();

	AnimNodeMirror = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	AnimNodeMirror = AnimNodeMirror(SkelComp.FindAnimNode('AnimNodeMirror'));
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (AnimNodeMirror == None)
	{
		return;
	}

	if (WorldInfo.TimeSeconds >= NextBlendTime)
	{
		AnimNodeMirror.bEnableMirroring = !AnimNodeMirror.bEnableMirroring;
		NextBlendTime = WorldInfo.TimeSeconds + 2.f;
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}