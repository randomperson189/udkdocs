class ExamplePlayCustomAnimPawn extends Pawn;

var(Pawn) array<Name> CustomAnimNames;
var AnimNodePlayCustomAnim AnimNodePlayCustomAnim;

simulated event Destroyed()
{
	Super.Destroyed();

	AnimNodePlayCustomAnim = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	AnimNodePlayCustomAnim = AnimNodePlayCustomAnim(SkelComp.FindAnimNode('AnimNodePlayCustomAnim'));
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (AnimNodePlayCustomAnim == None)
	{
		return;
	}

	if (!AnimNodePlayCustomAnim.bIsPlayingCustomAnim)
	{
		AnimNodePlayCustomAnim.PlayCustomAnim(CustomAnimNames[Rand(CustomAnimNames.Length)], 1.f, 0.1f, 0.1f, false, true);
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}