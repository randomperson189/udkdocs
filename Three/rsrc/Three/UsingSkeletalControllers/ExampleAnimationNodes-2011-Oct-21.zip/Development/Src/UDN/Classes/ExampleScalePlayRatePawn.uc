class ExampleScalePlayRatePawn extends Pawn;

var(AnimTree) const Name ScalePlayRateAnimNodeName;
var(AnimTree) const float PlayRateOffset;

var AnimNodeScalePlayRate AnimNodeScalePlayRate;

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	if (ScalePlayRateAnimNodeName != '')
	{
		AnimNodeScalePlayRate = AnimNodeScalePlayRate(SkelComp.FindAnimNode(ScalePlayRateAnimNodeName));
	}
}

simulated event Destroyed()
{
	Super.Destroyed();
	AnimNodeScalePlayRate = None;
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);
	AnimNodeScalePlayRate.ScaleByValue = (Sin(WorldInfo.TimeSeconds + PlayRateOffset) + 1) * 0.5f;
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}