class ExampleScaleRateBySpeedPawn extends Pawn;

event TakeDamage(int Damage, Controller InstigatedBy, vector HitLocation, vector Momentum, class<DamageType> DamageType, optional TraceHitInfo HitInfo, optional Actor DamageCauser)
{
	Super.TakeDamage(Damage, InstigatedBy, HitLocation, Momentum, DamageType, HitInfo, DamageCauser);

	GroundSpeed = default.GroundSpeed * (float(Health) / float(HealthMax));
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}