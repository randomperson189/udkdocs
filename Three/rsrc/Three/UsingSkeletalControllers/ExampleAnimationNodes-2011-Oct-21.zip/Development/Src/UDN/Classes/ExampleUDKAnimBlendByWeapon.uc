class ExampleUDKAnimBlendByWeapon extends Pawn;

// Name of the firing weapon animation
var() const name FireSequenceName;
// Is the player holding an automatic firing weapon
var() const bool IsWeaponAutoFire;
// Animation play rate
var() const float FirePlayRate;
// Override blend  time for fire animation
var() const float FireBlendTime;
// Name of the looping firing weapon animation
var() const name LoopingFireSequenceName;

var UDKAnimBlendByWeapon UDKAnimBlendByWeapon;

simulated event Destroyed()
{
	Super.Destroyed();

	UDKAnimBlendByWeapon = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	UDKAnimBlendByWeapon = UDKAnimBlendByWeapon(SkelComp.FindAnimNode('UDKAnimBlendByWeapon'));
	if (UDKAnimBlendByWeapon != None)
	{
		FireWeapon();
	}
}

simulated function FireWeapon()
{
	if (UDKAnimBlendByWeapon != None)
	{
		// Start the firing animation
		UDKAnimBlendByWeapon.AnimFire(FireSequenceName, IsWeaponAutoFire, FirePlayRate, FireBlendTime, LoopingFireSequenceName);
		// After a second, stop firing
		SetTimer(1.f, false, NameOf(StopFireWeapon));
	}
}

simulated function StopFireWeapon()
{
	if (UDKAnimBlendByWeapon != None)
	{
		// Stop firing animation
		UDKAnimBlendByWeapon.AnimStopFire(FireBlendTime);
		// Restart firing in half a second
		SetTimer(0.5f, false, NameOf(FireWeapon));
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}