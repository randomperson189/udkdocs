class ExampleUDKAnimNodeFramePlayer extends Pawn
	placeable; 

var UDKAnimNodeFramePlayer UDKAnimNodeFramePlayer;

simulated event Destroyed()
{
	Super.Destroyed();

	UDKAnimNodeFramePlayer = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	UDKAnimNodeFramePlayer = UDKAnimNodeFramePlayer(SkelComp.FindAnimNode('UDKAnimNodeFramePlayer'));
	if (UDKAnimNodeFramePlayer != None)
	{
		SetTimer(0.5f, true, NameOf(RandomizePosition));
	}
}

simulated function RandomizePosition()
{
	if (UDKAnimNodeFramePlayer != None)
	{
		UDKAnimNodeFramePlayer.SetAnimPosition(FRand());
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}