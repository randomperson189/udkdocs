class ExampleUDKAnimNodeJumpLeanOffset extends Pawn
	placeable;

var UDKAnimNodeJumpLeanOffset UDKAnimNodeJumpLeanOffset;
var bool Flipper;

simulated event Destroyed()
{
	Super.Destroyed();

	UDKAnimNodeJumpLeanOffset = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	UDKAnimNodeJumpLeanOffset = UDKAnimNodeJumpLeanOffset(SkelComp.FindAnimNode('UDKAnimNodeJumpLeanOffset'));
	if (UDKAnimNodeJumpLeanOffset != None)
	{
		SetLeanWeight();
		SetTimer(1.f, true, NameOf(SetLeanWeight));		
	}
}

simulated event SetLeanWeight()
{
	if (UDKAnimNodeJumpLeanOffset != None)
	{
		UDKAnimNodeJumpLeanOffset.SetLeanWeight((Flipper) ? 0.f : 1.f, 0.2f);
		Flipper = !Flipper;
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}