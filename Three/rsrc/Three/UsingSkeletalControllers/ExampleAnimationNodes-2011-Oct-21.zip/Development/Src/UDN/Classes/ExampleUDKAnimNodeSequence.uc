class ExampleUDKAnimNodeSequence extends Pawn
	placeable; 

// Array of anim sequences to play
var() const array<Name> Sequences;
// Rate to play the sequences at
var() const float SeqRate;
// If true, then the last animation will be loop
var() const bool bLoopLast;

var UDKAnimNodeSequence UDKAnimNodeSequence;

simulated event Destroyed()
{
	Super.Destroyed();

	UDKAnimNodeSequence = None;
}

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	UDKAnimNodeSequence = UDKAnimNodeSequence(SkelComp.FindAnimNode('UDKAnimNodeSequence'));
	if (UDKAnimNodeSequence != None)
	{
		UDKAnimNodeSequence.PlayAnimationSet(Sequences, SeqRate, bLoopLast);
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}