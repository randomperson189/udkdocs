class SkelControlCCDIKPawn extends Pawn
	Placeable;

var() Name LeftSkelControlCCDIKName;
var() Name RightSkelControlCCDIKName;
var SkelControl_CCD_IK LeftSkelControlCCDIK;
var SkelControl_CCD_IK RightSkelControlCCDIK;

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	Super.PostInitAnimTree(SkelComp);

	if (SkelComp == Mesh)
	{
		LeftSkelControlCCDIK = SkelControl_CCD_IK(Mesh.FindSkelControl(LeftSkelControlCCDIKName));
		RightSkelControlCCDIK = SkelControl_CCD_IK(Mesh.FindSkelControl(RightSkelControlCCDIKName));
	}
}

simulated event Destroyed()
{
	Super.Destroyed();

	LeftSkelControlCCDIK = None;
	RightSkelControlCCDIK = None;
}

simulated event Tick(float DeltaTime)
{
	local PlayerController PlayerController;

	Super.Tick(DeltaTime);

	if (LeftSkelControlCCDIK != None && RightSkelControlCCDIK != None)
	{
		PlayerController = GetALocalPlayerController();
		if (PlayerController != None && PlayerController.Pawn != None)
		{
			LeftSkelControlCCDIK.EffectorLocation = PlayerController.Pawn.Location;
			RightSkelControlCCDIK.EffectorLocation = PlayerController.Pawn.Location;
		}
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}