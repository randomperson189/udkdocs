class SkelControlLimbPawn extends Pawn
	Placeable;

var(SkelControl) Name LeftArmSkelControlName;
var(SkelControl) Name RightArmSkelControlName;
var(SkelControl) Actor LeftArmAttachment;
var(SkelControl) Actor RightArmAttachment;

var SkelControlLimb LeftArmSkelControl;
var SkelControlLimb RightArmSkelControl;

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	Super.PostInitAnimTree(SkelComp);

	if (SkelComp == Mesh)
	{
		LeftArmSkelControl = SkelControlLimb(Mesh.FindSkelControl(LeftArmSkelControlName));
		RightArmSkelControl = SkelControlLimb(Mesh.FindSkelControl(RightArmSkelControlName));
	}
}

simulated event Destroyed()
{
	Super.Destroyed();

	LeftArmSkelControl = None;
	RightArmSkelControl = None;
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (LeftArmSkelControl != None && LeftArmAttachment != None)
	{
		LeftArmSkelControl.EffectorLocation = LeftArmAttachment.Location;
	}

	if (RightArmSkelControl != None && RightArmAttachment != None)
	{
		RightArmSkelControl.EffectorLocation = RightArmAttachment.Location;
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}