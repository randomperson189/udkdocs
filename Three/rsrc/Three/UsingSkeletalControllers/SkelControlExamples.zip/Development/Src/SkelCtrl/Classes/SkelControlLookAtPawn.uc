class SkelControlLookAtPawn extends Pawn;

var() Name SkelControlLookAtName;
var() float EyeOffset;
var SkelControlLookAt SkelControlLookAt;

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	Super.PostInitAnimTree(SkelComp);

	if (SkelComp == Mesh)
	{
		SkelControlLookAt = SkelControlLookAt(Mesh.FindSkelControl(SkelControlLookAtName));
	}
}

simulated event Destroyed()
{
	Super.Destroyed();

	SkelControlLookAt = None;
}

simulated event Tick(float DeltaTime)
{
	local PlayerController PlayerController;

	Super.Tick(DeltaTime);

	if (SkelControlLookAt != None)
	{
		PlayerController = GetALocalPlayerController();

		if (PlayerController != None && PlayerController.Pawn != None)
		{
			SkelControlLookAt.TargetLocation = PlayerController.Pawn.Location + (Vect(0.f, 0.f, 1.f) * EyeOffset);
		}
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}