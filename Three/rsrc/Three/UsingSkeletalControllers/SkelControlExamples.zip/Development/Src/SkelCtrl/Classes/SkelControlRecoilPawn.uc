class SkelControlRecoilPawn extends Pawn
	Placeable;

var() Name RecoilSkelControlName;
var() float FireRate;

var GameSkelCtrl_Recoil RecoilSkelControl;

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	Super.PostInitAnimTree(SkelComp);

	if (SkelComp == Mesh)
	{
		RecoilSkelControl = GameSkelCtrl_Recoil(Mesh.FindSkelControl(RecoilSkelControlName));
	}

	SetTimer(FireRate, true, NameOf(PlayRecoil));
}

simulated event Destroyed()
{
	Super.Destroyed();

	RecoilSkelControl = None;
}

simulated function PlayRecoil()
{
	if (RecoilSkelControl != None)
	{
		RecoilSkelControl.bPlayRecoil = true;
	}
}

defaultproperties
{
	FireRate=0.2f

	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}