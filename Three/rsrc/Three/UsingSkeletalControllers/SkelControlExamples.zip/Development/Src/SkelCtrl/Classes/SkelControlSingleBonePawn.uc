class SkelControlSingleBonePawn extends Pawn
	Placeable;

var() Name SkelControlSingleBoneName;
var SkelControlSingleBone SkelControlSingleBone;

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	Super.PostInitAnimTree(SkelComp);

	if (SkelComp == Mesh)
	{
		SkelControlSingleBone = SkelControlSingleBone(Mesh.FindSkelControl(SkelControlSingleBoneName));
	}
}

simulated event Destroyed()
{
	Super.Destroyed();

	SkelControlSingleBone = None;
}

simulated event Tick(float DeltaTime)
{
	local PlayerController PlayerController;
	local Rotator R;

	Super.Tick(DeltaTime);

	if (SkelControlSingleBone != None)
	{
		PlayerController = GetALocalPlayerController();
		if (PlayerController != None && PlayerController.Pawn != None)
		{
			R = Rotator(Location - PlayerController.Pawn.Location);
			SkelControlSingleBone.BoneRotation.Yaw = R.Yaw;
		}
	}
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}