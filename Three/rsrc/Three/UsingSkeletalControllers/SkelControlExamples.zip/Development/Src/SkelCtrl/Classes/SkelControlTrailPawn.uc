class SkelControlTrailPawn extends Pawn
	Placeable;

var() Name SkelControlTrailLeftName;
var() Name SkelControlTrailRightName;
var() float SinkVelocityZ;
var() float FloatVelocityZ;

var SkelControlTrail SkelControlTrailLeft;
var SkelControlTrail SkelControlTrailRight;

simulated event PostInitAnimTree(SkeletalMeshComponent SkelComp)
{
	Super.PostInitAnimTree(SkelComp);

	if (SkelComp == Mesh)
	{
		SkelControlTrailLeft = SkelControlTrail(Mesh.FindSkelControl(SkelControlTrailLeftName));
		SkelControlTrailRight = SkelControlTrail(Mesh.FindSkelControl(SkelControlTrailRightName));
	}

	SetTimer(2.f, false, NameOf(SinkTrail));
}

simulated event Destroyed()
{
	Super.Destroyed();

	SkelControlTrailLeft = None;
	SkelControlTrailRight = None;
}

simulated event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);

	if (SkelControlTrailLeft != None && SkelControlTrailRight != None)
	{
		if (IsTimerActive(NameOf(FloatTrail)))
		{
			SkelControlTrailLeft.FakeVelocity.Z = Lerp(FloatVelocityZ, SinkVelocityZ, GetTimerCount(NameOf(FloatTrail)) / GetTimerRate(NameOf(FloatTrail)));
			SkelControlTrailRight.FakeVelocity.Z = Lerp(FloatVelocityZ, SinkVelocityZ, GetTimerCount(NameOf(FloatTrail)) / GetTimerRate(NameOf(FloatTrail)));
		}
		else if (IsTimerActive(NameOf(SinkTrail)))
		{
			SkelControlTrailLeft.FakeVelocity.Z = Lerp(SinkVelocityZ, FloatVelocityZ, GetTimerCount(NameOf(SinkTrail)) / GetTimerRate(NameOf(SinkTrail)));
			SkelControlTrailRight.FakeVelocity.Z = Lerp(SinkVelocityZ, FloatVelocityZ, GetTimerCount(NameOf(SinkTrail)) / GetTimerRate(NameOf(SinkTrail)));
		}
	}
}

simulated function FloatTrail()
{
	if (SkelControlTrailLeft != None && SkelControlTrailRight != None)
	{
		SkelControlTrailLeft.FakeVelocity.Z = FloatVelocityZ;
		SkelControlTrailRight.FakeVelocity.Z = FloatVelocityZ;
	}

	SetTimer(2.f, false, NameOf(SinkTrail));
}

simulated function SinkTrail()
{
	if (SkelControlTrailLeft != None && SkelControlTrailRight != None)
	{
		SkelControlTrailLeft.FakeVelocity.Z = SinkVelocityZ;
		SkelControlTrailRight.FakeVelocity.Z = SinkVelocityZ;
	}

	SetTimer(2.f, false, NameOf(FloatTrail));
}

defaultproperties
{
	Begin Object Class=SkeletalMeshComponent Name=PawnMesh
	End Object
	Mesh=PawnMesh
	Components.Add(PawnMesh)

	Physics=PHYS_Falling

	Begin Object Name=CollisionCylinder
		CollisionRadius=+0030.0000
		CollisionHeight=+0072.000000
	End Object
}