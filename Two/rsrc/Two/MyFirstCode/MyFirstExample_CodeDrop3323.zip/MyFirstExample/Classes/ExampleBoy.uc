class ExampleBoy extends ExamplePawn;

defaultproperties
{
	Mesh=SkeletalMesh'UDN_CharacterModels_K.GenericMale'

    DanceAnim="IdleStretch"

    DrawScale=0.9
	BaseEyeHeight=100
	CollisionRadius=+00040.000000
	CollisionHeight=+00100.000000
	CrouchHeight=+70.0
}

