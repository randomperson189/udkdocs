class ExampleGameInfo extends GameInfo;



defaultproperties
{
	bDelayedStart=false
	HUDType="MyFirstExample.ExampleHUD"
	ScoreBoardType="MyFirstExample.ExampleScoreboard"
	PlayerControllerClassName="MyFirstExample.ExampleController"
	DefaultPlayerName="Player"
	GameName="Example Game"
}
 