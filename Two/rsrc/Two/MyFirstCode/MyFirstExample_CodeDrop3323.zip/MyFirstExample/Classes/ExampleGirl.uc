class ExampleGirl extends ExamplePawn;

defaultproperties
{
	Mesh=SkeletalMesh'UDN_CharacterModels_K.GenericFemale'

    DanceAnim="IdleTwist"

    DrawScale=0.9
	BaseEyeHeight=90
	CollisionRadius=+00040.000000
	CollisionHeight=+00090.000000
	CrouchHeight=+65.0
}

