class ExampleHUD extends HUD;

//var PlayerController PlayerOwner;
var Material HUDScoreBox;



simulated function PostBeginPlay()
{
	Super.PostBeginPlay();
	PlayerOwner = PlayerController(Owner);
}


function DrawHUD(canvas Canvas)
{
	//local Pawn PawnOwner;
	//local PlayerReplicationInfo PawnOwnerPRI;
	local int FontSize;
	local float HUDScoreScaleX, HUDScoreScaleY;
	local float HUDScorePosX, HUDScorePosY;
	local int Score;
	local string ScoreString;
	local float XL,YL;
	
	// Get PlayerOwner
    /* obsolete by 3323
 	if (PlayerOwner.ViewTarget == PlayerOwner)
	{
		PawnOwner = PlayerOwner.Pawn;
	}
	else if (PlayerOwner.ViewTarget.IsA('Pawn') && Pawn(PlayerOwner.ViewTarget).Controller != None)
	{	
		PawnOwner = Pawn(PlayerOwner.ViewTarget);
	}
	else if ( PlayerOwner.Pawn != None )
	{
		PawnOwner = PlayerOwner.Pawn;
	}
	else
	{
		PawnOwner = None;
	}
    */

	// Get PlayerReplication
    /* obsolete by 3323
	if ((PawnOwner != None) && (PawnOwner.Controller != None))
        PawnOwnerPRI = PawnOwner.PlayerReplicationInfo;
    else
        PawnOwnerPRI = PlayerOwner.PlayerReplicationInfo;
    */

	//Get Font Size - (larger numbers are smaller fonts)
	if ( Canvas.ClipX <= 640 )
		FontSize=4;
	else if ( Canvas.ClipX <= 800 )
		FontSize=3;
	else if ( Canvas.ClipX <= 1024 )
		FontSize=2;
	else if ( Canvas.ClipX <= 1280 )
		FontSize=1;
	else if ( Canvas.ClipX <= 1600 )
		FontSize=0;
	else
		FontSize=0;
	Canvas.Font = LoadFontStatic(FontSize);


	// Draw Hud

	Canvas.SetDrawColor(255,255,255);
	HUDScoreScaleX = Canvas.ClipX/800;
	HUDScoreScaleY = Canvas.ClipY/600;
	HUDScorePosX = Canvas.ClipX - 256*HUDScoreScaleX;
	HUDScorePosY = Canvas.ClipY - 128*HUDScoreScaleY;
	Canvas.SetPos(HUDScorePosX, HUDScorePosY);
	Canvas.DrawTileScaled(HUDScoreBox, HUDScoreScaleX, HUDScoreScaleY);

	Canvas.SetDrawColor(230,240,240);
	Score = PawnOwnerPRI.Score;
	ScoreString = ""$Score;
	Canvas.StrLen(ScoreString,XL,YL);
	Canvas.SetPos(HUDScorePosX + 235*HUDScoreScaleX - XL, HUDScorePosY + 70*HUDScoreScaleY);
	Canvas.DrawText(Score);
}



defaultproperties
{
	HUDScoreBox=Texture'ExampleHUD_T.ShakeBox'

    //mh: wasn't able to port the texture package
    // and these aren't used anyway
	//SmallFont=Font'2K4Fonts.Verdana10'
	//MedFont=Font'2K4Fonts.Verdana14'
	//BigFont=Font'2K4Fonts.Verdana18'
	//LargeFont=Font'2K4Fonts.Verdana22'

	FontArrayNames(0)="2K4Fonts.Verdana38"
	FontArrayNames(1)="2K4Fonts.Verdana38"
	FontArrayNames(2)="2K4Fonts.Verdana34"
	FontArrayNames(3)="2K4Fonts.Verdana30"
	FontArrayNames(4)="2K4Fonts.Verdana26"
	FontArrayNames(5)="2K4Fonts.Verdana22"
	FontArrayNames(6)="2K4Fonts.Verdana18"
	FontArrayNames(7)="2K4Fonts.Verdana14"
	FontArrayNames(8)="2K4Fonts.Verdana10"

	FontScreenWidthMedium(0)=1600
	FontScreenWidthMedium(1)=1600
	FontScreenWidthMedium(2)=1600
	FontScreenWidthMedium(3)=1600
	FontScreenWidthMedium(4)=1280
	FontScreenWidthMedium(5)=1024
	FontScreenWidthMedium(6)=800
	FontScreenWidthMedium(7)=640
	FontScreenWidthMedium(8)=0

	ConsoleMessageCount=4
    ConsoleFontSize=5
    MessageFontOffset=0
}
