class ExampleScoreboard extends ScoreBoard;

const MAXPLAYERS=32;

var() localized string      PlayerText;
var() localized string      PointsText;
var PlayerReplicationInfo	PRIArray[MAXPLAYERS];
var() localized String		MapName;

var() Material BoxMaterial;
var() Material TitleMaterial;

simulated event UpdateScoreBoard(Canvas Canvas)
{
	local PlayerReplicationInfo PRI, OwnerPRI;
	local int i, OwnerPos, PlayerCount, OwnerOffset, HeaderOffsetY, HeadFoot;
	local int PlayerBoxSizeY, BoxSpaceY, NameXPos, BoxTextOffsetY, ScoreXPos, BoxXPos, TitleYPos, BoxWidth;
	local float XL,YL;
	local float TitleXL, ScoreXL;
	local string playername[MAXPLAYERS];
	local string TitleString;
	local color WhiteColor;
	
	WhiteColor = class'Canvas'.static.MakeColor(255,255,225);

	OwnerPRI = PlayerController(Owner).PlayerReplicationInfo;

	// Count Players
    for (i=0; i < GRI.PRIArray.Length; i++)
	{
		PRI = GRI.PRIArray[i];
		if ( !PRI.bIsSpectator || PRI.bWaitingPlayer )
		{
			if ( PRI == OwnerPRI )
				OwnerOffset = i;
			PlayerCount++;
		}
	}
	PlayerCount = Min(PlayerCount,MAXPLAYERS);
	
	// Select font size and box size
	Canvas.Font = HUDClass.static.GetMediumFontFor(Canvas); 
	Canvas.StrLen("Test", XL, YL);
	BoxSpaceY = 0.25 * YL;
	PlayerBoxSizeY = 1.5 * YL;
	HeadFoot = 6*YL;
	HeaderOffsetY = 5 * YL;
	BoxWidth = 0.6 * Canvas.ClipX;
	BoxXPos = 0.5 * (Canvas.ClipX - BoxWidth);
	NameXPos = BoxXPos + 0.0625 * BoxWidth;
	ScoreXPos = BoxXPos + 0.85 * BoxWidth;

	// Now that we have font size and box size, see how many players we can fit on the screen
	PlayerCount = Min(PlayerCount, (Canvas.ClipY - HeadFoot)/(PlayerBoxSizeY + BoxSpaceY) );

	// draw title

	Canvas.Style = ERenderStyle.STY_Normal;
	Canvas.Font = HUDClass.static.LargerFontThan(Canvas.Font);
	titlestring = GRI.GameName$MapName$Level.Title;
	Canvas.StrLen(TitleString,TitleXL,YL);

	Canvas.Style = ERenderStyle.STY_Alpha;
	Canvas.DrawColor = WhiteColor;
	Canvas.SetPos(0, 0.25*YL);
	Canvas.DrawTileStretched( TitleMaterial, Canvas.ClipX, YL*1.5);

	Canvas.SetPos(0.5*(Canvas.ClipX-TitleXL), 0.5*YL);
	Canvas.DrawText(TitleString,true);

	// Draw headers
	Canvas.Font = HUDClass.static.GetMediumFontFor(Canvas); 
	Canvas.StrLen("Test",XL,YL);
	TitleYPos = HeaderOffsetY - 1.25*YL;
	Canvas.StrLen(PointsText, ScoreXL, YL);
	Canvas.DrawColor = class'Canvas'.static.MakeColor(221,191,27);
	Canvas.SetPos(NameXPos, TitleYPos);
	Canvas.DrawText(PlayerText,true);
	Canvas.SetPos(ScoreXPos - 0.5*ScoreXL, TitleYPos);
	Canvas.DrawText(PointsText,true);
		
	// draw background boxes
	Canvas.Style = ERenderStyle.STY_Alpha;
	Canvas.DrawColor = WhiteColor * 0.5;
	for ( i=0; i<PlayerCount; i++ )
	{
		Canvas.SetPos(BoxXPos, HeaderOffsetY + (PlayerBoxSizeY + BoxSpaceY)*i);
		Canvas.DrawTileStretched( BoxMaterial, BoxWidth, PlayerBoxSizeY);
	}

	// draw player names
	Canvas.Style = ERenderStyle.STY_Normal;
	Canvas.DrawColor = class'Canvas'.static.MakeColor(180,180,180);
	Canvas.SetPos(0.5 * Canvas.ClipX, HeaderOffsetY + 4);
	for ( i=0; i<PlayerCount; i++ )
		playername[i] = GRI.PRIArray[i].PlayerName;		
	BoxTextOffsetY = HeaderOffsetY + 0.5 * (PlayerBoxSizeY - YL);
	for ( i=0; i<PlayerCount; i++ )
		if ( i != OwnerOffset )
		{
			Canvas.SetPos(NameXPos, (PlayerBoxSizeY + BoxSpaceY)*i + BoxTextOffsetY);
			Canvas.DrawText(playername[i],true);
		}

	// draw scores
	for ( i=0; i<PlayerCount; i++ )
		if ( i != OwnerOffset )
		{
			Canvas.SetPos(ScoreXPos, (PlayerBoxSizeY + BoxSpaceY)*i + BoxTextOffsetY);
			Canvas.DrawText(int(GRI.PRIArray[i].Score),true);
		}
	
	// draw owner line
	if ( OwnerOffset < PlayerCount )
	{
		OwnerPos = (PlayerBoxSizeY + BoxSpaceY)*OwnerOffset + BoxTextOffsetY;		
		Canvas.DrawColor = class'Canvas'.static.MakeColor(255,255,255);
		Canvas.SetPos(NameXPos, OwnerPos);
		Canvas.DrawText(playername[OwnerOffset],true);
		Canvas.SetPos(ScoreXPos, OwnerPos);
		Canvas.DrawText(int(GRI.PRIArray[OwnerOffset].Score),true);
	}
}



defaultproperties
{
    PlayerText="PLAYER"
    PointsText="SCORE"
	MapName=" in "
	BoxMaterial=Material'InterfaceContent.BorderBoxD'
	TitleMaterial=Material'InterfaceContent.SquareBoxA'
	HUDClass=class'ExampleHUD'
}
