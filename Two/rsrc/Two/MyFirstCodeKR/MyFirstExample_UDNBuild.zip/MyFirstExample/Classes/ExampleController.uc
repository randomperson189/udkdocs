class ExampleController extends PlayerController;

var bool DoingDance;

replication
{
	reliable if(Role < ROLE_Authority)
		Fly, Walk, ToggleFlyWalk;
	reliable if ( Role < ROLE_Authority )
		DoDance;
}

exec function DoDance()
{
	if( ExamplePawn(Pawn) != NONE && Pawn.Physics == PHYS_Walking && !DoingDance)
	{
		Pawn.SetAnimAction( ExamplePawn(Pawn).DanceAnim );
		PlayerReplicationInfo.Score += 1;
		DoingDance = true;
		SetTimer(3.0, false);
	}
}

event Timer()
{
	DoingDance = false;
}



exec function Fly()
{
	if ( Pawn != None )
	{
		Pawn.UnderWaterTime = Pawn.Default.UnderWaterTime;	
		ClientMessage("You feel much lighter");
		Pawn.SetCollision(true, true , true);
		Pawn.bCollideWorld = true;
		GotoState('PlayerFlying');
	}
}

exec function Walk()
{	
	if ( Pawn != None )
	{
		Pawn.UnderWaterTime = Pawn.Default.UnderWaterTime;	
		Pawn.SetCollision(true, true , true);
		Pawn.SetPhysics(PHYS_Walking);
		Pawn.bCollideWorld = true;
		GotoState('PlayerWalking');
	}
}

exec function ToggleFlyWalk()
{
	if(IsInState('PlayerFlying'))
		Walk();
	else
		Fly();
}



defaultproperties
{
}