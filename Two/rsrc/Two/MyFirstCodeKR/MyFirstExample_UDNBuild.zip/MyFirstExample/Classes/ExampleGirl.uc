class ExampleGirl extends ExamplePawn;

defaultproperties
{
	Mesh=SkeletalMesh'UDN_CharacterModels_K.GenericFemale'

	RunningAnims[0]="RunF"
	RunningAnims[1]="RunB"
	RunningAnims[2]="RunL"
	RunningAnims[3]="RunR"
	WalkingAnims[0]="WalkF"
	WalkingAnims[1]="WalkB"
	WalkingAnims[2]="WalkL"
	WalkingAnims[3]="WalkR"
	CrouchAnims[0]="CrouchF"
	CrouchAnims[1]="CrouchB"
	CrouchAnims[2]="CrouchL"
	CrouchAnims[3]="CrouchR"
	FlyingAnims[0]="FlyF"
	FlyingAnims[1]="FlyB"
	FlyingAnims[2]="FlyL"
	FlyingAnims[3]="FlyR"
	SwimmingAnims[0]="Swim"
	SwimmingAnims[1]="SwimB"
	SwimmingAnims[2]="SwimL"
	SwimmingAnims[3]="SwimR"

	StandingTurnAnims[0]="WalkL"
	StandingTurnAnims[1]="WalkR"
	CrouchTurnAnims[0]="CrouchL"
	CrouchTurnAnims[1]="CrouchR"

	StandIdle="IdleLong"
	CrouchIdle="CrouchIdle"
	FlyIdle="FlyIdle"
	SwimIdle="SwimTread"

	JumpStandingAnim="JumpUp"
	JumpMovingAnim="JumpF"
	LandAnim="JumpFLand"
	FallingAnim="Falling"

	DanceAnim="IdleTwist"

	BaseEyeHeight=100
	CollisionRadius=+00040.000000
	CollisionHeight=+00100.000000
	CrouchHeight=+72.0
}

