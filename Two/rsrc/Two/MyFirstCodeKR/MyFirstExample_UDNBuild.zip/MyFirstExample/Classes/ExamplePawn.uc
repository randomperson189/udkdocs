class ExamplePawn extends Pawn;

const LANDINGCHANNEL = 12;

var name RunningAnims[4];
var name WalkingAnims[4];
var name CrouchAnims[4];
var name FlyingAnims[4];
var name SwimmingAnims[4];

var name StandingTurnAnims[2];
var name CrouchTurnAnims[2];

var name StandIdle;
var name CrouchIdle;
var name FlyIdle;
var name SwimIdle;

var name DanceAnim;

var name JumpStandingAnim;
var name JumpMovingAnim;
var name LandAnim;
var name FallingAnim;

var bool bStartBehindView;

var bool bPlayedAnimAction;

event TakeDamage( int Damage, Pawn EventInstigator, vector HitLocation, vector Momentum, class<DamageType> DamageType)
{
	// Never take damage or die
}

//Called when this pawn is possessed by the controller to see how the view should be 
simulated function bool PointOfView()
{
	return bStartBehindView;
}

//Called to have all clients play a single animation in the idle animation channel
simulated event SetAnimAction(name NewAction)
{
	AnimAction = NewAction;
	PlayAnim(NewAction, 1.0, 0.2); //Play on base channel, which is the idle channel
	bPlayedAnimAction = true;
}



// Called whenever a player changes their movement type.
simulated function PlayMoving()
{
	if ( Physics == PHYS_Flying )
		AnimateFlying();
	else if ( (Physics == PHYS_Swimming)
		|| ((Physics == PHYS_Falling) && TouchingWaterVolume()) )
		AnimateSwimming();
	else
	{
		if ( bIsCrouched )
		{
			AnimateCrouchWalking();
		}
		else if ( bIsWalking )
		{
			AnimateWalking();
		}
		else
		{
			AnimateRunning();
		}
	}
}

// Play appropriate idle animations
simulated function PlayWaiting()
{
	if(Physics == PHYS_Falling)
		LoopAnim(FallingAnim, 1.0, 0.2);
	else if(Physics == PHYS_Flying)
		LoopAnim(FlyIdle, 1.0, 0.2);
	else if(Physics == PHYS_Swimming)
		LoopAnim(SwimIdle, 1.0, 0.2);
	else
	{
		if(bIsCrouched)
			LoopAnim(CrouchIdle, 1.0, 0.2);
		else
			LoopAnim(StandIdle, 1.0, 0.2);
	}
}

// Play appropriate running animations
simulated function AnimateRunning()
{
	MovementAnims[0]=RunningAnims[0];
	MovementAnims[1]=RunningAnims[1];
	MovementAnims[2]=RunningAnims[2];
	MovementAnims[3]=RunningAnims[3];
	TurnLeftAnim=StandingTurnAnims[0];
	TurnRightAnim=StandingTurnAnims[1];
}

// Play appropriate walking animations
simulated function AnimateWalking()
{
	MovementAnims[0]=WalkingAnims[0];
	MovementAnims[1]=WalkingAnims[1];
	MovementAnims[2]=WalkingAnims[2];
	MovementAnims[3]=WalkingAnims[3];
	TurnLeftAnim=StandingTurnAnims[0];
	TurnRightAnim=StandingTurnAnims[1];
}

// Play appropriate crouching animations
simulated function AnimateCrouchWalking()
{
	MovementAnims[0]=CrouchAnims[0];
	MovementAnims[1]=CrouchAnims[1];
	MovementAnims[2]=CrouchAnims[2];
	MovementAnims[3]=CrouchAnims[3];
	TurnLeftAnim=CrouchTurnAnims[0];
	TurnRightAnim=CrouchTurnAnims[1];
}

// Play appropriate flying animations
simulated function AnimateFlying()
{
	MovementAnims[0]=FlyingAnims[0];
	MovementAnims[1]=FlyingAnims[1];
	MovementAnims[2]=FlyingAnims[2];
	MovementAnims[3]=FlyingAnims[3];
}

// Play appropriate swimming animations
simulated function AnimateSwimming()
{
	MovementAnims[0]=SwimmingAnims[0];
	MovementAnims[1]=SwimmingAnims[1];
	MovementAnims[2]=SwimmingAnims[2];
	MovementAnims[3]=SwimmingAnims[3];
}



simulated event PlayFalling()
{
	LoopAnim(FallingAnim, 1.0, 0.5);
}

simulated event PlayJump()
{
	AnimBlendToAlpha(LANDINGCHANNEL,0,0.0);
	if ( (Acceleration.X != 0) || (Acceleration.Y != 0) )
		PlayAnim(JumpMovingAnim, 1.0, 0.1);
	else
		PlayAnim(JumpStandingAnim, 1.0, 0.1);
}

simulated event PlayLandingAnimation(float ImpactVel)
{
	AnimBlendParams(LANDINGCHANNEL, 1.0, 2.0, 2.0);
	PlayAnim(LandAnim, 0.4, 0.0, LANDINGCHANNEL);
}

simulated event AnimEnd(int Channel)
{
	Super.AnimEnd(Channel);

	if(Channel == 0 && bPlayedAnimAction) //idle channel
	{
		PlayWaiting(); //reset to normal idle
		bPlayedAnimAction = false;
		AnimAction = '';
	}
	if(Channel == LANDINGCHANNEL)
	{
		AnimBlendToAlpha(LANDINGCHANNEL,0,0.3);
	}
}



// Sets up Physics correctly for Scripted Sequences
function SetMovementPhysics()
{
	if (Physics == PHYS_Falling)
		return;
	if ( PhysicsVolume.bWaterVolume )
		SetPhysics(PHYS_Swimming);
	else
		SetPhysics(PHYS_Walking); 
}



defaultproperties
{
	//These need to be defined or else it will not animate in net play
	MovementAnims[0]="RunF"
	MovementAnims[1]="RunB"
	MovementAnims[2]="RunL"
	MovementAnims[3]="RunR"
	TurnLeftAnim="WalkL"
	TurnRightAnim="WalkR"

	bPhysicsAnimUpdate=true
	bSimulateGravity=true
	bCanCrouch=true
	bActorShadows=true
	BaseEyeHeight=100
	CollisionRadius=+00040.000000
	CollisionHeight=+00100.000000
	bStartBehindView=true
	JumpZ=500
	LODBias=5
}
